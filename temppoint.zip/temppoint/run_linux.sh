#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

if [ -x "$DIR/node_modules/.bin/electron" ]; then
  exec "$DIR/node_modules/.bin/electron" "$DIR"
elif command -v electron >/dev/null 2>&1; then
  exec electron "$DIR"
else
  exec python3 "$DIR/linux_native_launcher.py"
fi

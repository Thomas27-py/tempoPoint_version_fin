#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
chmod +x "$DIR/run_linux.sh" "$DIR/linux_native_launcher.py"

if command -v npm >/dev/null 2>&1 && [ ! -d "$DIR/node_modules/electron" ]; then
  echo "Installation d'Electron pour le rendu desktop natif..."
  cd "$DIR" && npm install
fi

ICON_DIR="$HOME/.local/share/icons/hicolor/scalable/apps"
APP_MENU_DIR="$HOME/.local/share/applications"
mkdir -p "$ICON_DIR" "$APP_MENU_DIR"
cp "$DIR/assets/logo.svg" "$ICON_DIR/tempo-point-ia.svg"

cat > "$APP_MENU_DIR/tempo-point-ia.desktop" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Tempo-Point IA
Comment=Plateforme intelligente de gestion, pointage et pilotage d'entreprise
Exec=$DIR/run_linux.sh
Icon=tempo-point-ia
Terminal=false
Categories=Office;ProjectManagement;
StartupWMClass=tempo-point-ia
EOF

chmod +x "$APP_MENU_DIR/tempo-point-ia.desktop"
update-desktop-database "$APP_MENU_DIR" >/dev/null 2>&1 || true

echo "Tempo-Point IA installé dans votre menu d'applications Linux."
echo "Lancez-le depuis votre menu d'applications ou avec : ./run_linux.sh"

#!/usr/bin/env python3
"""
Lanceur natif Linux autonome pour Tempo-Point IA.
Utilisé automatiquement si Electron n'est pas installé.
Sert les fichiers localement sur 127.0.0.1 avec persistance JSON locale
et ouvre une fenêtre applicative native (GTK/WebKit2, PyQt6, PySide6 ou Chromium --app).
"""
import functools
import http.server
import json
import os
import shutil
import socketserver
import subprocess
import sys
import threading

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.join(BASE_DIR, "app")
DATA_DIR = os.path.join(os.path.expanduser("~"), ".local", "share", "tempo-point-ia")
DATA_FILE = os.path.join(DATA_DIR, "tempo-point-data.json")
os.makedirs(DATA_DIR, exist_ok=True)


class TempoHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def _send_json(self, code, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/__tp_api/state":
            if os.path.exists(DATA_FILE):
                with open(DATA_FILE, "r", encoding="utf-8") as f:
                    try:
                        return self._send_json(200, {"ok": True, "state": json.load(f)})
                    except Exception:
                        pass
            return self._send_json(200, {"ok": True, "state": None})
        return super().do_GET()

    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length) if length > 0 else b"{}"
        if self.path == "/__tp_api/state":
            try:
                data = json.loads(raw.decode("utf-8"))
                with open(DATA_FILE, "w", encoding="utf-8") as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                return self._send_json(200, {"ok": True})
            except Exception as exc:
                return self._send_json(500, {"ok": False, "error": str(exc)})
        elif self.path == "/__tp_api/reset":
            if os.path.exists(DATA_FILE):
                os.remove(DATA_FILE)
            return self._send_json(200, {"ok": True})
        return self._send_json(404, {"ok": False})


def start_server():
    handler = functools.partial(TempoHandler, directory=APP_DIR)
    httpd = socketserver.TCPServer(("127.0.0.1", 0), handler)
    port = httpd.server_address[1]
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    return httpd, f"http://127.0.0.1:{port}/index.html"


def try_gtk_webkit(url):
    try:
        import gi
        gi.require_version("Gtk", "3.0")
        try:
            gi.require_version("WebKit2", "4.1")
        except ValueError:
            gi.require_version("WebKit2", "4.0")
        from gi.repository import Gtk, WebKit2
        win = Gtk.Window(title="Tempo-Point IA")
        win.set_default_size(1380, 880)
        icon_path = os.path.join(BASE_DIR, "assets", "logo.svg")
        if os.path.exists(icon_path):
            try:
                win.set_icon_from_file(icon_path)
            except Exception:
                pass
        view = WebKit2.WebView()
        view.load_uri(url)
        win.add(view)
        win.connect("destroy", Gtk.main_quit)
        win.show_all()
        Gtk.main()
        return True
    except Exception:
        return False


def try_qt(url):
    for mod in ("PyQt6", "PySide6"):
        try:
            if mod == "PyQt6":
                from PyQt6.QtWidgets import QApplication, QMainWindow
                from PyQt6.QtWebEngineWidgets import QWebEngineView
                from PyQt6.QtCore import QUrl
            else:
                from PySide6.QtWidgets import QApplication, QMainWindow
                from PySide6.QtWebEngineWidgets import QWebEngineView
                from PySide6.QtCore import QUrl
            app = QApplication(sys.argv)
            win = QMainWindow()
            win.setWindowTitle("Tempo-Point IA")
            win.resize(1380, 880)
            web = QWebEngineView()
            web.setUrl(QUrl(url))
            win.setCentralWidget(web)
            win.show()
            app.exec()
            return True
        except Exception:
            continue
    return False


def try_browser_app_mode(url):
    for cmd in ("chromium", "chromium-browser", "google-chrome", "brave-browser", "microsoft-edge"):
        exe = shutil.which(cmd)
        if exe:
            subprocess.run([exe, f"--app={url}", "--window-size=1380,880"])
            return True
    return False


if __name__ == "__main__":
    server, url = start_server()
    try:
        if not try_gtk_webkit(url):
            if not try_qt(url):
                if not try_browser_app_mode(url):
                    import webbrowser
                    webbrowser.open(url)
                    input("Tempo-Point IA actif sur " + url + "\nAppuyez sur Entrée pour fermer...")
    finally:
        server.shutdown()

(function () {
  const LS_KEY = 'tempo_point_ia_v1_state';

  const ICONS = {
    home: '<path d="M3 10.5L12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    cpu: '<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/>',
    chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    folder: '<path d="M3 6a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    zap: '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
    shield: '<path d="M12 2l8 4v6c0 5.25-3.4 9.74-8 11-4.6-1.26-8-5.75-8-11V6l8-4z"/>',
    code: '<polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>',
    trend: '<polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3.6 9h16.8M3.6 15h16.8M12 3a14 14 0 0 0 0 18M12 3a14 14 0 0 1 0 18"/>',
    file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="16" y2="17"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/>'
  };

  window.TP = {
    state: null,
    ui: {
      phase: 'splash',
      route: 'home',
      sub: 'dashboard',
      params: {},
      installStep: 1
    },

    icon(name, size = 18) {
      return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${ICONS[name] || ''}</svg>`;
    },

    logoSvg(size = 24) {
      return `<svg width="${size}" height="${size}" viewBox="0 0 128 128" fill="none">
        <rect x="52" y="18" width="24" height="9" rx="4.5" fill="#0B2E33"/>
        <rect x="61" y="26" width="6" height="9" fill="#0B2E33"/>
        <circle cx="64" cy="70" r="34" stroke="#0B2E33" stroke-width="10"/>
        <path d="M64 49V70L79 80" stroke="#0B2E33" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>`;
    },

    esc(str) {
      return String(str ?? '').replace(/[&<>"']/g, s => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[s]));
    },

    fmtMoney(val) {
      const cur = this.state?.company?.currency || 'Ar';
      const n = Number(val || 0).toLocaleString('fr-FR');
      return cur === 'Ar' ? `${n} Ar` : `${n} ${cur}`;
    },

    initials(fullName) {
      return (fullName || 'TP').trim().split(/\s+/).slice(0, 2).map(w => w[0]?.toUpperCase() || '').join('');
    },

    hasPerm(key) {
      const role = this.state.currentRole || 'PDG';
      return !!(this.state.rolePermissions[role]?.[key]);
    },

    isModuleEnabled(key) {
      return this.state.enabledModules?.[key] !== false;
    },

    async loadFromStorage() {
      let loaded = null;
      if (window.tempoBridge && window.tempoBridge.loadState) {
        try { loaded = await window.tempoBridge.loadState(); } catch {}
      } else {
        try {
          const r = await fetch('/__tp_api/state');
          if (r.ok) { const j = await r.json(); if (j.state) loaded = j.state; }
        } catch {}
      }
      if (!loaded) {
        try {
          const raw = localStorage.getItem(LS_KEY);
          if (raw) loaded = JSON.parse(raw);
        } catch {}
      }
      const def = window.TP_DEFAULT_DATA();
      this.state = loaded ? Object.assign({}, def, loaded) : def;
    },

    async save() {
      try { localStorage.setItem(LS_KEY, JSON.stringify(this.state)); } catch {}
      if (window.tempoBridge && window.tempoBridge.saveState) {
        try { await window.tempoBridge.saveState(this.state); } catch {}
      } else {
        try {
          await fetch('/__tp_api/state', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(this.state)
          });
        } catch {}
      }
    },

    async resetAll() {
      localStorage.removeItem(LS_KEY);
      if (window.tempoBridge?.resetState) await window.tempoBridge.resetState();
      else { try { await fetch('/__tp_api/reset', { method: 'POST' }); } catch {} }
      this.state = window.TP_DEFAULT_DATA();
      this.ui.installStep = 1;
      this.ui.phase = 'splash';
      this.render();
    },

    logAction(action, target, motif = 'Action système', before = '—', after = '—', field = 'Général') {
      const now = new Date();
      const dd = String(now.getDate()).padStart(2, '0');
      const mm = String(now.getMonth() + 1).padStart(2, '0');
      const hh = String(now.getHours()).padStart(2, '0');
      const mi = String(now.getMinutes()).padStart(2, '0');
      const author = `${this.state.adminAccount.name} (${this.state.currentRole})`;
      this.state.logs.unshift({
        id: 'log-' + Date.now() + Math.random().toString(16).slice(2, 5),
        date: `${dd}/${mm}/${now.getFullYear()} · ${hh}:${mi}`,
        action, target, author, motif, before, after, field
      });
      this.save();
    },

    toast(message) {
      const root = document.getElementById('toast-root');
      const el = document.createElement('div');
      el.className = 'toast';
      el.innerHTML = `<span style="color:#F59E0B;font-weight:800;">✓</span><span>${this.esc(message)}</span>`;
      root.appendChild(el);
      setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 250); }, 3200);
    },

    openModal(title, bodyHtml, wide = false) {
      const root = document.getElementById('modal-root');
      root.innerHTML = `
        <div class="modal-backdrop" onclick="if(event.target===this) TP.closeModal()">
          <div class="modal-box ${wide ? 'wide' : ''}">
            <div class="flex-between mb-4">
              <h2>${this.esc(title)}</h2>
              <button class="btn btn-outline btn-sm" onclick="TP.closeModal()">✕ Fermer</button>
            </div>
            <div>${bodyHtml}</div>
          </div>
        </div>`;
    },

    closeModal() {
      document.getElementById('modal-root').innerHTML = '';
    },

    async exportFile(filename, content) {
      if (window.tempoBridge?.exportFile) {
        const res = await window.tempoBridge.exportFile({ filename, content });
        if (res.ok) return this.toast(`Fichier exporté : ${res.filePath}`);
        if (res.canceled) return;
      }
      const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = filename;
      a.click();
      URL.revokeObjectURL(a.href);
      this.toast(`Export téléchargé : ${filename}`);
    },

    navigate(route, sub = 'index', params = {}) {
      this.ui.route = route;
      this.ui.sub = sub;
      this.ui.params = params;
      this.render();
    },

    async boot() {
      await this.loadFromStorage();
      this.ui.phase = 'splash';
      this.render();
    },

    finishSplash() {
      const el = document.getElementById('splash-screen');
      if (el) el.classList.add('fade-out');
      setTimeout(() => {
        this.ui.phase = this.state.installed ? (this.state.loggedIn ? 'app' : 'login') : 'install';
        this.render();
      }, 450);
    },

    render() {
      const root = document.getElementById('root');
      if (this.ui.phase === 'splash') return (root.innerHTML = window.TP_VIEWS.splash());
      if (this.ui.phase === 'install') return (root.innerHTML = window.TP_VIEWS.install());
      if (this.ui.phase === 'login') return (root.innerHTML = window.TP_VIEWS.login());
      root.innerHTML = this.renderAppShell();
    },

    renderAppShell() {
      const s = this.state;
      const r = this.ui.route;
      const pendCount = s.pendingRegistrations.length;
      const aprCount = s.approvals.filter(a => a.status === 'En attente').length;

      const navGroup = (label, items) => {
        const visible = items.filter(it => !it.mod || this.isModuleEnabled(it.mod));
        if (!visible.length) return '';
        return `<div class="nav-group-label">${label}</div>` + visible.map(it => `
          <button class="nav-item ${r === it.id ? 'active' : ''}" onclick="TP.navigate('${it.id}','${it.sub || 'index'}')">
            ${this.icon(it.icon, 17)}
            <span>${it.label}</span>
            ${it.badge ? `<span class="nav-badge">${it.badge}</span>` : ''}
          </button>`).join('');
      };

      const sidebar = `
        <aside class="sidebar">
          <div>
            <div class="brand-lockup" style="padding:4px 8px 14px;">
              <div class="brand-badge">${this.logoSvg(22)}</div>
              <div>
                <div style="font-weight:800;color:#fff;font-size:15px;">Tempo-Point <span style="color:#FBBF24;">IA</span></div>
                <div style="font-size:11px;color:#7FA2A8;">${this.esc(s.company.name)}</div>
              </div>
            </div>
            ${navGroup('Pilotage', [
              { id: 'home', label: 'Accueil', icon: 'home', sub: 'dashboard' },
              { id: 'vision', label: 'Vision numérique', icon: 'globe', mod: 'digitalVision' },
              { id: 'predictive', label: 'Prédictif IA', icon: 'trend', mod: 'predictive' }
            ])}
            ${navGroup('RH & Temps', [
              { id: 'employees', label: 'Employés', icon: 'users', badge: pendCount || '' },
              { id: 'rules', label: 'Règles de pointage', icon: 'clock' },
              { id: 'machines', label: 'Machines', icon: 'cpu' },
              { id: 'stats', label: 'Statistiques', icon: 'chart' }
            ])}
            ${navGroup('Coordination & Flux', [
              { id: 'projects', label: 'Projets & Tâches', icon: 'folder', mod: 'projectsTasks' },
              { id: 'agenda', label: 'Agenda & Planning', icon: 'calendar' },
              { id: 'automation', label: 'Automatisations', icon: 'zap', mod: 'automation', badge: aprCount || '' }
            ])}
            ${navGroup('Sécurité, API & Audit', [
              { id: 'security', label: 'Sécurité & Cloud', icon: 'shield' },
              { id: 'api', label: 'Tempo API', icon: 'code', mod: 'tempoApi' },
              { id: 'logs', label: 'Journaux', icon: 'file' }
            ])}
            ${navGroup('Assistance', [
              { id: 'help', label: 'Outil d\'aide', icon: 'help' }
            ])}
          </div>
          <div class="sidebar-account">
            <button class="account-btn ${r === 'account' ? 'active' : ''}" onclick="TP.navigate('account','profile')">
              <span class="avatar avatar-amber">${this.initials(s.adminAccount.name)}</span>
              <div style="min-width:0;flex:1;">
                <div style="font-weight:700;color:#fff;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">Mon compte</div>
                <div style="font-size:11.5px;color:#93B3B8;">${this.esc(s.adminAccount.name)} · ${s.currentRole}</div>
              </div>
            </button>
          </div>
        </aside>`;

      const modePill = s.securityCloud.storageMode === 'local'
        ? '<span class="pill pill-gray">Mode Local pur</span>'
        : s.securityCloud.storageMode === 'hybride'
          ? '<span class="pill pill-blue">Hybride · Consentement actif</span>'
          : '<span class="pill pill-green">Cloud consenté</span>';

      const topbar = `
        <header class="topbar">
          <div class="topbar-left">
            <span class="pill pill-dark">${s.company.type === 'type1' ? 'Type n°01 · Sections' : 'Type n°02 · Calendrier'}</span>
            ${modePill}
            <span class="muted small">Linux Desktop · v1.0</span>
          </div>
          <div class="topbar-right">
            <select class="select" style="width:auto;padding:5px 10px;font-size:12.5px;" onchange="TP.state.currentRole=this.value;TP.save();TP.render();TP.toast('Rôle actif : '+this.value)">
              ${['PDG', 'DRH', 'DG', 'SG'].map(rl => `<option value="${rl}" ${s.currentRole === rl ? 'selected' : ''}>Rôle : ${rl}</option>`).join('')}
            </select>
            <button class="btn btn-outline btn-sm" onclick="TP.ui.phase='splash';TP.render();">▶ Intro</button>
            <button class="btn btn-outline btn-sm" onclick="TP.state.loggedIn=false;TP.ui.phase='login';TP.save();TP.render();">Verrouiller</button>
          </div>
        </header>`;

      let pageContent = '';
      if (r === 'home') pageContent = window.TP_CORE_MODULES.home();
      else if (r === 'employees') pageContent = window.TP_CORE_MODULES.employees();
      else if (r === 'rules') pageContent = window.TP_CORE_MODULES.rules();
      else if (r === 'machines') pageContent = window.TP_CORE_MODULES.machines();
      else if (r === 'stats') pageContent = window.TP_CORE_MODULES.stats();
      else if (r === 'projects') pageContent = window.TP_EXT_MODULES.projects();
      else if (r === 'agenda') pageContent = window.TP_EXT_MODULES.agenda();
      else if (r === 'automation') pageContent = window.TP_EXT_MODULES.automation();
      else if (r === 'security') pageContent = window.TP_EXT_MODULES.security();
      else if (r === 'api') pageContent = window.TP_EXT_MODULES.api();
      else if (r === 'predictive') pageContent = window.TP_EXT_MODULES.predictive();
      else if (r === 'vision') pageContent = window.TP_EXT_MODULES.vision();
      else if (r === 'logs') pageContent = window.TP_EXT_MODULES.logs();
      else if (r === 'help') pageContent = window.TP_EXT_MODULES.help();
      else if (r === 'account') pageContent = window.TP_EXT_MODULES.account();

      return `<div class="app-shell">${sidebar}<div class="main-area">${topbar}<main class="content-scroll">${pageContent}</main></div></div>`;
    }
  };
})();

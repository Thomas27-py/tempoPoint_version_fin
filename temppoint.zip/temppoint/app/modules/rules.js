(function () {
  window.TP_CORE_MODULES = window.TP_CORE_MODULES || {};
  window.TP_CORE = window.TP_CORE || {};

  window.TP_CORE_MODULES.rules = function () {
    const r = TP.state.rules;
    const tab = TP.ui.sub === 'index' ? 'horaires' : TP.ui.sub;
    const tabs = [['horaires', 'Horaires'], ['pauses', 'Pauses et repas'], ['plages', 'Plages par salarié'], ['calendrier', 'Calendrier'], ['appliquer', 'Appliquer'], ['documents', 'Documents']];

    let inner = '';
    if (tab === 'horaires') {
      inner = `
        <div class="grid-2">
          <div class="card">
            <label class="field-label">Heure d'arrivée</label><input type="time" class="input mb-3" value="${r.arrival}" onchange="TP.state.rules.arrival=this.value;TP.save();"/>
            <label class="field-label">Heure de fin de travail</label><input type="time" class="input mb-3" value="${r.departure}" onchange="TP.state.rules.departure=this.value;TP.save();"/>
            <label class="field-label">Tolérance de retard (minutes)</label><input type="number" class="input" value="${r.lateTolerance}" oninput="TP.state.rules.lateTolerance=+this.value;TP.save();"/>
          </div>
          <div class="card" style="background:#F7FAFA;">
            <div class="muted small">Tolérance configurée</div>
            <div style="font-size:30px;font-weight:800;margin:8px 0;">${r.lateTolerance} minutes</div>
            <p class="muted small">Au-delà, le retard est compté en minutes et alimente les retenues configurées.</p>
          </div>
        </div>`;
    } else if (tab === 'pauses') {
      inner = `
        <div style="display:flex;flex-direction:column;gap:10px;">
          ${r.breaks.map((b, i) => `
            <div class="card flex-between">
              <strong>${TP.esc(b.label)}</strong>
              <div class="flex gap-2">
                <input type="time" class="input" style="width:120px;" value="${b.start}" onchange="TP.state.rules.breaks[${i}].start=this.value;TP.save();"/>
                <span>–</span>
                <input type="time" class="input" style="width:120px;" value="${b.end}" onchange="TP.state.rules.breaks[${i}].end=this.value;TP.save();"/>
                <button class="btn btn-danger btn-sm" onclick="TP.state.rules.breaks.splice(${i},1);TP.save();TP.render();">🗑</button>
              </div>
            </div>`).join('')}
          <button class="btn btn-outline" onclick="TP_CORE.addBreak()">+ Ajouter une pause ou un repas</button>
        </div>`;
    } else if (tab === 'plages') {
      inner = `
        <div class="table-wrap">
          <table>
            <thead><tr><th>Début – Fin</th><th>Salarié</th><th>Unité</th><th></th></tr></thead>
            <tbody>
              ${r.employeeShifts.map((sh, i) => `
                <tr><td>${TP.esc(sh.range)}</td><td><strong>${TP.esc(sh.employee)}</strong></td><td><span class="pill ${sh.unit === 'Nuit' ? 'pill-dark' : 'pill-blue'}">${sh.unit}</span></td><td><button class="btn btn-danger btn-sm" onclick="TP.state.rules.employeeShifts.splice(${i},1);TP.save();TP.render();">🗑</button></td></tr>`).join('')}
            </tbody>
          </table>
        </div>
        <button class="btn btn-outline mt-3" onclick="TP_CORE.addShift()">+ Ajouter une plage horaire</button>`;
    } else if (tab === 'calendrier') {
      inner = `
        <p class="muted mb-3">Cliquez sur n'importe quel jour du mois pour basculer le régime (Jour → Nuit → Repos).</p>
        <div class="cal-grid">
          ${r.calendarCycle.map((mode, idx) => {
            const cls = mode === 'Nuit' ? 'background:#0B2E33;color:#fff;' : mode === 'Repos' ? 'background:#EEF2F3;color:#64748B;' : 'background:#E0F2FE;color:#0369A1;';
            return `<button class="cal-cell" style="min-height:68px;${cls}" onclick="TP_CORE.cycleCal(${idx})"><strong>${idx + 1}</strong><span class="small">${mode}</span></button>`;
          }).join('')}
        </div>`;
    } else if (tab === 'appliquer') {
      inner = `
        <div class="card">
          <div class="flex-between"><span>Arrivée / Fin</span><strong>${r.arrival} – ${r.departure}</strong></div>
          <div class="flex-between mt-3"><span>Tolérance de retard</span><strong>${r.lateTolerance} minutes</strong></div>
          <div class="flex-between mt-3"><span>Pauses et repas</span><strong>${r.breaks.length} plages configurées</strong></div>
          <div class="flex-between mt-3"><span>Plages par salarié</span><strong>${r.employeeShifts.length} définies</strong></div>
          <div class="flex-between mt-4">
            <span class="pill pill-dark">✓ Règle prête · tracée dans les journaux</span>
            <button class="btn btn-amber" onclick="TP_CORE.applyRules()">✓ Appliquer la règle</button>
          </div>
        </div>`;
    } else {
      const docs = ['Règlement des horaires', 'Règles de pause et de repas', 'Règles de retard et heures sup', 'Calendrier jour / nuit', 'Plages par salarié', 'Règles du télétravail'];
      inner = `
        <div class="card">
          <h3 class="mb-3">Documents générés automatiquement depuis vos règles</h3>
          ${docs.map(d => `<div class="flex-between mb-2" style="padding:10px;border:1px solid var(--border);border-radius:10px;"><span>☑ ${d}</span><span class="pill pill-green">Prêt</span></div>`).join('')}
          <div class="flex gap-2 mt-4">
            <button class="btn btn-outline" onclick="TP_CORE.exportRules('txt')">Exporter .TXT</button>
            <button class="btn btn-outline" onclick="TP_CORE.exportRules('csv')">Exporter Excel (CSV)</button>
            <button class="btn btn-amber" onclick="TP_CORE.exportRules('doc')">Exporter Word / PDF</button>
          </div>
        </div>`;
    }

    return `
      <div class="flex-between mb-4">
        <div><h1>Modifier les règles de pointage</h1><p class="muted">Horaires, pauses, plages, calendrier et documentation</p></div>
      </div>
      <div class="tabs">${tabs.map(([k, l]) => `<button class="tab-btn ${tab === k ? 'active' : ''}" onclick="TP.navigate('rules','${k}')">${l}</button>`).join('')}</div>
      ${inner}`;
  };

  Object.assign(window.TP_CORE, {
    addBreak() { TP.state.rules.breaks.push({ id: 'br-' + Date.now(), label: 'Pause supplémentaire', start: '16:00', end: '16:15' }); TP.save(); TP.render(); },
    addShift() { TP.state.rules.employeeShifts.push({ id: 'sh-' + Date.now(), range: '08h – 17h', employee: TP.state.employees[0].nom + ' ' + TP.state.employees[0].prenom, unit: 'Jour' }); TP.save(); TP.render(); },
    cycleCal(idx) {
      const seq = ['Jour', 'Nuit', 'Repos'];
      TP.state.rules.calendarCycle[idx] = seq[(seq.indexOf(TP.state.rules.calendarCycle[idx]) + 1) % 3];
      TP.save(); TP.render();
    },
    applyRules() {
      const r = TP.state.rules;
      TP.state.ruleLogs.unshift({ label: 'Application complète des règles', before: 'Règle précédente', after: `${r.arrival}–${r.departure} (tol. ${r.lateTolerance}m)`, date: 'Aujourd\'hui', author: `${TP.state.adminAccount.name} (${TP.state.currentRole})` });
      TP.logAction('Modifier', 'Règles de pointage appliquées', 'Mise à jour règlement', 'Précédent', `${r.arrival}–${r.departure}`, 'Règles');
      TP.save(); TP.toast('Règles appliquées et journalisées !');
    },
    exportRules(fmt) {
      const r = TP.state.rules;
      const content = `TEMPO-POINT IA - REGLEMENT (${TP.state.company.name})\nArrivee: ${r.arrival} | Fin: ${r.departure} | Tolerance: ${r.lateTolerance} min\n` + r.breaks.map(b => `- ${b.label}: ${b.start} - ${b.end}`).join('\n');
      TP.exportFile(`regles-pointage.${fmt}`, content);
    }
  });
})();

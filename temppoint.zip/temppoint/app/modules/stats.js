(function () {
  window.TP_CORE_MODULES = window.TP_CORE_MODULES || {};
  window.TP_CORE = window.TP_CORE || {};

  window.TP_CORE_MODULES.stats = function () {
    const s = TP.state;
    const emps = s.employees;
    const present = emps.filter(e => e.status === 'Présent').length;
    const late = emps.filter(e => e.status === 'Retard').length;
    const filterSec = TP.ui.params.section || null;
    const sub = TP.ui.sub;
    const listRows = emps.filter(e => {
      if (!filterSec) return true;
      if (filterSec === 'Télétravail') return e.telework;
      if (s.company.type === 'type2') return e.shift.includes(filterSec);
      return e.section === filterSec;
    });
    const days = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];
    const planned = [48, 48, 44, 48, 46, 26, 48];
    const actual = [45, 47, 40, 48, 42, 26, present + late];

    const groupCards = s.company.type === 'type1'
      ? s.company.sections.concat(s.company.teleworkEnabled ? ['Télétravail'] : [])
      : ['Jour', 'Nuit', 'Repos'].concat(s.company.teleworkEnabled ? ['Télétravail'] : []);

    return `
      <div class="flex-between mb-4">
        <div>
          <h1>${filterSec ? 'Statistiques · ' + TP.esc(filterSec) : 'Statistiques globales'}</h1>
          <p class="muted">${s.company.type === 'type1' ? 'Type n°01 · par section et télétravail' : 'Type n°02 · équipes Jour, Nuit, Repos & télétravail'}</p>
        </div>
        <div class="flex gap-2">
          ${filterSec ? `<button class="btn btn-outline" onclick="TP.navigate('stats','index')">← Global</button>` : ''}
          <button class="btn btn-outline" onclick="TP.navigate('stats','daily')">Liste du jour</button>
          <button class="btn btn-outline" onclick="TP.navigate('stats','calendar')">Suivi calendrier</button>
          <button class="btn btn-primary" onclick="TP_CORE.exportStatsModal()">⬇ Exporter</button>
        </div>
      </div>

      ${sub === 'calendar' ? `
        <div class="card">
          <h3 class="mb-3">Prévus et présents par jour</h3>
          <div style="display:flex;align-items:flex-end;gap:18px;height:210px;padding:12px 10px 0;">
            ${days.map((d, i) => `
              <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;">
                <div style="display:flex;align-items:flex-end;gap:5px;height:160px;">
                  <div style="width:22px;height:${planned[i] * 3}px;background:#D6E2E3;border-radius:6px 6px 0 0;" title="Prévus: ${planned[i]}"></div>
                  <div style="width:22px;height:${Math.min(48, actual[i]) * 3}px;background:#17525B;border-radius:6px 6px 0 0;" title="Présents: ${actual[i]}"></div>
                </div>
                <span class="small muted">${d}</span>
              </div>`).join('')}
          </div>
        </div>` : sub === 'daily' ? `
        <div class="table-wrap">
          <table>
            <thead><tr><th>Salarié</th><th>Plage</th><th>Pointage</th><th>Statut</th><th>Heures</th></tr></thead>
            <tbody>${emps.map(e => `<tr><td><strong>${TP.esc(e.nom)} ${TP.esc(e.prenom)}</strong></td><td>${TP.esc(e.shift)}</td><td class="num">${e.arrivee}</td><td><span class="pill ${e.status === 'Présent' ? 'pill-green' : e.status === 'Retard' ? 'pill-amber' : 'pill-red'}">${e.status}</span></td><td class="num">${e.heures}</td></tr>`).join('')}</tbody>
          </table>
        </div>` : `
        <div class="card mb-4">${TP_CHARTS.arrivalsSvg(present + late, late)}</div>
        ${!filterSec ? `
          <h3 class="mb-3">${s.company.type === 'type1' ? 'Statistiques par section' : 'Statistiques par équipe & régime'}</h3>
          <div class="grid-3 mb-4">
            ${groupCards.map(sec => {
              const cnt = sec === 'Télétravail'
                ? emps.filter(e => e.telework).length
                : s.company.type === 'type2'
                  ? emps.filter(e => e.shift.includes(sec)).length
                  : emps.filter(e => e.section === sec).length;
              return `<div class="card card-hover" onclick="TP.navigate('stats','index',{section:'${TP.esc(sec)}'})"><div class="flex-between"><strong>${TP.esc(sec)}</strong><span class="pill pill-blue">${cnt} pers.</span></div><div class="muted small mt-2">Cliquer pour consulter les détails ›</div></div>`;
            }).join('')}
          </div>` : ''}
        <div class="table-wrap">
          <table>
            <thead><tr><th>Nom</th><th>Arrivée</th><th>Retard</th><th>Heures</th><th>Sup.</th><th>Fin</th><th>Avis manager</th></tr></thead>
            <tbody>${listRows.map(e => `<tr><td><strong>${TP.esc(e.nom)} ${TP.esc(e.prenom)}</strong></td><td class="num">${e.arrivee}</td><td class="num">${e.retardMin ? e.retardMin + ' min' : '0'}</td><td class="num">${e.heures}</td><td class="num">${e.sup}</td><td class="num">${e.fin}</td><td><span class="pill ${e.managerAvis === 'Favorable' ? 'pill-green' : 'pill-amber'}">${e.managerAvis}</span></td></tr>`).join('')}</tbody>
          </table>
        </div>`}`;
  };

  Object.assign(window.TP_CORE, {
    exportStatsModal() {
      TP.openModal('Exporter les statistiques', `
        <div class="grid-2">
          <button class="choice-card" onclick="TP_CORE.doStatsExport('csv')"><strong>Excel (.CSV)</strong><div class="muted small">Tableur exploitable</div></button>
          <button class="choice-card" onclick="TP_CORE.doStatsExport('txt')"><strong>Fichier Texte (.TXT)</strong><div class="muted small">Rapport lisible</div></button>
          <button class="choice-card" onclick="TP_CORE.doStatsExport('doc')"><strong>Document Word (.DOC)</strong><div class="muted small">Mise en page rapport</div></button>
          <button class="choice-card" onclick="TP.closeModal();window.print();"><strong>PDF / Imprimer</strong><div class="muted small">Impression Linux PDF</div></button>
        </div>`);
    },
    doStatsExport(ext) {
      const rows = ['Nom;Prenom;Section;Statut;Arrivee;Retard_min;Heures'].concat(
        TP.state.employees.map(e => `${e.nom};${e.prenom};${e.section};${e.status};${e.arrivee};${e.retardMin};${e.heures}`)
      ).join('\n');
      TP.closeModal();
      TP.exportFile(`statistiques-tempo-point.${ext}`, rows);
    }
  });
})();

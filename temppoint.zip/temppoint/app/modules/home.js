(function () {
  window.TP_CORE_MODULES = window.TP_CORE_MODULES || {};
  window.TP_CORE = window.TP_CORE || {};

  window.TP_CHARTS = {
    arrivalsSvg(presents, retards) {
      const ptsP = [2, Math.round(presents * 0.35), Math.round(presents * 0.75), presents, presents, presents];
      const ptsR = [0, Math.max(1, Math.round(retards * 0.6)), retards, retards, retards, retards];
      const maxY = Math.max(10, presents + retards + 4);
      const toPath = arr => arr.map((v, i) => `${i === 0 ? 'M' : 'L'}${40 + i * 88},${155 - (v / maxY) * 125}`).join(' ');
      const dots = (arr, col) => arr.map((v, i) => `<circle cx="${40 + i * 88}" cy="${155 - (v / maxY) * 125}" r="4.5" fill="#fff" stroke="${col}" stroke-width="2.5"/>`).join('');
      return `
        <svg viewBox="0 0 520 180" style="width:100%;height:190px;">
          ${[0, 1, 2, 3].map(i => `<line x1="35" y1="${30 + i * 41}" x2="495" y2="${30 + i * 41}" stroke="#E5EDED" stroke-dasharray="3"/>`).join('')}
          <path d="${toPath(ptsP)}" fill="none" stroke="#17525B" stroke-width="3"/>
          <path d="${toPath(ptsR)}" fill="none" stroke="#F59E0B" stroke-width="3"/>
          ${dots(ptsP, '#17525B')}${dots(ptsR, '#F59E0B')}
          ${['07h', '08h', '09h', '10h', '11h', '12h'].map((h, i) => `<text x="${33 + i * 88}" y="174" font-size="11" fill="#6E8488">${h}</text>`).join('')}
        </svg>`;
    }
  };

  window.TP_CORE_MODULES.home = function () {
    const s = TP.state;
    const emps = s.employees;
    const present = emps.filter(e => e.status === 'Présent').length;
    const late = emps.filter(e => e.status === 'Retard').length;
    const absent = emps.filter(e => e.status === 'Absent').length;
    const onlineM = s.machines.filter(m => m.status === 'En ligne').length;
    const newEmails = s.managerEmails.filter(m => m.status === 'Nouveau').length;

    return `
      <div class="flex-between mb-4">
        <div>
          <h1>Bonjour ${TP.esc(s.adminAccount.name.split(' ')[0])}</h1>
          <p class="muted">Voici l'état de ${TP.esc(s.company.name)} · Pilotage centralisé</p>
        </div>
        <div class="flex gap-2">
          <button class="btn btn-outline btn-sm" onclick="TP_CORE.simPunch()">⚡ Simuler un pointage</button>
          <button class="btn btn-amber btn-sm" onclick="TP.navigate('employees','enroll')">+ Inscrire un salarié</button>
        </div>
      </div>

      <div class="grid-4 mb-4">
        <div class="card"><div class="muted small">Présents</div><div class="num" style="font-size:28px;font-weight:800;color:#059669;">${present} / ${emps.length}</div></div>
        <div class="card"><div class="muted small">Retards</div><div class="num" style="font-size:28px;font-weight:800;color:#D97706;">${late}</div></div>
        <div class="card"><div class="muted small">Absents</div><div class="num" style="font-size:28px;font-weight:800;color:#DC2626;">${absent}</div></div>
        <div class="card"><div class="muted small">Machines en ligne</div><div class="num" style="font-size:28px;font-weight:800;color:#0284C7;">${onlineM} / ${s.machines.length}</div></div>
      </div>

      <div class="grid-2" style="grid-template-columns:1.55fr 1fr;">
        <div class="card">
          <div class="flex-between mb-3">
            <h3>Arrivées de la journée</h3>
            <div class="flex gap-3 small"><span style="color:#17525B;font-weight:700;">● Présents</span><span style="color:#F59E0B;font-weight:700;">● Retards</span></div>
          </div>
          ${TP_CHARTS.arrivalsSvg(present + late, late)}
        </div>
        <div class="card">
          <h3 class="mb-3">À traiter</h3>
          <div style="display:flex;flex-direction:column;gap:10px;">
            <button class="choice-card" onclick="TP.navigate('employees','pending')">
              <div class="flex-between"><strong>${s.pendingRegistrations.length} inscriptions à valider</strong><span>›</span></div>
              <div class="muted small">Employés · Intranet & en attente</div>
            </button>
            <button class="choice-card" onclick="TP.navigate('employees','reviews')">
              <div class="flex-between"><strong>${newEmails} avis de managers à traiter</strong><span>›</span></div>
              <div class="muted small">IA · Extraction vers tableaux</div>
            </button>
            ${TP.isModuleEnabled('automation') ? `
            <button class="choice-card" onclick="TP.navigate('automation','approvals')">
              <div class="flex-between"><strong>${s.approvals.filter(a => a.status === 'En attente').length} approbations workflow</strong><span>›</span></div>
              <div class="muted small">Tempo Automation · Validation humaine</div>
            </button>` : ''}
            <button class="choice-card" onclick="TP.navigate('machines','index')">
              <div class="flex-between"><strong>${s.machines.filter(m => m.status !== 'En ligne').length} terminal hors ligne</strong><span>›</span></div>
              <div class="muted small">Quai logistique · Pointage en cache local</div>
            </button>
          </div>
        </div>
      </div>

      <h3 class="mt-4 mb-3">Accès rapide aux modules</h3>
      <div class="grid-4">
        ${[
          ['employees', 'index', 'Gestion des employés', 'Inscription, fiches, salaires, promotions'],
          ['rules', 'index', 'Règles de pointage', 'Horaires, pauses, calendrier, exports'],
          ['projects', 'index', 'Projets & Tâches', 'Phases, jalons, Kanban & Gantt'],
          ['vision', 'index', 'Vision numérique', 'Organigramme, équipements, direction']
        ].map(([rt, sb, t, d]) => `
          <div class="card card-hover" onclick="TP.navigate('${rt}','${sb}')">
            <div style="font-weight:700;">${t}</div>
            <div class="muted small mt-2">${d}</div>
          </div>`).join('')}
      </div>`;
  };

  window.TP_CORE.simPunch = function () {
    const emp = TP.state.employees.find(e => e.status !== 'Présent') || TP.state.employees[1];
    emp.status = 'Présent';
    emp.arrivee = '08:00';
    emp.retardMin = 0;
    emp.heures = '8h00';
    TP.logAction('Modifier', `Pointage simulé · ${emp.nom} ${emp.prenom}`, 'Pointage terminal MP-0001', 'En retard / Absent', 'Présent 08:00', 'Pointage');
    TP.save();
    TP.render();
    TP.toast(`Pointage enregistré pour ${emp.nom} ${emp.prenom}`);
  };
})();

(function () {
  window.TP_EXT_MODULES = window.TP_EXT_MODULES || {};
  window.TP_EXT = window.TP_EXT || {};
  let projectView = 'list';

  window.TP_EXT_MODULES.projects = function () {
    const s = TP.state;
    const selPrjId = TP.ui.params.prjId || null;

    if (selPrjId) {
      const p = s.projects.find(x => x.id === selPrjId) || s.projects[0];
      const tasks = s.tasks.filter(t => t.projectId === p.id);
      const doneCount = tasks.filter(t => t.status === 'Terminée').length;
      const pct = tasks.length ? Math.round((doneCount / tasks.length) * 100) : 0;

      return `
        <div class="flex-between mb-4">
          <div>
            <h1>${TP.esc(p.name)}</h1>
            <p class="muted">${TP.esc(p.section)} · Responsable : ${TP.esc(p.owner)} · ${p.start} → ${p.end}</p>
          </div>
          <div class="flex gap-2">
            <button class="btn btn-outline" onclick="TP.navigate('projects','index')">← Projets</button>
            <button class="btn btn-outline" onclick="TP.navigate('agenda','week')">📅 Voir dans Planning</button>
            <button class="btn btn-amber" onclick="TP_EXT.addTaskModal('${p.id}')">+ Nouvelle tâche</button>
          </div>
        </div>

        <div class="grid-3 mb-4">
          <div class="card">
            <div class="muted small">Avancement global</div>
            <div style="font-size:26px;font-weight:800;">${pct} %</div>
            <div class="progress-track mt-2"><div class="progress-fill" style="width:${pct}%"></div></div>
          </div>
          <div class="card">
            <div class="muted small">Phases & Jalons</div>
            <div class="mt-2" style="display:flex;flex-direction:column;gap:6px;">
              ${p.phases.map((ph, idx) => `
                <label class="flex-between small" style="cursor:pointer;">
                  <span><input type="checkbox" ${ph.done ? 'checked' : ''} onchange="TP_EXT.togglePhase('${p.id}',${idx})"/> ${TP.esc(ph.name)}</span>
                  <span class="pill pill-gray">${TP.esc(ph.milestone)}</span>
                </label>`).join('')}
            </div>
          </div>
          <div class="card">
            <div class="muted small">Budget prévisionnel & Risques</div>
            ${TP.isModuleEnabled('projectBudgets') ? `<div class="mt-1"><strong>${TP.fmtMoney(p.spent)}</strong> / ${TP.fmtMoney(p.budget)}</div>` : '<div class="muted small">Suivi budget désactivé</div>'}
            <div class="small mt-2" style="color:#B45309;">⚠ ${TP.esc(p.risks || 'Aucun risque signalé')}</div>
          </div>
        </div>

        <div class="tabs">
          ${[['list', 'Liste des tâches'], ['kanban', 'Tableau Kanban'], ['gantt', 'Chronologie (Gantt)']].map(([k, l]) => `
            <button class="tab-btn ${projectView === k ? 'active' : ''}" onclick="TP_EXT.setProjectView('${k}')">${l}</button>`).join('')}
        </div>

        ${projectView === 'kanban' ? `
          <div class="kanban-cols">
            ${['À faire', 'En cours', 'En validation', 'Terminée'].map(col => `
              <div class="kanban-col">
                <div class="flex-between mb-3"><strong>${col}</strong><span class="pill pill-gray">${tasks.filter(t => t.status === col).length}</span></div>
                <div style="display:flex;flex-direction:column;gap:10px;">
                  ${tasks.filter(t => t.status === col).map(t => `
                    <div class="card card-hover" style="padding:12px;" onclick="TP_EXT.taskDetailModal('${t.id}')">
                      <span class="pill ${t.priority === 'Critique' ? 'pill-red' : t.priority === 'Haute' ? 'pill-amber' : 'pill-blue'}">${t.priority}</span>
                      <div class="mt-2" style="font-weight:600;">${TP.esc(t.title)}</div>
                      <div class="muted small mt-2">${TP.esc(t.assignee)} · Éch. ${t.due}</div>
                      ${t.blocker ? `<div class="small mt-1" style="color:#DC2626;">⛔ ${TP.esc(t.blocker)}</div>` : ''}
                    </div>`).join('')}
                </div>
              </div>`).join('')}
          </div>` : projectView === 'gantt' ? `
          <div class="card">
            <h3 class="mb-3">Chronologie & Dépendances du projet</h3>
            ${tasks.map((t, i) => `
              <div class="flex-between mb-3" style="gap:16px;">
                <div style="width:260px;flex-shrink:0;"><strong>${TP.esc(t.title)}</strong><div class="muted small">${TP.esc(t.assignee)}</div></div>
                <div style="flex:1;background:#EDF3F3;height:24px;border-radius:8px;position:relative;overflow:hidden;">
                  <div style="position:absolute;left:${(i * 14) % 55}%;width:${Math.max(18, t.hours * 5)}%;top:3px;bottom:3px;border-radius:6px;background:${t.status === 'Terminée' ? '#10B981' : '#0B2E33'};color:#fff;font-size:11px;display:flex;align-items:center;padding:0 8px;">${t.start} → ${t.due}</div>
                </div>
              </div>`).join('')}
          </div>` : `
          <div class="table-wrap">
            <table>
              <thead><tr><th>Tâche</th><th>Responsable</th><th>Priorité</th><th>Statut</th><th>Échéance</th><th></th></tr></thead>
              <tbody>
                ${tasks.map(t => `
                  <tr class="clickable" onclick="TP_EXT.taskDetailModal('${t.id}')">
                    <td><strong>${TP.esc(t.title)}</strong>${t.blocker ? `<div class="small" style="color:#DC2626;">⛔ Bloqué : ${TP.esc(t.blocker)}</div>` : ''}</td>
                    <td>${TP.esc(t.assignee)}</td>
                    <td><span class="pill ${t.priority === 'Critique' ? 'pill-red' : t.priority === 'Haute' ? 'pill-amber' : 'pill-blue'}">${t.priority}</span></td>
                    <td><span class="pill ${t.status === 'Terminée' ? 'pill-green' : 'pill-gray'}">${t.status}</span></td>
                    <td class="num">${t.due}</td>
                    <td><button class="btn btn-outline btn-sm">Gérer</button></td>
                  </tr>`).join('')}
              </tbody>
            </table>
          </div>`}`;
    }

    return `
      <div class="flex-between mb-4">
        <div><h1>Tempo Projet & Tâches</h1><p class="muted">Projets, jalons, tâches et synchronisation directe avec le Planning & Agenda</p></div>
        <div class="flex gap-2">
          <button class="btn btn-outline" onclick="TP.navigate('agenda','month')">📅 Planning unifié</button>
          <button class="btn btn-amber" onclick="TP_EXT.newProjectModal()">+ Nouveau projet</button>
        </div>
      </div>
      <div class="grid-3">
        ${s.projects.map(p => {
          const pTasks = s.tasks.filter(t => t.projectId === p.id);
          const done = pTasks.filter(t => t.status === 'Terminée').length;
          const pct = pTasks.length ? Math.round((done / pTasks.length) * 100) : 0;
          return `
            <div class="card card-hover" onclick="TP.navigate('projects','detail',{prjId:'${p.id}'})">
              <div class="flex-between mb-2">
                <span class="pill ${p.priority === 'Critique' ? 'pill-red' : 'pill-blue'}">${TP.esc(p.section)}</span>
                <span class="pill pill-gray">${p.status}</span>
              </div>
              <h3>${TP.esc(p.name)}</h3>
              <p class="muted small mt-2">${TP.esc(p.objectives)}</p>
              <div class="flex-between mt-3 small"><span>Avancement (${done}/${pTasks.length} tâches)</span><strong>${pct}%</strong></div>
              <div class="progress-track mt-1"><div class="progress-fill" style="width:${pct}%"></div></div>
              <div class="muted small mt-3">Resp. : ${TP.esc(p.owner)} · Fin : ${p.end}</div>
            </div>`;
        }).join('')}
      </div>`;
  };

  Object.assign(window.TP_EXT, {
    setProjectView(v) { projectView = v; TP.render(); },
    togglePhase(pid, idx) {
      const p = TP.state.projects.find(x => x.id === pid);
      p.phases[idx].done = !p.phases[idx].done;
      TP.save(); TP.render();
    },
    newProjectModal() {
      TP.openModal('Nouveau projet', `
        <label class="field-label">Nom du projet</label><input id="np-name" class="input mb-3" placeholder="Ex: Modernisation parc"/>
        <div class="grid-2 mb-3">
          <div><label class="field-label">Service</label><select id="np-sec" class="select">${TP.state.company.sections.map(s => `<option>${TP.esc(s)}</option>`).join('')}</select></div>
          <div><label class="field-label">Responsable</label><input id="np-own" class="input" value="${TP.esc(TP.state.adminAccount.name)}"/></div>
          <div><label class="field-label">Date début</label><input id="np-st" type="date" class="input" value="2026-11-18"/></div>
          <div><label class="field-label">Date fin</label><input id="np-en" type="date" class="input" value="2026-12-15"/></div>
        </div>
        <label class="field-label">Objectifs</label><textarea id="np-obj" class="textarea mb-3"></textarea>
        <button class="btn btn-amber" onclick="TP_EXT.saveNewProject()">Créer le projet</button>`);
    },
    saveNewProject() {
      TP.state.projects.unshift({
        id: 'prj-' + Date.now(), name: document.getElementById('np-name').value || 'Nouveau projet',
        section: document.getElementById('np-sec').value, owner: document.getElementById('np-own').value,
        status: 'En cours', priority: 'Haute', start: document.getElementById('np-st').value, end: document.getElementById('np-en').value,
        budget: 5000000, spent: 0, objectives: document.getElementById('np-obj').value || 'Objectifs définis', risks: '',
        phases: [{ name: 'Phase 1 · Lancement', milestone: 'Fin mois', done: false }]
      });
      TP.logAction('Insérer', 'Nouveau projet créé', 'Tempo Projet', '—', TP.state.projects[0].name, 'Projets');
      TP.closeModal(); TP.save(); TP.render(); TP.toast('Projet créé.');
    },
    addTaskModal(pid) {
      TP.openModal('Nouvelle tâche', `
        <label class="field-label">Titre</label><input id="nt-title" class="input mb-3" placeholder="Ex: Contrôler les relevés"/>
        <div class="grid-2 mb-3">
          <div><label class="field-label">Responsable</label><select id="nt-asg" class="select">${TP.state.employees.map(e => `<option>${TP.esc(e.nom + ' ' + e.prenom)}</option>`).join('')}</select></div>
          <div><label class="field-label">Priorité</label><select id="nt-pri" class="select"><option>Normale</option><option>Haute</option><option>Critique</option></select></div>
          <div><label class="field-label">Échéance</label><input id="nt-due" type="date" class="input" value="2026-11-23"/></div>
          <div><label class="field-label">Charge (h)</label><input id="nt-hrs" type="number" class="input" value="4"/></div>
        </div>
        <button class="btn btn-amber" onclick="TP_EXT.saveTask('${pid}')">Ajouter & synchroniser Agenda</button>`);
    },
    saveTask(pid) {
      TP.state.tasks.unshift({
        id: 'tsk-' + Date.now(), projectId: pid, title: document.getElementById('nt-title').value || 'Tâche sans titre',
        assignee: document.getElementById('nt-asg').value, section: TP.state.company.sections[0],
        priority: document.getElementById('nt-pri').value, status: 'À faire', start: '2026-11-18',
        due: document.getElementById('nt-due').value, hours: +document.getElementById('nt-hrs').value, blocker: '',
        checklist: [{ text: 'Étape initiale', done: false }], comments: []
      });
      TP.closeModal(); TP.save(); TP.render(); TP.toast('Tâche ajoutée et synchronisée dans le Planning.');
    },
    taskDetailModal(tid) {
      const t = TP.state.tasks.find(x => x.id === tid);
      if (!t) return;
      TP.openModal(`Tâche · ${t.title}`, `
        <div class="grid-2 mb-3">
          <div><label class="field-label">Statut</label><select id="td-st" class="select">${['À faire', 'En cours', 'En validation', 'Terminée'].map(s => `<option ${t.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
          <div><label class="field-label">Échéance</label><input id="td-due" type="date" class="input" value="${t.due}"/></div>
        </div>
        <label class="field-label">Signaler un blocage</label><input id="td-blk" class="input mb-3" value="${TP.esc(t.blocker)}" placeholder="Aucun blocage"/>
        <div class="mb-3">
          <label class="field-label">Checklist</label>
          ${(t.checklist || []).map((c, i) => `<label class="flex gap-2 small mt-1"><input type="checkbox" ${c.done ? 'checked' : ''} onchange="TP_EXT.toggleChecklist('${t.id}',${i})"/> ${TP.esc(c.text)}</label>`).join('')}
        </div>
        <button class="btn btn-amber" onclick="TP_EXT.updateTask('${t.id}')">Enregistrer</button>`);
    },
    toggleChecklist(tid, idx) {
      const t = TP.state.tasks.find(x => x.id === tid);
      if (t?.checklist?.[idx]) { t.checklist[idx].done = !t.checklist[idx].done; TP.save(); }
    },
    updateTask(tid) {
      const t = TP.state.tasks.find(x => x.id === tid);
      t.status = document.getElementById('td-st').value;
      t.due = document.getElementById('td-due').value;
      t.blocker = document.getElementById('td-blk').value;
      TP.closeModal(); TP.save(); TP.render(); TP.toast('Tâche mise à jour.');
    }
  });
})();

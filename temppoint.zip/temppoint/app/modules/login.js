(function () {
  window.TP_VIEWS = window.TP_VIEWS || {};

  window.TP_VIEWS.login = function () {
    const s = TP.state;
    return `
      <div class="auth-bg">
        <div class="login-card">
          <div class="wizard-side">
            <div>
              <div class="brand-lockup">
                <div class="brand-badge">${TP.logoSvg(22)}</div>
                <div><div style="font-weight:800;font-size:18px;">Tempo-Point IA</div></div>
              </div>
              <p class="mt-4" style="color:#C2DADF;font-size:15px;">Le pointage, la coordination et le pilotage du personnel, simples et fiables.</p>
            </div>
            <div>
              <div class="small" style="color:#8FB1B6;">${TP.esc(s.company.name)}</div>
              <button class="btn btn-outline btn-sm mt-2" style="background:rgba(255,255,255,0.08);color:#fff;border-color:rgba(255,255,255,0.2);" onclick="TP.ui.phase='install';TP.ui.installStep=1;TP.render();">Reconfigurer l'installation</button>
            </div>
          </div>
          <div style="padding:38px 40px;display:flex;flex-direction:column;justify-content:center;">
            <h1>Connexion</h1>
            <p class="muted mt-2">Accédez à votre espace ${TP.esc(s.company.name)}</p>
            <div class="mt-4">
              <label class="field-label">Mail professionnel</label>
              <input id="login-email" class="input" value="${TP.esc(s.adminAccount.email)}"/>
            </div>
            <div class="mt-3">
              <label class="field-label">Mot de passe</label>
              <input id="login-pass" type="password" class="input" value="${TP.esc(s.adminAccount.password)}"/>
            </div>
            <div class="card mt-3" style="background:#F7FAFA;display:flex;align-items:center;gap:14px;padding:12px;">
              <div style="width:52px;height:44px;border-radius:8px;background:#0B2E33;display:flex;align-items:center;justify-content:center;">
                <div style="width:24px;height:28px;border-radius:50%;border:2px solid #F59E0B;"></div>
              </div>
              <div>
                <strong>Vérification biométrique (${s.currentRole})</strong>
                <div class="mt-1"><span class="pill pill-green">✓ Visage reconnu (simulation locale)</span></div>
              </div>
            </div>
            <button class="btn btn-amber mt-4" style="width:100%;padding:12px;" onclick="TP_LOGIN.doLogin()">Ouvrir Tempo-Point IA</button>
          </div>
        </div>
      </div>`;
  };

  window.TP_LOGIN = {
    doLogin() {
      const mail = document.getElementById('login-email').value.trim();
      const pass = document.getElementById('login-pass').value;
      if (!mail || (pass !== TP.state.adminAccount.password && pass !== 'admin')) {
        return TP.toast('Identifiants invalides (mot de passe configuré : ' + TP.state.adminAccount.password + ').');
      }
      TP.state.loggedIn = true;
      TP.ui.phase = 'app';
      TP.save();
      TP.render();
      TP.toast(`Connecté en tant que ${TP.state.adminAccount.name}`);
    }
  };
})();

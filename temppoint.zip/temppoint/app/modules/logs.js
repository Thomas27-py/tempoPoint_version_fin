(function () {
  window.TP_EXT_MODULES = window.TP_EXT_MODULES || {};
  window.TP_EXT = window.TP_EXT || {};

  window.TP_EXT_MODULES.logs = function () {
    const s = TP.state;
    const tab = TP.ui.sub === 'rules' ? 'rules' : 'all';
    const f = TP.ui.params.act || 'Toutes';
    const list = s.logs.filter(l => f === 'Toutes' || l.action === f);

    return `
      <div class="flex-between mb-4">
        <div><h1>Journaux des activités</h1><p class="muted">Traçabilité complète (Avant / Après / Auteur) de chaque action</p></div>
        <div class="flex gap-2">
          <button class="btn ${tab === 'all' ? 'btn-primary' : 'btn-outline'} btn-sm" onclick="TP.navigate('logs','index')">Journaux globaux</button>
          <button class="btn ${tab === 'rules' ? 'btn-primary' : 'btn-outline'} btn-sm" onclick="TP.navigate('logs','rules')">Journaux · Règles</button>
        </div>
      </div>
      ${tab === 'rules' ? `
        <div class="card">
          ${s.ruleLogs.map(r => `<div class="flex-between mb-3" style="padding:12px;border:1px solid var(--border);border-radius:10px;"><div><strong>${TP.esc(r.label)}</strong><div class="muted small">Par ${TP.esc(r.author)} · ${r.date}</div></div><div><span class="pill pill-red">${TP.esc(r.before)}</span> → <span class="pill pill-green">${TP.esc(r.after)}</span></div></div>`).join('')}
        </div>` : `
        <div class="tabs">${['Toutes', 'Insérer', 'Modifier', 'Supprimer'].map(a => `<button class="tab-btn ${f === a ? 'active' : ''}" onclick="TP.navigate('logs','index',{act:'${a}'})">${a}</button>`).join('')}</div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Date</th><th>Action</th><th>Cible</th><th>Auteur</th><th>Avant → Après</th></tr></thead>
            <tbody>
              ${list.map(l => `
                <tr class="clickable" onclick="TP_EXT.showLogDetail('${l.id}')">
                  <td class="num">${l.date}</td>
                  <td><span class="pill ${l.action === 'Supprimer' ? 'pill-red' : l.action === 'Insérer' ? 'pill-green' : 'pill-amber'}">${l.action}</span></td>
                  <td><strong>${TP.esc(l.target)}</strong></td>
                  <td>${TP.esc(l.author)}</td>
                  <td class="small muted">${TP.esc(l.before)} → ${TP.esc(l.after)}</td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>`}`;
  };

  Object.assign(window.TP_EXT, {
    showLogDetail(id) {
      const l = TP.state.logs.find(x => x.id === id);
      TP.openModal('Détails du journal', `<p><strong>Action :</strong> ${l.action}</p><p class="mt-2"><strong>Cible :</strong> ${TP.esc(l.target)}</p><p class="mt-2"><strong>Auteur :</strong> ${TP.esc(l.author)}</p><p class="mt-2"><strong>Avant :</strong> ${TP.esc(l.before)} → <strong>Après :</strong> ${TP.esc(l.after)}</p>`);
    }
  });
})();

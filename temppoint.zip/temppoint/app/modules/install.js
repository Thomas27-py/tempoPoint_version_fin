(function () {
  window.TP_VIEWS = window.TP_VIEWS || {};
  let captureCount = 0;

  window.TP_VIEWS.install = function () {
    const step = TP.ui.installStep;
    const s = TP.state;
    const c = s.company;
    const stepsLabels = [
      'Identité & Structure',
      'Horaires & Pointage',
      'Modules sur mesure',
      'Hébergement & Cloud',
      'Paiement & Support',
      'Conditions & Rôles',
      'Admin & Biométrie',
      'Application prête'
    ];

    let body = '';
    if (step === 1) {
      const baseSecs = ['Marketing', 'Finance', 'Logistique', 'Informatique', 'RH', 'Production', 'Commercial', 'Qualité'];
      const allSecs = baseSecs.concat(c.sections.filter(x => !baseSecs.includes(x)));
      body = `
        <div>
          <h1>Parlez-nous de votre entreprise</h1>
          <p class="muted mt-2">Ces paramètres adaptent Tempo-Point IA à votre structure dès l'installation.</p>
          <div class="grid-2 mt-4">
            <div>
              <label class="field-label">Type d'organisation</label>
              <select class="select" onchange="TP.state.company.type=this.value;TP.render();">
                <option value="type1" ${c.type === 'type1' ? 'selected' : ''}>Type n°01 · Organisée en sections / services</option>
                <option value="type2" ${c.type === 'type2' ? 'selected' : ''}>Type n°02 · Sans section, planning par calendrier</option>
              </select>
            </div>
            <div>
              <label class="field-label">Nom de l'entreprise</label>
              <input class="input" value="${TP.esc(c.name)}" oninput="TP.state.company.name=this.value"/>
            </div>
            <div>
              <label class="field-label">Secteur d'activité</label>
              <select class="select" onchange="TP.state.company.sector=this.value">
                ${['Primaire (Agriculture, Mines, Pêche)', 'Secondaire (Industrie, Construction)', 'Tertiaire (Commerce, Services, IT)'].map(sec => {
                  const k = sec.split(' ')[0];
                  return `<option value="${k}" ${c.sector === k ? 'selected' : ''}>${sec}</option>`;
                }).join('')}
              </select>
            </div>
            <div>
              <label class="field-label">Sous-secteur métier (sur-mesure)</label>
              <input class="input" value="${TP.esc(c.subSector)}" oninput="TP.state.company.subSector=this.value"/>
            </div>
            <div>
              <label class="field-label">Email officiel</label>
              <input class="input" value="${TP.esc(c.email)}" oninput="TP.state.company.email=this.value"/>
            </div>
            <div class="grid-2">
              <div>
                <label class="field-label">Effectif</label>
                <input type="number" min="1" class="input" value="${c.headcount}" oninput="TP.state.company.headcount=Math.max(1,+this.value);TP.state.company.machinesOrdered=Math.max(1,Math.ceil(TP.state.company.headcount/12));"/>
              </div>
              <div>
                <label class="field-label">Devise & Langue</label>
                <div class="flex gap-2">
                  <select class="select" onchange="TP.state.company.currency=this.value">
                    <option value="Ar" ${c.currency === 'Ar' ? 'selected' : ''}>Ar (MGA)</option>
                    <option value="€" ${c.currency === '€' ? 'selected' : ''}>EUR (€)</option>
                    <option value="$" ${c.currency === '$' ? 'selected' : ''}>USD ($)</option>
                  </select>
                  <select class="select" onchange="TP.state.company.language=this.value">
                    <option value="FR" ${c.language === 'FR' ? 'selected' : ''}>FR</option>
                    <option value="FR+MG" ${c.language === 'FR+MG' ? 'selected' : ''}>FR+MG</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          ${c.type === 'type1' ? `
            <div class="mt-4">
              <label class="field-label">Sections / Services de l'entreprise (${c.sections.length} sélectionnées)</label>
              <div class="flex gap-2" style="flex-wrap:wrap;">
                ${allSecs.map(sec => {
                  const on = c.sections.includes(sec);
                  return `<button type="button" class="pill ${on ? 'pill-amber' : 'pill-gray'}" style="padding:7px 14px;border:1px solid ${on ? '#F59E0B' : '#DCE6E7'};" onclick="TP_INSTALL.toggleSection('${TP.esc(sec)}')">${on ? '✓ ' : ''}${TP.esc(sec)}</button>`;
                }).join('')}
              </div>
              <div class="flex gap-2 mt-2">
                <input id="inst-new-sec" class="input" style="max-width:260px;" placeholder="Ajouter une section personnalisée..."/>
                <button type="button" class="btn btn-amber btn-sm" onclick="TP_INSTALL.addSection()">+ Ajouter</button>
              </div>
            </div>` : `<div class="banner banner-blue mt-4">Type n°02 sélectionné : tout le personnel est suivi dans un planning unifié Jour / Nuit / Repos sans découpage par section.</div>`}
          <div class="mt-3">
            <label class="field-label">Sites & Établissements (séparés par virgule)</label>
            <input class="input" value="${TP.esc(c.sites.join(', '))}" oninput="TP.state.company.sites=this.value.split(',').map(x=>x.trim()).filter(Boolean)"/>
          </div>
        </div>`;
    } else if (step === 2) {
      const rl = s.rules;
      body = `
        <div>
          <h1>Règles de travail & Pointage sur mesure</h1>
          <p class="muted mt-2">Calibrez vos horaires, tolérances, télétravail et retenues automatiques.</p>
          <div class="grid-2 mt-4">
            <div><label class="field-label">Heure d'arrivée standard</label><input type="time" class="input" value="${rl.arrival}" onchange="TP.state.rules.arrival=this.value"/></div>
            <div><label class="field-label">Heure de fin standard</label><input type="time" class="input" value="${rl.departure}" onchange="TP.state.rules.departure=this.value"/></div>
            <div><label class="field-label">Tolérance de retard (minutes)</label><input type="number" class="input" value="${rl.lateTolerance}" oninput="TP.state.rules.lateTolerance=+this.value"/></div>
            <div><label class="field-label">Retenue par minute hors tolérance (${c.currency})</label><input type="number" class="input" value="${rl.latePenaltyPerMin}" oninput="TP.state.rules.latePenaltyPerMin=+this.value"/></div>
          </div>
          <div class="mt-4">
            <label class="field-label">Méthode de pointage principale sur machines</label>
            <div class="grid-2 mt-2">
              ${['Badge + empreinte', 'Badge + mot de passe', 'Badge seul', 'Code PIN + photo'].map(m => `
                <button type="button" class="choice-card ${c.pointingMethod === m ? 'selected' : ''}" onclick="TP.state.company.pointingMethod='${m}';TP.render();">
                  <strong>${m}</strong>
                </button>`).join('')}
            </div>
          </div>
          <div class="card mt-4" style="background:#F8FBFB;">
            <div class="flex-between">
              <div><strong>Connexion à distance / Télétravail autorisé</strong><div class="muted small">Permet le suivi des postes distants dans Statistiques</div></div>
              <div class="switch ${c.teleworkEnabled ? 'on' : ''}" onclick="TP.state.company.teleworkEnabled=!TP.state.company.teleworkEnabled;TP.render();"></div>
            </div>
          </div>
        </div>`;
    } else if (step === 3) {
      const em = s.enabledModules;
      const mods = [
        ['hrDecisions', 'Aide à la décision RH (Import IA Photo/Excel, Avis managers & Promotions)', 'Recommandé'],
        ['payrollDeductions', 'Calcul automatique des salaires & retenues de retard', 'Paie'],
        ['projectsTasks', 'Tempo Projet & Tâches unifié avec Planning & Agenda', 'Coordination'],
        ['projectBudgets', 'Suivi des budgets prévisionnels dans les projets', 'Option'],
        ['automation', 'Tempo Automation (Constructeur visuel de workflows & approbations)', 'Productivité'],
        ['predictive', 'Tableau de bord Prédictif IA (Retards, surcharges, risques projets)', 'Local IA'],
        ['predictiveMalagasy', 'Support bilingue Français / Malagasy dans le tableau prédictif', 'Madagascar'],
        ['digitalVision', 'Vision numérique de toute l\'entreprise (Jumeau organisationnel)', 'Direction'],
        ['tempoApi', 'Tempo API & Portail Développeur (REST, Webhooks, Sandbox)', 'Intégration']
      ];
      body = `
        <div>
          <h1>Sur-mesuration des modules Tempo-Point IA</h1>
          <p class="muted mt-2">Activez uniquement les briques dont votre entreprise a besoin. Vous pourrez ajuster ces choix ensuite.</p>
          <div class="grid-2 mt-4">
            ${mods.map(([k, lbl, tag]) => `
              <div class="choice-card ${em[k] ? 'selected' : ''}" onclick="TP.state.enabledModules['${k}']=!TP.state.enabledModules['${k}'];TP.render();">
                <div class="flex-between">
                  <span class="pill ${em[k] ? 'pill-amber' : 'pill-gray'}">${tag}</span>
                  <input type="checkbox" ${em[k] ? 'checked' : ''} onclick="event.stopPropagation();TP.state.enabledModules['${k}']=this.checked;TP.render();"/>
                </div>
                <div class="mt-2" style="font-weight:600;font-size:13px;">${lbl}</div>
              </div>`).join('')}
          </div>
        </div>`;
    } else if (step === 4) {
      const sc = s.securityCloud;
      const recMachines = Math.max(1, Math.ceil(c.headcount / 12));
      body = `
        <div>
          <h1>Hébergement, Machines & Consentement Cloud</h1>
          <p class="muted mt-2">Aucune donnée n'est envoyée sur le cloud sans votre consentement granulaire explicite.</p>
          <div class="grid-3 mt-4">
            ${[
              ['local', 'Mode Local pur', '100 % sur votre réseau interne. Zéro donnée externe.'],
              ['hybride', 'Hors ligne et en ligne', 'Fonctionne en local + synchro sélective autorisée.'],
              ['cloud', 'En ligne (Serveur Cloud)', 'Hébergé sur nos serveurs chiffrés sans maintenance locale.']
            ].map(([k, t, d]) => `
              <button type="button" class="choice-card ${c.hostingMode === k ? 'selected' : ''}" onclick="TP.state.company.hostingMode='${k}';TP.state.securityCloud.storageMode='${k}';TP.render();">
                <strong>${t}</strong><div class="muted small mt-2">${d}</div>
              </button>`).join('')}
          </div>
          <div class="grid-2 mt-4">
            <div>
              <label class="field-label">Nombre de machines de pointage à déployer</label>
              <input type="number" min="1" class="input" value="${c.machinesOrdered}" oninput="TP.state.company.machinesOrdered=Math.max(1,+this.value)"/>
            </div>
            <div class="banner banner-green" style="margin-top:18px;">Recommandé : ${recMachines} machines pour ${c.headcount} personnes</div>
          </div>
          ${c.hostingMode !== 'local' ? `
            <div class="mt-4">
              <label class="field-label">Consentement Cloud granulaire initial</label>
              <div class="grid-2">
                ${Object.entries(sc.categories).map(([k, cat]) => `
                  <label class="flex-between card" style="padding:10px 12px;cursor:${cat.locked ? 'not-allowed' : 'pointer'};">
                    <span class="small">${cat.label}</span>
                    <input type="checkbox" ${cat.cloud ? 'checked' : ''} ${cat.locked ? 'disabled' : ''} onchange="TP.state.securityCloud.categories['${k}'].cloud=this.checked;"/>
                  </label>`).join('')}
              </div>
            </div>` : ''}
        </div>`;
    } else if (step === 5) {
      const perStaff = (c.headcount * 12000).toLocaleString('fr-FR');
      body = `
        <div>
          <h1>Type de paiement & Accompagnement</h1>
          <p class="muted mt-2">Choisissez la formule adaptée à la taille et aux objectifs de ${TP.esc(c.name)}.</p>
          <div class="mt-4" style="display:flex;flex-direction:column;gap:12px;">
            ${[
              ['Abonnement par personnel', `Facturation proportionnelle à l'effectif (${perStaff} ${c.currency} / mois estimé pour ${c.headcount} salariés).`],
              ['Abonnement global par an', 'Un tarif annuel unique pour toute l\'entreprise, quel que soit l\'effectif.'],
              ['Action de l\'entreprise', 'Pertes et bénéfices : partenariat stratégique (1 % à 2 % de participation).']
            ].map(([p, d]) => `
              <button type="button" class="choice-card ${c.paymentPlan === p ? 'selected' : ''}" onclick="TP.state.company.paymentPlan='${p.replace(/'/g, "\\'")}';TP.render();">
                <strong>${p}</strong><div class="muted small mt-2">${d}</div>
              </button>`).join('')}
          </div>
          <div class="mt-4">
            <label class="field-label">Accompagnement souhaité</label>
            <select class="select" onchange="TP.state.company.supportPackage=this.value">
              ${['Installation sur site + Formation équipes', 'Déploiement à distance + Import Excel', 'Support prioritaire 24/7 + Migration complète'].map(o => `<option ${c.supportPackage === o ? 'selected' : ''}>${o}</option>`).join('')}
            </select>
          </div>
        </div>`;
    } else if (step === 6) {
      body = `
        <div>
          <h1>Conditions, Gouvernance & Premier Compte</h1>
          <p class="muted mt-2">Validez les conditions légales et personnalisez le premier rôle administrateur.</p>
          <div class="card mt-3" style="background:#F7FAFA;">
            <div>1. Utilisation du logiciel Tempo-Point IA Linux</div>
            <div class="mt-2">2. Traitement des données du personnel & consentement cloud révocable</div>
            <div class="mt-2">3. Confidentialité stricte & protection renforcée des gabarits biométriques</div>
            <div class="mt-2">4. Facturation, sauvegarde locale & restitution complète</div>
          </div>
          <div class="mt-3" style="display:flex;flex-direction:column;gap:8px;">
            <label class="flex gap-2"><input type="checkbox" id="chk-c1" checked/> J'accepte toutes les conditions générales</label>
            <label class="flex gap-2"><input type="checkbox" id="chk-c2" checked/> J'autorise le traitement local sécurisé des données biométriques</label>
            <label class="flex gap-2"><input type="checkbox" id="chk-c3" checked/> Je confirme l'exactitude des informations saisies</label>
          </div>
          <div class="mt-4">
            <label class="field-label">Premier compte utilisateur</label>
            <div class="grid-4 mt-2">
              ${[['PDG', 'Président-directeur général'], ['DRH', 'Dir. ressources humaines'], ['DG', 'Directeur général'], ['SG', 'Secrétaire général']].map(([r, l]) => `
                <button type="button" class="choice-card ${s.currentRole === r ? 'selected' : ''}" onclick="TP.state.currentRole='${r}';TP.render();">
                  <strong>${r}</strong><div class="muted small">${l}</div>
                </button>`).join('')}
            </div>
          </div>
        </div>`;
    } else if (step === 7) {
      const adm = s.adminAccount;
      body = `
        <div>
          <h1>Compte Administrateur & Biométrie Faciale</h1>
          <p class="muted mt-2">Sécurisez le compte ${s.currentRole} avec mot de passe et reconnaissance faciale.</p>
          <div class="grid-2 mt-4">
            <div>
              <div class="mb-3"><label class="field-label">Nom et prénom</label><input class="input" value="${TP.esc(adm.name)}" oninput="TP.state.adminAccount.name=this.value"/></div>
              <div class="mb-3"><label class="field-label">Mail professionnel</label><input class="input" value="${TP.esc(adm.email)}" oninput="TP.state.adminAccount.email=this.value"/></div>
              <div class="mb-3"><label class="field-label">Téléphone</label><input class="input" value="${TP.esc(adm.phone)}" oninput="TP.state.adminAccount.phone=this.value"/></div>
              <div><label class="field-label">Mot de passe</label><input type="password" class="input" value="${TP.esc(adm.password)}" oninput="TP.state.adminAccount.password=this.value"/></div>
            </div>
            <div class="card" style="background:#0B2E33;color:#fff;text-align:center;display:flex;flex-direction:column;justify-content:center;align-items:center;">
              <div style="width:140px;height:140px;border-radius:50%;border:3px solid ${captureCount >= 5 ? '#10B981' : '#F59E0B'};display:flex;align-items:center;justify-content:center;background:#103F46;position:relative;">
                <div style="width:62px;height:62px;border-radius:50%;background:rgba(255,255,255,0.18);"></div>
                <span class="pill ${captureCount >= 5 ? 'pill-green' : 'pill-amber'}" style="position:absolute;bottom:-10px;">${captureCount} / 5 captures</span>
              </div>
              <div class="mt-4 small" style="color:#B4D0D4;">Enregistrement facial du compte ${s.currentRole} (simulation sécurisée locale)</div>
              <button type="button" class="btn btn-amber btn-sm mt-3" onclick="TP_INSTALL.captureFace()">
                ${captureCount >= 5 ? '✓ Visage enregistré (Refaire)' : 'Capturer angle du visage (+1)'}
              </button>
            </div>
          </div>
        </div>`;
    } else {
      body = `
        <div style="text-align:center;padding:12px 0;">
          <div style="width:68px;height:68px;border-radius:50%;background:#D1FAE5;color:#059669;display:inline-flex;align-items:center;justify-content:center;font-size:30px;font-weight:800;">✓</div>
          <h1 class="mt-3">Tempo-Point IA est installé sur mesure !</h1>
          <p class="muted mt-2">Votre application Linux est configurée et prête à fonctionner.</p>
          <div class="card mt-4" style="text-align:left;max-width:620px;margin:18px auto 0;">
            <div class="flex-between"><span>Entreprise</span><strong>${TP.esc(c.name)} (${c.type === 'type1' ? c.sections.length + ' sections' : 'Sans section'})</strong></div>
            <div class="flex-between mt-2"><span>Pointage & Machines</span><strong>${TP.esc(c.pointingMethod)} · ${c.machinesOrdered} machines</strong></div>
            <div class="flex-between mt-2"><span>Hébergement & Sécurité</span><strong>${c.hostingMode.toUpperCase()} · Consentement granulaire actif</strong></div>
            <div class="flex-between mt-2"><span>Modules sur mesure</span><strong>${Object.values(s.enabledModules).filter(Boolean).length} / 9 activés</strong></div>
            <div class="flex-between mt-2"><span>Compte principal</span><strong>${TP.esc(s.adminAccount.name)} (${s.currentRole})</strong></div>
          </div>
        </div>`;
    }

    return `
      <div class="auth-bg">
        <div class="wizard-card">
          <div class="wizard-side">
            <div>
              <div class="brand-lockup">
                <div class="brand-badge">${TP.logoSvg(22)}</div>
                <div>
                  <div style="font-weight:800;font-size:17px;">Tempo-Point IA</div>
                  <div style="font-size:11.5px;color:#8BB0B5;">Assistant d'installation sur mesure</div>
                </div>
              </div>
              <div class="wizard-steps">
                ${stepsLabels.map((lbl, idx) => {
                  const n = idx + 1;
                  const cls = n === step ? 'active' : n < step ? 'done' : '';
                  return `<div class="w-step ${cls}"><div class="w-step-num">${n < step ? '✓' : n}</div><span>${lbl}</span></div>`;
                }).join('')}
              </div>
            </div>
            <div style="font-size:11.5px;color:#789EA4;">Version 1.0 Linux · Configuration locale persistante</div>
          </div>
          <div class="wizard-body">
            ${body}
            <div class="wizard-footer">
              ${step > 1 && step < 8 ? `<button class="btn btn-outline" onclick="TP.ui.installStep--;TP.render();">← Retour</button>` : '<div></div>'}
              ${step < 7 ? `<button class="btn btn-primary" onclick="TP_INSTALL.next()">Suivant →</button>`
                : step === 7 ? `<button class="btn btn-amber" onclick="TP_INSTALL.finishBuild()">Créer mon application sur mesure →</button>`
                : `<button class="btn btn-amber" onclick="TP_INSTALL.launchApp()">Ouvrir Tempo-Point IA</button>`}
            </div>
          </div>
        </div>
      </div>`;
  };

  window.TP_INSTALL = {
    toggleSection(sec) {
      const arr = TP.state.company.sections;
      const i = arr.indexOf(sec);
      if (i >= 0 && arr.length > 1) arr.splice(i, 1);
      else if (i < 0) arr.push(sec);
      TP.render();
    },
    addSection() {
      const inp = document.getElementById('inst-new-sec');
      const v = (inp?.value || '').trim();
      if (!v) return;
      if (!TP.state.company.sections.includes(v)) TP.state.company.sections.push(v);
      TP.render();
    },
    next() {
      if (TP.ui.installStep === 6) {
        if (!document.getElementById('chk-c1')?.checked || !document.getElementById('chk-c2')?.checked) {
          return TP.toast('Veuillez accepter les conditions et l\'autorisation biométrique.');
        }
      }
      TP.ui.installStep++;
      TP.render();
    },
    captureFace() {
      captureCount = captureCount >= 5 ? 1 : captureCount + 1;
      TP.state.adminAccount.faceRegistered = captureCount >= 5;
      TP.render();
      if (captureCount === 5) TP.toast('5 angles faciaux enregistrés localement.');
    },
    finishBuild() {
      TP.openModal('Création de votre application sur mesure', `
        <div id="build-sim">
          <p class="muted mb-3">Application des règles, modules et ${TP.state.company.machinesOrdered} machines...</p>
          <div class="progress-track"><div id="build-bar" class="progress-fill" style="width:15%;background:#F59E0B;"></div></div>
          <div id="build-txt" class="mt-3 small">1/4 · Initialisation de la base locale...</div>
        </div>`);
      const steps = [
        [40, '2/4 · Application du type et des règles de pointage...'],
        [75, '3/4 · Activation des modules sur mesure et consentements...'],
        [100, '4/4 · Provisionnement simulé des terminaux terminé !']
      ];
      steps.forEach(([pct, msg], idx) => {
        setTimeout(() => {
          const b = document.getElementById('build-bar');
          const t = document.getElementById('build-txt');
          if (b) b.style.width = pct + '%';
          if (t) t.textContent = msg;
          if (idx === steps.length - 1) {
            setTimeout(() => {
              TP.closeModal();
              TP.state.installed = true;
              TP.ui.installStep = 8;
              TP.save();
              TP.render();
            }, 450);
          }
        }, (idx + 1) * 450);
      });
    },
    launchApp() {
      TP.state.installed = true;
      TP.state.loggedIn = true;
      TP.ui.phase = 'app';
      TP.logAction('Insérer', `Installation complète · ${TP.state.company.name}`, 'Déploiement initial', 'Non installé', 'Configuré sur mesure', 'Système');
      TP.save();
      TP.render();
      TP.toast('Bienvenue dans Tempo-Point IA !');
    }
  };
})();

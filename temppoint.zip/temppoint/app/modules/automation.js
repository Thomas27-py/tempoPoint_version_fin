(function () {
  window.TP_EXT_MODULES = window.TP_EXT_MODULES || {};
  window.TP_EXT = window.TP_EXT || {};

  window.TP_EXT_MODULES.automation = function () {
    const s = TP.state;
    const tab = TP.ui.sub === 'index' ? 'scenarios' : TP.ui.sub;
    return `
      <div class="flex-between mb-4">
        <div><h1>Tempo Automation</h1><p class="muted">Automatisation des processus métier avec validation humaine sur actions sensibles</p></div>
        <button class="btn btn-amber" onclick="TP.navigate('automation','builder')">+ Créer un scénario</button>
      </div>
      <div class="tabs">
        ${[['scenarios', 'Scénarios (' + s.automations.length + ')'], ['builder', 'Constructeur visuel'], ['approvals', 'Circuit d\'approbations (' + s.approvals.filter(a => a.status === 'En attente').length + ')'], ['logs', 'Historique & Erreurs']].map(([k, l]) => `
          <button class="tab-btn ${tab === k ? 'active' : ''}" onclick="TP.navigate('automation','${k}')">${l}</button>`).join('')}
      </div>

      ${tab === 'builder' ? `
        <div class="card">
          <h3 class="mb-3">Constructeur visuel : Déclencheur → Conditions → Actions → Résultat</h3>
          <div class="grid-3">
            <div><label class="field-label">1. Déclencheur (Événement / Date)</label><select id="aut-trg" class="select"><option>Nouvelle inscription validée</option><option>Absence ou retard détecté</option><option>Échéance tâche J-2</option><option>Date mensuelle (25 du mois)</option><option>Document arrivé à expiration</option></select></div>
            <div><label class="field-label">2. Condition</label><select id="aut-cnd" class="select"><option>Toutes sections</option><option>Priorité Critique / Haute</option><option>Retard cumulé > 30 min</option><option>Service Logistique / Finance</option></select></div>
            <div><label class="field-label">3. Action automatique</label><select id="aut-act" class="select" onchange="TP_EXT.checkSensitive(this.value)"><option>Créer une tâche + Notifier responsable</option><option>Ajouter un événement dans Agenda</option><option>Préparer calcul paie / retenue RH</option><option>Appeler Webhook API externe</option></select></div>
          </div>
          <div class="mt-3"><label class="field-label">Nom du scénario</label><input id="aut-name" class="input" placeholder="Ex: Alerte retard récurrent"/></div>
          <div id="aut-guard" class="banner banner-amber mt-3" style="display:none;">⚠ Action sensible détectée : une validation humaine explicite sera obligatoirement exigée avant application.</div>
          <button class="btn btn-amber mt-4" onclick="TP_EXT.saveAutomation()">✓ Activer ce workflow</button>
        </div>` : tab === 'approvals' ? `
        <div style="display:flex;flex-direction:column;gap:12px;">
          ${s.approvals.map(a => `
            <div class="card">
              <div class="flex-between">
                <div><strong>${TP.esc(a.workflow)}</strong><div class="muted small">Demandé le ${a.requestedAt}</div></div>
                <span class="pill ${a.status === 'Approuvée' ? 'pill-green' : a.status === 'Refusée' ? 'pill-red' : 'pill-amber'}">${a.status}</span>
              </div>
              <p class="mt-2">${TP.esc(a.detail)}</p>
              ${a.status === 'En attente' ? `
                <div class="flex gap-2 mt-3">
                  <input id="apr-c-${a.id}" class="input" placeholder="Commentaire de validation..."/>
                  <button class="btn btn-success btn-sm" onclick="TP_EXT.decideApproval('${a.id}','Approuvée')">Approuver</button>
                  <button class="btn btn-danger btn-sm" onclick="TP_EXT.decideApproval('${a.id}','Refusée')">Refuser</button>
                </div>` : `<div class="muted small mt-2">Commentaire : ${TP.esc(a.comment || '—')}</div>`}
            </div>`).join('')}
        </div>` : tab === 'logs' ? `
        <div class="table-wrap">
          <table>
            <thead><tr><th>Date</th><th>Scénario</th><th>Statut</th><th>Détail</th><th></th></tr></thead>
            <tbody>
              ${s.automationLogs.map((l, i) => `
                <tr>
                  <td class="num">${l.date}</td><td><strong>${TP.esc(l.scenario)}</strong></td>
                  <td><span class="pill ${l.status === 'Succès' ? 'pill-green' : 'pill-red'}">${l.status}</span></td>
                  <td>${TP.esc(l.note)}</td>
                  <td>${l.status !== 'Succès' ? `<button class="btn btn-outline btn-sm" onclick="TP_EXT.retryAutoLog(${i})">↻ Relancer</button>` : ''}</td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>` : `
        <div style="display:flex;flex-direction:column;gap:12px;">
          ${s.automations.map(a => `
            <div class="card">
              <div class="flex-between">
                <div>
                  <div class="flex gap-2"><strong>${TP.esc(a.name)}</strong>${a.sensitive ? '<span class="pill pill-amber">Validation humaine requise</span>' : ''}</div>
                  <div class="muted small mt-1">Si <strong>${TP.esc(a.trigger)}</strong> & (${TP.esc(a.condition)}) → <strong>${TP.esc(a.action)}</strong></div>
                </div>
                <div class="flex gap-3">
                  <button class="btn btn-outline btn-sm" onclick="TP_EXT.testAutomation('${a.id}')">▶ Simuler</button>
                  <div class="switch ${a.active ? 'on' : ''}" onclick="TP_EXT.toggleAutomation('${a.id}')"></div>
                </div>
              </div>
              <div class="muted small mt-2">Exécutions : ${a.runs} · Dernière : ${a.lastRun}</div>
            </div>`).join('')}
        </div>`}`;
  };

  Object.assign(window.TP_EXT, {
    checkSensitive(val) {
      const g = document.getElementById('aut-guard');
      if (g) g.style.display = val.includes('paie') ? 'flex' : 'none';
    },
    saveAutomation() {
      const act = document.getElementById('aut-act').value;
      const sens = act.includes('paie');
      TP.state.automations.unshift({
        id: 'aut-' + Date.now(), name: document.getElementById('aut-name').value || 'Nouveau workflow',
        active: true, sensitive: sens, trigger: document.getElementById('aut-trg').value,
        condition: document.getElementById('aut-cnd').value, action: act + (sens ? ' (Validation humaine obligatoire)' : ''),
        runs: 0, lastRun: 'Jamais'
      });
      TP.save(); TP.navigate('automation', 'scenarios'); TP.toast('Scénario automatisé enregistré.');
    },
    toggleAutomation(id) { const a = TP.state.automations.find(x => x.id === id); a.active = !a.active; TP.save(); TP.render(); },
    testAutomation(id) {
      const a = TP.state.automations.find(x => x.id === id);
      a.runs++; a.lastRun = 'À l\'instant';
      TP.state.automationLogs.unshift({ date: 'À l\'instant', scenario: a.name, status: 'Succès', note: a.sensitive ? 'Demande envoyée dans Circuit d\'approbations' : 'Action exécutée avec succès' });
      if (a.sensitive) TP.state.approvals.unshift({ id: 'apr-' + Date.now(), workflow: a.name, detail: 'Simulation déclenchée manuellement nécessitant accord humain.', requestedAt: 'À l\'instant', status: 'En attente', comment: '' });
      TP.save(); TP.render(); TP.toast(`Simulation exécutée : ${a.name}`);
    },
    decideApproval(id, dec) {
      const a = TP.state.approvals.find(x => x.id === id);
      a.status = dec; a.comment = document.getElementById('apr-c-' + id)?.value || '';
      TP.logAction('Modifier', `Workflow ${dec} : ${a.workflow}`, a.comment || 'Circuit d\'approbation', 'En attente', dec, 'Automation');
      TP.save(); TP.render(); TP.toast(`Demande ${dec.toLowerCase()}.`);
    },
    retryAutoLog(idx) { TP.state.automationLogs[idx].status = 'Succès'; TP.state.automationLogs[idx].note = 'Relance réussie.'; TP.save(); TP.render(); TP.toast('Scénario relancé.'); }
  });
})();

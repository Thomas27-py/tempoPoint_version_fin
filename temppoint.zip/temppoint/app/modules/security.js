(function () {
  window.TP_EXT_MODULES = window.TP_EXT_MODULES || {};
  window.TP_EXT = window.TP_EXT || {};

  window.TP_EXT_MODULES.security = function () {
    const sc = TP.state.securityCloud;
    return `
      <div class="flex-between mb-4">
        <div><h1>Tempo Sécurité & Cloud à consentement</h1><p class="muted">Aucune donnée n'est envoyée sur le cloud sans votre consentement explicite, daté et révocable</p></div>
        <div class="flex gap-2">
          <button class="btn btn-outline" onclick="TP_EXT.exportFullRestitution()">⬇ Restitution complète (.JSON)</button>
          ${sc.storageMode !== 'local' ? `<button class="btn btn-danger" onclick="TP_EXT.revokeAllCloud()">Révoquer & Purger copies Cloud</button>` : ''}
        </div>
      </div>

      <div class="grid-3 mb-4">
        ${[
          ['local', 'Mode Local pur', 'Les données restent uniquement sur votre infrastructure Linux.'],
          ['hybride', 'Mode Hybride', 'Seules les catégories cochées ci-dessous sont synchronisées.'],
          ['cloud', 'Mode Cloud activé', 'Sauvegarde distante chiffrée selon votre sélection.']
        ].map(([m, t, d]) => `
          <button class="choice-card ${sc.storageMode === m ? 'selected' : ''}" onclick="TP_EXT.setStorageMode('${m}')">
            <strong>${t}</strong><div class="muted small mt-2">${d}</div>
          </button>`).join('')}
      </div>

      <div class="grid-2">
        <div class="card">
          <div class="flex-between mb-3">
            <h3>Consentement granulaire par catégorie</h3>
            <span class="small muted">Maj : ${sc.lastConsentDate}</span>
          </div>
          ${Object.entries(sc.categories).map(([k, cat]) => `
            <div class="flex-between mb-2" style="padding:10px;border:1px solid var(--border);border-radius:10px;">
              <div>
                <div style="font-weight:600;font-size:13px;">${TP.esc(cat.label)}</div>
                <div class="muted small">${cat.locked ? 'Protection juridique & technique renforcée' : 'Statut : ' + (cat.cloud && sc.storageMode !== 'local' ? 'Synchronisé' : 'Local uniquement')}</div>
              </div>
              <div class="switch ${cat.cloud && sc.storageMode !== 'local' && !cat.locked ? 'on' : ''}" style="${cat.locked || sc.storageMode === 'local' ? 'opacity:0.4;cursor:not-allowed;' : ''}" onclick="${cat.locked || sc.storageMode === 'local' ? '' : `TP_EXT.toggleCloudCat('${k}')`}"></div>
            </div>`).join('')}
        </div>

        <div style="display:flex;flex-direction:column;gap:16px;">
          <div class="card">
            <h3 class="mb-3">Tableau de contrôle & Sécurité</h3>
            <div class="flex-between mb-2"><span>Chiffrement transfert & repos</span><span class="pill pill-green">TLS 1.3 + AES-256 actif</span></div>
            <div class="flex-between mb-2"><span>Authentification multifacteur (MFA)</span><div class="switch ${sc.mfaRequired ? 'on' : ''}" onclick="TP.state.securityCloud.mfaRequired=!TP.state.securityCloud.mfaRequired;TP.save();TP.render();"></div></div>
            <div class="flex-between"><span>Durée de rétention</span>
              <select class="select" style="width:140px;" onchange="TP.state.securityCloud.retentionYears=+this.value;TP.save();">
                ${[1, 3, 5, 10].map(y => `<option value="${y}" ${sc.retentionYears === y ? 'selected' : ''}>${y} an(s)</option>`).join('')}
              </select>
            </div>
          </div>
          <div class="card">
            <h3 class="mb-3">Alertes & Détection d'anomalies</h3>
            ${sc.securityAlerts.map(al => `
              <div class="mb-2" style="padding:10px;border:1px solid var(--border);border-radius:10px;">
                <div class="flex-between"><span class="pill ${al.status === 'Résolu' ? 'pill-green' : 'pill-amber'}">${al.severity} · ${al.status}</span><span class="small muted">${al.date}</span></div>
                <div class="small mt-2">${TP.esc(al.msg)}</div>
                ${al.status !== 'Résolu' ? `<button class="btn btn-outline btn-sm mt-2" onclick="TP_EXT.resolveSecAlert('${al.id}')">Marquer résolu</button>` : ''}
              </div>`).join('')}
          </div>
        </div>
      </div>`;
  };

  Object.assign(window.TP_EXT, {
    setStorageMode(m) {
      TP.state.securityCloud.storageMode = m;
      TP.state.company.hostingMode = m;
      TP.state.securityCloud.lastConsentDate = 'À l\'instant';
      TP.logAction('Modifier', `Mode stockage → ${m}`, 'Tempo Sécurité', 'Précédent', m, 'Sécurité');
      TP.save(); TP.render(); TP.toast(`Mode stockage : ${m}`);
    },
    toggleCloudCat(k) {
      const cat = TP.state.securityCloud.categories[k];
      cat.cloud = !cat.cloud;
      TP.state.securityCloud.lastConsentDate = 'À l\'instant';
      TP.logAction('Modifier', `Consentement cloud · ${cat.label}`, 'Consentement granulaire', !cat.cloud ? 'Oui' : 'Non', cat.cloud ? 'Oui' : 'Non', 'Sécurité');
      TP.save(); TP.render();
    },
    revokeAllCloud() {
      Object.values(TP.state.securityCloud.categories).forEach(c => { if (!c.locked) c.cloud = false; });
      TP.state.securityCloud.storageMode = 'local';
      TP.state.company.hostingMode = 'local';
      TP.logAction('Modifier', 'Révocation complète des copies Cloud', 'Tempo Sécurité', 'Cloud/Hybride', 'Local pur', 'Sécurité');
      TP.save(); TP.render(); TP.toast('Consentements révoqués, synchronisation arrêtée et copies cloud purgées.');
    },
    exportFullRestitution() { TP.exportFile('restitution-complete-tempo-point.json', JSON.stringify(TP.state, null, 2)); },
    resolveSecAlert(id) { TP.state.securityCloud.securityAlerts.find(x => x.id === id).status = 'Résolu'; TP.save(); TP.render(); }
  });
})();

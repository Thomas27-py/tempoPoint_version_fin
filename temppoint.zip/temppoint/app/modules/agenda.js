(function () {
  window.TP_EXT_MODULES = window.TP_EXT_MODULES || {};
  window.TP_EXT = window.TP_EXT || {};
  let agendaView = 'month';
  let draggedItem = null;

  window.TP_EXT_MODULES.agenda = function () {
    const s = TP.state;
    const personalOnly = TP.ui.params.personal === true;
    const myName = s.adminAccount.name;

    const allItems = [
      ...s.events.map(e => ({ kind: 'event', id: e.id, title: e.title, date: e.date, sub: e.time + ' · ' + e.place, owner: e.section, color: e.color === 'red' ? '#FEE2E2;color:#DC2626' : e.color === 'green' ? '#D1FAE5;color:#059669' : '#E0F2FE;color:#0284C7' })),
      ...s.tasks.map(t => ({ kind: 'task', id: t.id, title: '☑ ' + t.title, date: t.due, sub: t.priority + ' · ' + t.hours + 'h', owner: t.assignee, color: '#FEF3C7;color:#B45309' }))
    ].filter(it => !personalOnly || it.owner.includes(myName) || it.owner === 'Toute l\'entreprise');

    const workload = {};
    s.tasks.filter(t => t.status !== 'Terminée').forEach(t => {
      workload[t.assignee] = (workload[t.assignee] || 0) + t.hours;
    });
    const overloads = Object.entries(workload).filter(([, h]) => h > 8);

    return `
      <div class="flex-between mb-4">
        <div><h1>Planning & Agenda unifiés</h1><p class="muted">Réunions, événements, jalons projets et tâches · Glisser-déposer pour replanifier</p></div>
        <div class="flex gap-2">
          <button class="btn ${personalOnly ? 'btn-primary' : 'btn-outline'} btn-sm" onclick="TP.navigate('agenda','${agendaView}',{personal:${!personalOnly}})">${personalOnly ? 'Vue Personnelle' : 'Vue Manager (Tout)'}</button>
          <button class="btn btn-amber btn-sm" onclick="TP_EXT.newEventModal()">+ Ajouter événement</button>
        </div>
      </div>

      ${overloads.length ? `<div class="banner banner-amber mb-3">⚠ Chevauchement / charge élevée détectée : ${overloads.map(([n, h]) => `${n} (${h}h actives)`).join(', ')}</div>` : ''}

      <div class="tabs">
        ${[['month', 'Mois (Novembre 2026)'], ['week', 'Semaine'], ['load', 'Charge & Emplois du temps']].map(([k, l]) => `
          <button class="tab-btn ${agendaView === k ? 'active' : ''}" onclick="TP_EXT.setAgendaView('${k}')">${l}</button>`).join('')}
      </div>

      ${agendaView === 'load' ? `
        <div class="grid-2">
          <div class="card">
            <h3 class="mb-3">Charge des tâches par collaborateur</h3>
            ${Object.entries(workload).map(([person, hrs]) => `
              <div class="mb-3">
                <div class="flex-between small"><strong>${TP.esc(person)}</strong><span>${hrs} h planifiées</span></div>
                <div class="progress-track mt-1"><div class="progress-fill" style="width:${Math.min(100, hrs * 10)}%;background:${hrs > 8 ? '#EF4444' : '#0B2E33'}"></div></div>
              </div>`).join('')}
          </div>
          <div class="card">
            <h3 class="mb-3">Emplois du temps des équipes</h3>
            ${s.company.sections.map(sec => `
              <div class="flex-between mb-2" style="padding:10px;border:1px solid var(--border);border-radius:10px;">
                <strong>${TP.esc(sec)}</strong>
                <span class="pill pill-blue">${s.rules.arrival} – ${s.rules.departure}</span>
              </div>`).join('')}
          </div>
        </div>` : `
        <div class="cal-grid">
          ${['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map(d => `<div style="font-weight:700;text-align:center;color:var(--text-muted);font-size:12px;">${d}</div>`).join('')}
          ${Array.from({ length: agendaView === 'week' ? 7 : 30 }, (_, idx) => {
            const dayNum = agendaView === 'week' ? idx + 16 : idx + 1;
            const iso = `2026-11-${String(dayNum).padStart(2, '0')}`;
            const dayItems = allItems.filter(it => it.date === iso);
            return `
              <div class="cal-cell" ondragover="event.preventDefault();this.classList.add('drag-over')" ondragleave="this.classList.remove('drag-over')" ondrop="TP_EXT.dropOnDay(event,'${iso}')">
                <div class="flex-between"><strong class="small">${dayNum} Nov</strong></div>
                ${dayItems.map(it => `
                  <div class="cal-chip" draggable="true" ondragstart="TP_EXT.dragStart('${it.kind}','${it.id}')" style="background:${it.color};" onclick="TP_EXT.clickAgendaItem('${it.kind}','${it.id}')" title="${TP.esc(it.title)} (${TP.esc(it.sub)})">
                    ${TP.esc(it.title)}
                  </div>`).join('')}
              </div>`;
          }).join('')}
        </div>`}`;
  };

  Object.assign(window.TP_EXT, {
    setAgendaView(v) { agendaView = v; TP.render(); },
    dragStart(kind, id) { draggedItem = { kind, id }; },
    dropOnDay(ev, isoDate) {
      ev.preventDefault();
      if (!draggedItem) return;
      if (draggedItem.kind === 'task') {
        const t = TP.state.tasks.find(x => x.id === draggedItem.id);
        if (t) t.due = isoDate;
      } else {
        const e = TP.state.events.find(x => x.id === draggedItem.id);
        if (e) e.date = isoDate;
      }
      draggedItem = null;
      TP.save(); TP.render(); TP.toast(`Replanifié au ${isoDate}`);
    },
    clickAgendaItem(kind, id) {
      if (kind === 'task') return TP_EXT.taskDetailModal(id);
      const e = TP.state.events.find(x => x.id === id);
      if (e) TP.openModal(e.title, `<p>${e.date} · ${e.time}</p><p class="mt-2 muted">Lieu : ${TP.esc(e.place)} · Section : ${TP.esc(e.section)}</p>`);
    },
    newEventModal() {
      TP.openModal('Ajouter un événement', `
        <label class="field-label">Titre</label><input id="ev-t" class="input mb-3" placeholder="Réunion d'équipe"/>
        <div class="grid-2 mb-3">
          <div><label class="field-label">Date</label><input id="ev-d" type="date" class="input" value="2026-11-21"/></div>
          <div><label class="field-label">Horaire</label><input id="ev-tm" class="input" value="10:00 – 11:30"/></div>
        </div>
        <label class="field-label">Lieu</label><input id="ev-pl" class="input mb-3" value="Salle de réunion"/>
        <button class="btn btn-amber" onclick="TP_EXT.saveEvent()">Ajouter à l'Agenda</button>`);
    },
    saveEvent() {
      TP.state.events.push({ id: 'ev-' + Date.now(), title: document.getElementById('ev-t').value || 'Réunion', date: document.getElementById('ev-d').value, time: document.getElementById('ev-tm').value, type: 'Réunion', section: 'Toute l\'entreprise', place: document.getElementById('ev-pl').value, reminder: '1h avant', color: 'blue' });
      TP.closeModal(); TP.save(); TP.render(); TP.toast('Événement ajouté.');
    }
  });
})();

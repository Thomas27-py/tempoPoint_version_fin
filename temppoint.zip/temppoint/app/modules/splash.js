(function () {
  window.TP_VIEWS = window.TP_VIEWS || {};

  window.TP_VIEWS.splash = function () {
    if (TP._splashTimer) clearTimeout(TP._splashTimer);
    TP._splashTimer = setTimeout(() => {
      if (TP.ui.phase === 'splash') TP.finishSplash();
    }, 3900);

    return `
      <div id="splash-screen" class="splash-screen">
        <div class="splash-rings">
          <div class="splash-ring r1"></div>
          <div class="splash-ring r2"></div>
          <div class="splash-ring r3"></div>
        </div>
        <div class="splash-stage">
          <svg class="splash-emblem" viewBox="0 0 128 128">
            <rect class="svg-draw-box" x="10" y="10" width="108" height="108" rx="26" fill="transparent" stroke="#F59E0B" stroke-width="5"/>
            <g class="svg-draw-crown">
              <rect x="52" y="24" width="24" height="8" rx="4" fill="#0B2E33"/>
              <rect x="61" y="30" width="6" height="8" fill="#0B2E33"/>
            </g>
            <circle class="svg-draw-dial" cx="64" cy="69" r="30" fill="none" stroke="#0B2E33" stroke-width="8" stroke-linecap="round"/>
            <g class="svg-hand-sweep">
              <path d="M64 49V69L78 78" fill="none" stroke="#0B2E33" stroke-width="7.5" stroke-linecap="round" stroke-linejoin="round"/>
              <circle cx="64" cy="69" r="4.5" fill="#0B2E33"/>
            </g>
          </svg>
          <div class="splash-wordmark">
            <div class="splash-title">TEMPO-POINT <span class="splash-ia-pill">IA</span></div>
            <div class="splash-sub">Plateforme intelligente de gestion, pointage & pilotage d'entreprise</div>
          </div>
        </div>
        <div class="splash-loader"><div class="splash-loader-bar"></div></div>
        <button class="splash-skip" onclick="TP.finishSplash()">Passer l'intro →</button>
      </div>`;
  };
})();

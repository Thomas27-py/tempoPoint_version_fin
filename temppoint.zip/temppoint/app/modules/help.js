(function () {
  window.TP_EXT_MODULES = window.TP_EXT_MODULES || {};
  window.TP_EXT = window.TP_EXT || {};
  let helpTopic = 'all';

  window.TP_EXT_MODULES.help = function () {
    const topics = {
      all: { t: 'Tout à propos de Tempo-Point IA', b: 'Tempo-Point IA est une plateforme Linux de pointage, gestion RH, coordination Projets & Agenda, automatisation (Tempo Automation), sécurité cloud à consentement, API ouverte, tableau prédictif local et vision numérique de l\'entreprise.' },
      history: { t: 'Histoire du logiciel', b: 'Né pour remplacer les cahiers papier et les tableurs dispersés, Tempo-Point IA réunit le pointage matériel, l\'aide à la décision RH et le pilotage opérationnel dans un poste Linux unifié.' },
      features: { t: 'Fonctionnalités complètes', b: 'Inclut le socle RH (inscription manuelle, photo IA, Excel, intranet, badges, salaires, promotions, avis managers), règles de pointage, machines, statistiques, Projets & Tâches, Planning unifié, Automatisations, Sécurité & Cloud, Tempo API, Prédictif IA et Vision numérique.' },
      install: { t: 'Installation sur mesure', b: 'L\'assistant en 8 étapes adapte Tempo-Point IA selon votre type (Type 01 avec sections / Type 02 sans section), vos modules activés, vos règles horaires, votre consentement cloud et votre compte administrateur.' },
      rules: { t: 'Règles de pointage', b: 'Définissez l\'heure d\'arrivée, fin de travail, tolérance de retard, pauses, plages individuelles Jour/Nuit, calendrier cyclique et exportez vos documents réglementaires.' },
      support: { t: 'Contacter le support', b: 'Support technique Tempo-Point IA · support@tempo-point.mg · Lun–Sam 07h30–18h00.' }
    };
    const cur = topics[helpTopic] || topics.all;

    return `
      <div class="flex-between mb-4">
        <div><h1>Outil d'aide Tempo-Point</h1><p class="muted">Guides d'utilisation et aperçu visuel de l'interface de discussion</p></div>
      </div>
      <div class="grid-2" style="grid-template-columns:280px 1fr;">
        <div class="card" style="padding:14px;">
          <h3 class="mb-3">Sujets</h3>
          <div style="display:flex;flex-direction:column;gap:6px;">
            ${Object.entries(topics).map(([k, v]) => `
              <button class="choice-card ${helpTopic === k ? 'selected' : ''}" style="padding:10px 12px;" onclick="TP_EXT.setHelpTopic('${k}')">
                <strong style="font-size:13px;">${v.t}</strong>
              </button>`).join('')}
          </div>
        </div>

        <div class="card chat-box">
          <div class="chat-messages">
            <div class="chat-bubble-user">${cur.t}</div>
            <div class="chat-bubble-bot">
              <strong>${cur.t}</strong>
              <p class="mt-2">${cur.b}</p>
              <div class="mt-3"><span class="pill pill-gray">Interface de discussion (prototypage visuel · aucune réponse automatique active)</span></div>
            </div>
          </div>
          <div class="chat-input-bar" title="Prototype visuel uniquement : la saisie conversationnelle est désactivée">
            <input type="text" placeholder="Posez votre question... (prototype visuel inactif)" />
            <button type="button" class="btn btn-amber btn-sm" style="border-radius:99px;" onclick="return false;">Envoyer</button>
          </div>
        </div>
      </div>`;
  };

  Object.assign(window.TP_EXT, {
    setHelpTopic(k) { helpTopic = k; TP.render(); }
  });
})();

(function () {
  window.TP_EXT_MODULES = window.TP_EXT_MODULES || {};
  window.TP_EXT = window.TP_EXT || {};
  let visionTab = 'org';

  window.TP_EXT_MODULES.vision = function () {
    const s = TP.state;
    const filterSec = TP.ui.params.vSec || 'Toutes';
    const emps = s.employees.filter(e => filterSec === 'Toutes' || e.section === filterSec);

    return `
      <div class="flex-between mb-4">
        <div><h1>Vision numérique de l'entreprise</h1><p class="muted">Jumeau numérique organisationnel · Filtré selon vos autorisations (${s.currentRole})</p></div>
        <select class="select" style="width:220px;" onchange="TP.navigate('vision','index',{vSec:this.value})">
          <option value="Toutes">Tous les services</option>
          ${s.company.sections.map(sec => `<option ${filterSec === sec ? 'selected' : ''}>${TP.esc(sec)}</option>`).join('')}
        </select>
      </div>

      <div class="tabs">
        ${[['org', 'Organigramme'], ['projects', 'Carte des projets'], ['cal', 'Calendrier'], ['proc', 'Processus'], ['equip', 'Équipements'], ['dir', 'Vue Direction']].map(([k, l]) => `
          <button class="tab-btn ${visionTab === k ? 'active' : ''}" onclick="TP_EXT.setVision('${k}')">${l}</button>`).join('')}
      </div>

      ${visionTab === 'org' ? `
        <div class="card" style="text-align:center;">
          <div class="pill pill-dark" style="padding:10px 22px;font-size:14px;">Direction · ${TP.esc(s.adminAccount.name)} (${s.currentRole})</div>
          <div class="grid-3 mt-4" style="text-align:left;">
            ${(filterSec === 'Toutes' ? s.company.sections : [filterSec]).map(sec => {
              const secEmps = emps.filter(e => e.section === sec);
              return `
                <div class="card" style="background:#F7FAFA;">
                  <div class="flex-between mb-2"><strong>${TP.esc(sec)}</strong><span class="pill pill-blue">${secEmps.length}</span></div>
                  ${secEmps.map(e => `<div class="flex-between small mt-2"><span>${TP.esc(e.nom)} ${TP.esc(e.prenom)}</span><span class="pill ${e.status === 'Présent' ? 'pill-green' : e.status === 'Retard' ? 'pill-amber' : 'pill-red'}">${e.status}</span></div>`).join('') || '<div class="muted small">Aucun membre</div>'}
                </div>`;
            }).join('')}
          </div>
        </div>` : visionTab === 'projects' ? `
        <div class="grid-3">
          ${s.projects.filter(p => filterSec === 'Toutes' || p.section === filterSec).map(p => `
            <div class="card"><strong>${TP.esc(p.name)}</strong><div class="muted small mt-1">${TP.esc(p.section)} · ${TP.esc(p.owner)}</div><div class="mt-2"><span class="pill pill-amber">${s.tasks.filter(t => t.projectId === p.id).length} tâches liées</span></div></div>`).join('')}
        </div>` : visionTab === 'proc' ? `
        <div class="grid-2">
          ${s.automations.map(a => `<div class="card"><div class="flex-between"><strong>${TP.esc(a.name)}</strong><span class="pill ${a.active ? 'pill-green' : 'pill-gray'}">${a.active ? 'Actif' : 'Inactif'}</span></div><div class="muted small mt-2">${TP.esc(a.trigger)} → ${TP.esc(a.action)}</div></div>`).join('')}
        </div>` : visionTab === 'equip' ? `
        <div class="grid-4">
          ${s.machines.map(m => `<div class="topo-node ${m.status !== 'En ligne' ? 'offline' : ''}"><strong>${TP.esc(m.name)}</strong><div class="small muted">${m.ip}</div><div class="mt-2"><span class="pill ${m.status === 'En ligne' ? 'pill-green' : 'pill-red'}">${m.status}</span></div></div>`).join('')}
        </div>` : visionTab === 'cal' ? `
        <div class="card">${s.events.map(ev => `<div class="flex-between mb-2" style="padding:10px;border-bottom:1px solid var(--border);"><strong>${TP.esc(ev.title)}</strong><span>${ev.date} · ${ev.time}</span></div>`).join('')}</div>` : `
        <div class="grid-4">
          <div class="card"><div class="muted small">Effectif actif</div><div style="font-size:26px;font-weight:800;">${s.employees.length}</div></div>
          <div class="card"><div class="muted small">Projets en cours</div><div style="font-size:26px;font-weight:800;">${s.projects.length}</div></div>
          <div class="card"><div class="muted small">Workflows actifs</div><div style="font-size:26px;font-weight:800;">${s.automations.filter(a => a.active).length}</div></div>
          <div class="card"><div class="muted small">Accès Salaires (${s.currentRole})</div><div style="font-size:18px;font-weight:800;margin-top:6px;">${TP.hasPerm('salaries') ? 'Autorisé' : 'Masqué par RBAC'}</div></div>
        </div>`}`;
  };

  Object.assign(window.TP_EXT, {
    setVision(v) { visionTab = v; TP.render(); }
  });
})();

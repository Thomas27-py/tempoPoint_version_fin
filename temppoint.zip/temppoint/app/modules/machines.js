(function () {
  window.TP_CORE_MODULES = window.TP_CORE_MODULES || {};
  window.TP_CORE = window.TP_CORE || {};

  window.TP_CORE_MODULES.machines = function () {
    const s = TP.state;
    const sub = TP.ui.sub;

    if (sub === 'topology') {
      return `
        <div class="flex-between mb-4">
          <div><h1>Connexions entre les machines</h1><p class="muted">Serveur Tempo-Point, terminaux et postes connectés</p></div>
          <div class="flex gap-2">
            <button class="btn btn-outline" onclick="TP.navigate('machines','index')">← Retour</button>
            <button class="btn btn-primary" onclick="TP_CORE.pingMachines()">Tester toutes les liaisons</button>
          </div>
        </div>
        <div class="card mb-4" style="text-align:center;">
          <div class="pill pill-dark" style="padding:10px 24px;font-size:14px;">Serveur Tempo-Point (${s.company.hostingMode.toUpperCase()})</div>
          <div class="grid-4 mt-4">
            ${s.machines.map(m => `
              <div class="topo-node ${m.status !== 'En ligne' ? 'offline' : ''}">
                <strong>${TP.esc(m.name)}</strong>
                <div class="small muted">${m.id} · ${m.ip}</div>
                <div class="mt-2"><span class="pill ${m.status === 'En ligne' ? 'pill-green' : 'pill-red'}">${m.status === 'En ligne' ? `${m.pcs.length} PC · ${m.latencyMs} ms` : 'Hors ligne · ' + m.offlineBuffered + ' cache'}</span></div>
                ${m.status !== 'En ligne' ? `<button class="btn btn-success btn-sm mt-2" onclick="TP_CORE.toggleMachine('${m.id}')">Reconnecter</button>` : ''}
              </div>`).join('')}
          </div>
        </div>`;
    }

    if (sub === 'history') {
      return `
        <div class="flex-between mb-4">
          <div><h1>Historique des connexions</h1><p class="muted">Machines et ordinateurs</p></div>
          <button class="btn btn-outline" onclick="TP.navigate('machines','index')">← Retour</button>
        </div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Date</th><th>Machine</th><th>Événement</th><th>Détail</th></tr></thead>
            <tbody>${s.connectionHistory.map(h => `<tr><td class="num">${h.date}</td><td><strong>${TP.esc(h.machine)}</strong></td><td><span class="pill ${h.event === 'Déconnectée' ? 'pill-red' : 'pill-green'}">${h.event}</span></td><td>${TP.esc(h.detail)}</td></tr>`).join('')}</tbody>
          </table>
        </div>`;
    }

    const online = s.machines.filter(m => m.status === 'En ligne').length;
    return `
      <div class="flex-between mb-4">
        <div><h1>Machines de pointage</h1><p class="muted">${s.machines.length} machines · ${online} en ligne · ${s.machines.length - online} hors ligne</p></div>
        <div class="flex gap-2">
          <button class="btn btn-outline" onclick="TP.navigate('machines','topology')">🔗 Topologie réseau</button>
          <button class="btn btn-outline" onclick="TP.navigate('machines','history')">📜 Historique</button>
          <button class="btn btn-amber" onclick="TP_CORE.connectMachineModal()">+ Ajouter une machine</button>
        </div>
      </div>
      <div class="grid-2">
        ${s.machines.map(m => `
          <div class="card" style="${m.status !== 'En ligne' ? 'border-color:#FCA5A5;background:#FFFBFB;' : ''}">
            <div class="flex-between">
              <div><h3>${TP.esc(m.name)}</h3><div class="muted small">${m.id} · ${m.ip}</div></div>
              <span class="pill ${m.status === 'En ligne' ? 'pill-green' : 'pill-red'}">${m.status}</span>
            </div>
            <div class="grid-3 mt-3">
              <div><div class="muted small">PC connectés</div><strong>${m.pcs.length}</strong></div>
              <div><div class="muted small">Méthode</div><strong>${TP.esc(m.method)}</strong></div>
              <div><div class="muted small">Dernier pointage</div><strong>${TP.esc(m.lastPunch)}</strong></div>
            </div>
            <div class="flex gap-2 mt-4">
              <button class="btn btn-outline btn-sm" onclick="TP_CORE.machineDetailModal('${m.id}')">Détails & PC (${m.pcs.length})</button>
              <button class="btn btn-outline btn-sm" onclick="TP_CORE.machineMethodModal('${m.id}')">Méthode</button>
              <button class="btn ${m.status === 'En ligne' ? 'btn-danger' : 'btn-success'} btn-sm" onclick="TP_CORE.toggleMachine('${m.id}')">${m.status === 'En ligne' ? 'Déconnecter' : 'Reconnecter'}</button>
            </div>
          </div>`).join('')}
      </div>`;
  };

  Object.assign(window.TP_CORE, {
    pingMachines() { TP.state.machines.forEach(m => { if (m.status === 'En ligne') m.latencyMs = 8 + Math.floor(Math.random() * 24); }); TP.save(); TP.render(); TP.toast('Liaisons réseau testées.'); },
    toggleMachine(id) {
      const m = TP.state.machines.find(x => x.id === id);
      if (m.status === 'En ligne') {
        m.status = 'Hors ligne'; m.latencyMs = null;
        TP.state.connectionHistory.unshift({ date: 'À l\'instant', machine: m.name, event: 'Déconnectée', type: 'machine', detail: 'Pointages en cache hors-ligne' });
      } else {
        const synced = m.offlineBuffered;
        m.status = 'En ligne'; m.latencyMs = 14; m.offlineBuffered = 0;
        TP.state.connectionHistory.unshift({ date: 'À l\'instant', machine: m.name, event: 'Reconnectée', type: 'machine', detail: `${synced} pointages synchronisés` });
      }
      TP.save(); TP.render(); TP.toast(`${m.name} (${m.status})`);
    },
    connectMachineModal() {
      TP.openModal('Connecter une nouvelle machine', `<div class="banner banner-blue mb-3">Scan réseau local simulé : <strong>MP-0005 (192.168.1.25)</strong> détectée.</div><label class="field-label">Nom</label><input id="nm-mname" class="input mb-3" value="Atelier Annexe"/><label class="field-label">IP</label><input id="nm-mip" class="input mb-4" value="192.168.1.25"/><button class="btn btn-amber" onclick="TP_CORE.addMachine()">Associer</button>`);
    },
    addMachine() {
      const name = document.getElementById('nm-mname').value; const ip = document.getElementById('nm-mip').value;
      TP.state.machines.push({ id: 'MP-000' + (TP.state.machines.length + 1), name, ip, status: 'En ligne', latencyMs: 11, method: TP.state.company.pointingMethod, lastPunch: 'Maintenant', connectedSince: 'Maintenant', offlineBuffered: 0, pcs: [] });
      TP.logAction('Insérer', `Machine ${name} (${ip})`, 'Nouveau terminal', '—', 'En ligne', 'Machines');
      TP.closeModal(); TP.save(); TP.render();
    },
    machineDetailModal(id) {
      const m = TP.state.machines.find(x => x.id === id);
      TP.openModal(`${m.name} (${m.id})`, `<p class="muted mb-3">IP : ${m.ip} · Méthode : ${m.method}</p><h4>Ordinateurs connectés (${m.pcs.length})</h4><div class="table-wrap mt-2"><table><thead><tr><th>Poste</th><th>Utilisateur</th><th>IP</th><th></th></tr></thead><tbody>${m.pcs.map((p, i) => `<tr><td><strong>${p.pc}</strong></td><td>${TP.esc(p.user)}</td><td>${p.ip}</td><td><button class="btn btn-danger btn-sm" onclick="TP_CORE.disconnectPc('${m.id}',${i})">Déconnecter</button></td></tr>`).join('') || '<tr><td colspan="4" class="muted">Aucun poste connecté</td></tr>'}</tbody></table></div>`, true);
    },
    disconnectPc(mId, idx) {
      const m = TP.state.machines.find(x => x.id === mId); const removed = m.pcs.splice(idx, 1)[0];
      TP.state.connectionHistory.unshift({ date: 'À l\'instant', machine: m.name, event: 'Poste déconnecté', type: 'pc', detail: removed.pc });
      TP.closeModal(); TP.save(); TP.render();
    },
    machineMethodModal(id) {
      const m = TP.state.machines.find(x => x.id === id);
      TP.openModal(`Méthode · ${m.name}`, `<div style="display:flex;flex-direction:column;gap:10px;">${['Badge + empreinte', 'Badge + mot de passe', 'Badge seul', 'Code PIN + photo'].map(meth => `<button class="choice-card ${m.method === meth ? 'selected' : ''}" onclick="TP_CORE.setMachineMethod('${m.id}','${meth}')"><strong>${meth}</strong></button>`).join('')}</div>`);
    },
    setMachineMethod(id, meth) { TP.state.machines.find(x => x.id === id).method = meth; TP.closeModal(); TP.save(); TP.render(); }
  });
})();

(function () {
  window.TP_EXT_MODULES = window.TP_EXT_MODULES || {};
  window.TP_EXT = window.TP_EXT || {};

  window.TP_EXT_MODULES.api = function () {
    const ap = TP.state.apiPlatform;
    const tab = TP.ui.sub === 'index' ? 'console' : TP.ui.sub;
    return `
      <div class="flex-between mb-4">
        <div><h1>Tempo API · Portail d'intégration</h1><p class="muted">API REST v1 respectant strictement vos permissions internes et votre consentement cloud</p></div>
        <button class="btn btn-amber" onclick="TP_EXT.newApiAppModal()">+ Créer une application API</button>
      </div>
      <div class="tabs">
        ${[['console', 'Console Bac à sable'], ['apps', 'Applications & Clés (' + ap.apps.length + ')'], ['webhooks', 'Webhooks (' + ap.webhooks.length + ')'], ['docs', 'Documentation REST v1']].map(([k, l]) => `
          <button class="tab-btn ${tab === k ? 'active' : ''}" onclick="TP.navigate('api','${k}')">${l}</button>`).join('')}
      </div>

      ${tab === 'apps' ? `
        <div class="grid-2">
          ${ap.apps.map(a => `
            <div class="card">
              <div class="flex-between"><strong>${TP.esc(a.name)}</strong><span class="pill ${a.env === 'Production' ? 'pill-dark' : 'pill-blue'}">${a.env}</span></div>
              <div class="mt-2 small muted">Clé : <code>${TP.esc(a.key)}</code> · Expire : ${a.expires}</div>
              <div class="flex gap-2 mt-2" style="flex-wrap:wrap;">${a.scopes.map(sc => `<span class="pill pill-gray">${sc}</span>`).join('')}</div>
              <div class="flex gap-2 mt-3">
                <button class="btn btn-outline btn-sm" onclick="TP_EXT.rotateApiKey('${a.id}')">↻ Rotation clé</button>
                <button class="btn ${a.active ? 'btn-danger' : 'btn-success'} btn-sm" onclick="TP_EXT.toggleApiApp('${a.id}')">${a.active ? 'Révoquer' : 'Réactiver'}</button>
              </div>
            </div>`).join('')}
        </div>` : tab === 'webhooks' ? `
        <div class="card mb-3">
          <div class="flex-between mb-3"><h3>Webhooks configurés</h3><button class="btn btn-outline btn-sm" onclick="TP_EXT.newWebhookModal()">+ Ajouter Webhook</button></div>
          ${ap.webhooks.map(w => `
            <div class="flex-between mb-2" style="padding:10px;border:1px solid var(--border);border-radius:10px;">
              <div><strong>${TP.esc(w.event)}</strong><div class="small muted">${TP.esc(w.url)} · ${TP.esc(w.lastStatus)}</div></div>
              <button class="btn btn-amber btn-sm" onclick="TP_EXT.testWebhook('${w.id}')">⚡ Tester</button>
            </div>`).join('')}
        </div>` : tab === 'docs' ? `
        <div class="card">
          <h3 class="mb-3">Endpoints officiels REST /api/v1 (OAuth 2.0 / Bearer Key)</h3>
          ${[
            ['GET', '/api/v1/employees', 'Liste du personnel (scope rh:read + consentement)'],
            ['GET', '/api/v1/attendance/today', 'Relevé de pointage du jour (scope pointage:read)'],
            ['GET', '/api/v1/projects', 'Projets, jalons et avancement (scope projets:read/write)'],
            ['GET', '/api/v1/stats/summary', 'Indicateurs agrégés (scope stats:read)']
          ].map(([m, p, d]) => `<div class="flex-between mb-2" style="padding:10px;border-bottom:1px solid var(--border);"><div><span class="pill pill-dark">${m}</span> <code style="margin-left:8px;font-weight:700;">${p}</code></div><span class="muted small">${d}</span></div>`).join('')}
        </div>` : `
        <div class="card">
          <h3 class="mb-3">Console interactive Sandbox / Production</h3>
          <div class="grid-2 mb-3">
            <div>
              <label class="field-label">Endpoint</label>
              <select id="api-ep" class="select">
                <option value="/api/v1/employees">GET /api/v1/employees</option>
                <option value="/api/v1/attendance/today">GET /api/v1/attendance/today</option>
                <option value="/api/v1/projects">GET /api/v1/projects</option>
                <option value="/api/v1/stats/summary">GET /api/v1/stats/summary</option>
              </select>
            </div>
            <div>
              <label class="field-label">Application cliente</label>
              <select id="api-app" class="select">${ap.apps.map(a => `<option value="${a.id}">${TP.esc(a.name)} (${a.env}${a.active ? '' : ' · RÉVOQUÉE'})</option>`).join('')}</select>
            </div>
          </div>
          <button class="btn btn-amber" onclick="TP_EXT.runApiTest()">▶ Exécuter la requête simulée</button>
          <pre id="api-output" style="margin-top:14px;background:#072024;color:#A7F3D0;padding:14px;border-radius:10px;overflow:auto;max-height:240px;font-size:12px;">Cliquez sur Exécuter pour tester l'API avec contrôle des scopes et consentements...</pre>
        </div>`}`;
  };

  Object.assign(window.TP_EXT, {
    newApiAppModal() {
      TP.openModal('Nouvelle application Tempo API', `
        <label class="field-label">Nom de l'application</label><input id="na-name" class="input mb-3" placeholder="Ex: Connecteur ERP"/>
        <label class="field-label">Environnement</label><select id="na-env" class="select mb-4"><option>Sandbox</option><option>Production</option></select>
        <button class="btn btn-amber" onclick="TP_EXT.saveApiApp()">Générer clé API</button>`);
    },
    saveApiApp() {
      const env = document.getElementById('na-env').value;
      TP.state.apiPlatform.apps.push({ id: 'app-' + Date.now(), name: document.getElementById('na-name').value || 'Client API', env, key: (env === 'Production' ? 'tp_live_' : 'tp_test_') + Math.random().toString(16).slice(2, 16), scopes: ['rh:read', 'pointage:read', 'stats:read'], expires: '2027-12-31', active: true });
      TP.closeModal(); TP.save(); TP.render(); TP.toast('Clé API générée.');
    },
    rotateApiKey(id) { const a = TP.state.apiPlatform.apps.find(x => x.id === id); a.key = (a.env === 'Production' ? 'tp_live_' : 'tp_test_') + Math.random().toString(16).slice(2, 16); TP.save(); TP.render(); TP.toast('Clé régénérée.'); },
    toggleApiApp(id) { const a = TP.state.apiPlatform.apps.find(x => x.id === id); a.active = !a.active; TP.save(); TP.render(); },
    newWebhookModal() {
      TP.openModal('Nouveau Webhook', `
        <label class="field-label">URL cible</label><input id="nw-url" class="input mb-3" value="https://intranet.ravelo.mg/hooks/events"/>
        <label class="field-label">Événement</label><select id="nw-ev" class="select mb-4"><option>attendance.anomaly</option><option>employee.created</option><option>task.overdue</option></select>
        <button class="btn btn-amber" onclick="TP_EXT.saveWebhook()">Enregistrer</button>`);
    },
    saveWebhook() { TP.state.apiPlatform.webhooks.push({ id: 'wh-' + Date.now(), url: document.getElementById('nw-url').value, event: document.getElementById('nw-ev').value, active: true, lastStatus: 'En attente de test' }); TP.closeModal(); TP.save(); TP.render(); },
    testWebhook(id) { const w = TP.state.apiPlatform.webhooks.find(x => x.id === id); w.lastStatus = '200 OK · 28 ms'; TP.save(); TP.render(); TP.toast(`Webhook ${w.event} livré (200 OK).`); },
    runApiTest() {
      const ep = document.getElementById('api-ep').value;
      const app = TP.state.apiPlatform.apps.find(a => a.id === document.getElementById('api-app').value);
      const out = document.getElementById('api-output');
      const sc = TP.state.securityCloud;
      if (!app || !app.active) { out.textContent = JSON.stringify({ status: 403, error: 'Clé API révoquée ou inactive.' }, null, 2); return; }
      const reqScope = ep.includes('employees') ? 'rh:read' : ep.includes('attendance') ? 'pointage:read' : ep.includes('projects') ? 'projets:write' : 'stats:read';
      if (!app.scopes.includes(reqScope)) { out.textContent = JSON.stringify({ status: 403, error: `Scope manquant : ${reqScope}` }, null, 2); return; }
      if (ep.includes('employees') && sc.storageMode !== 'local' && !sc.categories.employees.cloud) {
        out.textContent = JSON.stringify({ status: 403, error: 'Accès bloqué par Tempo Sécurité : consentement cloud non accordé pour les dossiers employés.' }, null, 2);
        return;
      }
      let payload = { status: 200, env: app.env, endpoint: ep, correlationId: 'corr-' + Math.random().toString(16).slice(2, 8) };
      if (ep.includes('employees')) payload.data = TP.state.employees.map(e => ({ matricule: e.matricule, nom: e.nom, section: e.section }));
      else if (ep.includes('attendance')) payload.data = TP.state.employees.map(e => ({ nom: e.nom, status: e.status, arrivee: e.arrivee }));
      else if (ep.includes('projects')) payload.data = TP.state.projects;
      else payload.data = { totalEmployees: TP.state.employees.length, projects: TP.state.projects.length, mode: sc.storageMode };
      out.textContent = JSON.stringify(payload, null, 2);
    }
  });
})();

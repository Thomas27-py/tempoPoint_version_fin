(function () {
  window.TP_EXT_MODULES = window.TP_EXT_MODULES || {};
  window.TP_EXT = window.TP_EXT || {};

  window.TP_EXT_MODULES.account = function () {
    const s = TP.state;
    const adm = s.adminAccount;
    const tab = TP.ui.sub === 'accounts' ? 'accounts' : 'profile';
    return `
      <div class="flex-between mb-4">
        <div><h1>Mon compte · ${TP.esc(adm.name)}</h1><p class="muted">Rôle actif : ${s.currentRole} · Entreprise : ${TP.esc(s.company.name)}</p></div>
        <div class="flex gap-2">
          <button class="btn ${tab === 'profile' ? 'btn-primary' : 'btn-outline'} btn-sm" onclick="TP.navigate('account','profile')">Mon profil</button>
          <button class="btn ${tab === 'accounts' ? 'btn-primary' : 'btn-outline'} btn-sm" onclick="TP.navigate('account','accounts')">Comptes de l'entreprise</button>
          <button class="btn btn-danger btn-sm" onclick="TP_EXT.confirmReset()">Réinitialiser l'app</button>
        </div>
      </div>

      ${tab === 'accounts' ? `
        ${s.currentRole !== 'PDG' ? '<div class="banner banner-amber mb-3">Seul le rôle PDG peut modifier les autres comptes utilisateurs de l\'entreprise.</div>' : ''}
        <div class="table-wrap">
          <table>
            <thead><tr><th>Utilisateur</th><th>Rôle</th><th>Mail</th><th>Statut</th></tr></thead>
            <tbody>${s.companyAccounts.map(a => `<tr><td><strong>${TP.esc(a.name)}</strong></td><td><span class="pill pill-dark">${a.role}</span></td><td>${TP.esc(a.email)}</td><td><span class="pill ${a.status === 'Connecté' ? 'pill-green' : 'pill-gray'}">${a.status}</span></td></tr>`).join('')}</tbody>
          </table>
        </div>` : `
        <div class="grid-2">
          <div class="card">
            <h3 class="mb-3">Informations personnelles</h3>
            <label class="field-label">Nom complet</label><input id="acc-name" class="input mb-3" value="${TP.esc(adm.name)}"/>
            <label class="field-label">Mail professionnel</label><input id="acc-mail" class="input mb-3" value="${TP.esc(adm.email)}"/>
            <label class="field-label">Téléphone</label><input id="acc-tel" class="input mb-4" value="${TP.esc(adm.phone)}"/>
            <button class="btn btn-amber" onclick="TP_EXT.saveProfile()">Enregistrer le profil</button>
          </div>
          <div class="card" style="background:#0B2E33;color:#fff;">
            <h3 style="color:#fff;">Biométrie faciale & Sécurité</h3>
            <p class="small mt-2" style="color:#B4D0D4;">Gabarit stocké uniquement en local (bloqué hors synchronisation cloud par défaut).</p>
            <div class="mt-3"><span class="pill pill-green">✓ Visage enregistré · ${adm.lastFaceUpdate}</span></div>
            <button class="btn btn-amber btn-sm mt-4" onclick="TP.toast('Nouvel enregistrement facial simulé effectué.')">Refaire la capture faciale</button>
          </div>
        </div>`}`;
  };

  Object.assign(window.TP_EXT, {
    confirmReset() {
      if (confirm('Réinitialiser toutes les données locales et relancer l\'installation ?')) {
        TP.resetAll();
      }
    },
    saveProfile() {
      TP.state.adminAccount.name = document.getElementById('acc-name').value;
      TP.state.adminAccount.email = document.getElementById('acc-mail').value;
      TP.state.adminAccount.phone = document.getElementById('acc-tel').value;
      TP.save(); TP.render(); TP.toast('Profil mis à jour.');
    }
  });
})();

(function () {
  window.TP_CORE_MODULES = window.TP_CORE_MODULES || {};
  window.TP_CORE = window.TP_CORE || {};

  let selectedIds = new Set();
  let ocrDrafts = [];
  let ocrIdx = 0;
  let manualCount = 1;
  let manualCurrent = 1;

  function barcodeSvg(code) {
    let bars = '';
    for (let i = 0; i < 34; i++) {
      const w = (code.charCodeAt(i % code.length) + i) % 3 === 0 ? 3 : 1.5;
      bars += `<rect x="${i * 5}" y="0" width="${w}" height="44" fill="#0B2E33"/>`;
    }
    return `<svg width="170" height="44" viewBox="0 0 170 44">${bars}</svg>`;
  }

  window.TP_CORE_MODULES.employees = function () {
    const sub = TP.ui.sub;
    const s = TP.state;

    if (sub === 'index') {
      return `
        <div class="flex-between mb-4">
          <div><h1>Gestion des employés</h1><p class="muted">Choisissez une action RH ou utilisez l'IA d'inscription et d'évaluation</p></div>
          <button class="btn btn-outline" onclick="TP.navigate('employees','list')">Voir toute la liste (${s.employees.length})</button>
        </div>
        <div class="grid-3">
          <div class="card card-hover" onclick="TP.navigate('employees','enroll')"><div class="icon-box mb-3">+</div><h3>Inscription</h3><p class="muted small mt-2">Manuelle, Photo IA, Excel IA, Intranet & Badges</p></div>
          <div class="card card-hover" onclick="TP.navigate('employees','list')"><div class="icon-box mb-3">✎</div><h3>Fiches & Modification</h3><p class="muted small mt-2">Consulter et mettre à jour chaque salarié</p></div>
          <div class="card card-hover" onclick="TP.navigate('employees','delete')"><div class="icon-box mb-3">🗑</div><h3>Suppression</h3><p class="muted small mt-2">Retirer un ou plusieurs salariés avec trace</p></div>
          ${TP.isModuleEnabled('payrollDeductions') ? `<div class="card card-hover" onclick="TP.navigate('employees','salaries')"><div class="icon-box mb-3">${TP.esc(s.company.currency)}</div><h3>Voir les salaires</h3><p class="muted small mt-2">Salaires de base, retenues retards & net</p></div>` : ''}
          ${TP.isModuleEnabled('hrDecisions') ? `<div class="card card-hover" onclick="TP.navigate('employees','promotions')"><div class="icon-box mb-3">★</div><h3>Générer la promotion</h3><p class="muted small mt-2">Suggestions calculées par IA avec avis managers</p></div>` : ''}
          <div class="card card-dark card-hover" onclick="TP.navigate('employees','reviews')"><div class="icon-box mb-3" style="background:rgba(245,158,11,0.2);color:#FBBF24;">💬</div><h3 style="color:#fff;">Avis des managers</h3><p class="small mt-2" style="color:#B9D3D7;">Lecture IA des emails & alimentation promotions</p></div>
        </div>`;
    }

    if (sub === 'enroll') {
      return `
        <div class="flex-between mb-4">
          <div><h1>Inscription des salariés</h1><p class="muted">Choisissez la méthode d'ajout ou générez les badges</p></div>
          <button class="btn btn-outline" onclick="TP.navigate('employees','index')">← Retour</button>
        </div>
        <div class="card mb-4" style="border-color:#F59E0B;">
          <span class="pill pill-amber mb-2">Recommandé</span>
          <div class="flex-between" style="flex-wrap:wrap;gap:14px;">
            <div><h3>Inscription manuelle</h3><p class="muted small">Saisissez les fiches une par une.</p></div>
            <div class="flex gap-2">
              <input id="manual-qty" type="number" min="1" max="20" value="${manualCount}" class="input" style="width:90px;"/>
              <button class="btn btn-amber" onclick="TP_CORE.startManual()">Démarrer →</button>
            </div>
          </div>
        </div>
        <div class="grid-2">
          <div class="card card-hover" onclick="TP_CORE.runPhotoAI()"><h3>📷 Inscription par photo (IA OCR)</h3><p class="muted small mt-2">Simule la lecture IA d'une liste papier puis validation fiche par fiche.</p></div>
          <div class="card card-hover" onclick="TP_CORE.runExcelAI()"><h3>📊 Inscription par Excel / CSV (IA)</h3><p class="muted small mt-2">Importe un fichier tableur et associe automatiquement les colonnes.</p></div>
          <div class="card card-dark card-hover" onclick="TP.navigate('employees','badges')"><h3 style="color:#fff;">🪪 Générer et télécharger les badges</h3><p class="small mt-2" style="color:#B4D0D4;">Code-barres dynamique et export PDF/impression.</p></div>
          <div class="card card-hover" onclick="TP.navigate('employees','intranet')"><h3>🌐 Inscription en ligne par intranet</h3><p class="muted small mt-2">Simule http://tempo-point.local/inscription et gère les ${s.pendingRegistrations.length} demandes en attente.</p></div>
        </div>`;
    }

    if (sub === 'manual') {
      return `
        <div class="flex-between mb-4">
          <div><h1>Inscription manuelle</h1><span class="pill pill-amber">Salarié ${manualCurrent} sur ${manualCount}</span></div>
          <button class="btn btn-outline" onclick="TP.navigate('employees','enroll')">← Retour</button>
        </div>
        <div class="card" style="max-width:740px;">
          <div class="grid-2">
            <div><label class="field-label">Nom</label><input id="m-nom" class="input" placeholder="Ex: Ravelo"/></div>
            <div><label class="field-label">Prénom</label><input id="m-prenom" class="input" placeholder="Ex: Kanto"/></div>
            <div><label class="field-label">Mail</label><input id="m-mail" class="input" placeholder="kanto@ravelo.mg"/></div>
            <div><label class="field-label">Téléphone</label><input id="m-tel" class="input" placeholder="+261 34 ..."/></div>
            ${s.company.type === 'type1' ? `<div><label class="field-label">Section</label><select id="m-sec" class="select">${s.company.sections.map(x => `<option>${TP.esc(x)}</option>`).join('')}</select></div>` : ''}
            <div><label class="field-label">Fonction</label><input id="m-fn" class="input" placeholder="Ex: Technicien"/></div>
          </div>
          <div class="mt-4 flex-between">
            <span class="muted small">Inscrit automatiquement dans les journaux</span>
            <button class="btn btn-amber" onclick="TP_CORE.submitManual()">Confirmer l'inscription</button>
          </div>
        </div>`;
    }

    if (sub === 'ocr_validate') {
      const d = ocrDrafts[ocrIdx];
      if (!d) { TP.navigate('employees', 'list'); return ''; }
      const missing = ['nom', 'prenom', 'mail', 'tel', 'fonction'].filter(k => !d[k]);
      return `
        <div class="flex-between mb-4">
          <div><h1>Validation fiche par fiche (IA OCR)</h1><p class="muted">Fiche ${ocrIdx + 1} sur ${ocrDrafts.length} · L'IA n'invente jamais les champs illisibles</p></div>
          <button class="btn btn-outline" onclick="TP.navigate('employees','enroll')">Annuler</button>
        </div>
        <div class="banner ${missing.length ? 'banner-amber' : 'banner-green'} mb-4">
          ${missing.length ? `Champs non lus par l'IA : ${missing.join(', ')}. Complétez manuellement avant de valider.` : 'Tout est complet : la fiche attend votre validation humaine.'}
        </div>
        <div class="card">
          <div class="grid-2">
            <div><label class="field-label">Nom ${d.aiNom ? '<span class="pill pill-amber">IA</span>' : ''}</label><input id="ocr-nom" class="input" value="${TP.esc(d.nom)}" oninput="TP_CORE.updateOcr('nom',this.value)"/></div>
            <div><label class="field-label">Prénom ${d.aiPrenom ? '<span class="pill pill-amber">IA</span>' : ''}</label><input id="ocr-prenom" class="input" value="${TP.esc(d.prenom)}" oninput="TP_CORE.updateOcr('prenom',this.value)"/></div>
            <div><label class="field-label">Mail ${d.aiMail ? '<span class="pill pill-amber">IA</span>' : '<span class="pill pill-blue">À saisir</span>'}</label><input id="ocr-mail" class="input" value="${TP.esc(d.mail)}" oninput="TP_CORE.updateOcr('mail',this.value)"/></div>
            <div><label class="field-label">Tél ${d.aiTel ? '<span class="pill pill-amber">IA</span>' : '<span class="pill pill-blue">À saisir</span>'}</label><input id="ocr-tel" class="input" value="${TP.esc(d.tel)}" oninput="TP_CORE.updateOcr('tel',this.value)"/></div>
            <div><label class="field-label">Section</label><select class="select" onchange="TP_CORE.updateOcr('section',this.value)">${s.company.sections.map(x => `<option ${d.section === x ? 'selected' : ''}>${TP.esc(x)}</option>`).join('')}</select></div>
            <div><label class="field-label">Fonction</label><input class="input" value="${TP.esc(d.fonction)}" oninput="TP_CORE.updateOcr('fonction',this.value)"/></div>
          </div>
          <div class="flex-between mt-4">
            <button class="btn btn-danger" onclick="TP_CORE.skipOcr()">Refuser cette fiche</button>
            <button class="btn btn-success" ${missing.length ? 'disabled style="opacity:0.45;cursor:not-allowed;"' : ''} onclick="TP_CORE.acceptOcr()">✓ Valider la fiche</button>
          </div>
        </div>`;
    }

    if (sub === 'intranet' || sub === 'pending') {
      return `
        <div class="flex-between mb-4">
          <div><h1>Intranet & Inscriptions en attente</h1><p class="muted">Portail simulé : http://tempo-point.local/inscription</p></div>
          <div class="flex gap-2">
            <button class="btn btn-outline" onclick="TP.navigate('employees','enroll')">← Retour</button>
            <button class="btn btn-amber" onclick="TP_CORE.openIntranetForm()">Simuler formulaire Intranet</button>
          </div>
        </div>
        <div style="display:flex;flex-direction:column;gap:10px;">
          ${s.pendingRegistrations.length ? s.pendingRegistrations.map(p => `
            <div class="card flex-between">
              <div><strong>${TP.esc(p.nom)} ${TP.esc(p.prenom)}</strong><div class="muted small">${TP.esc(p.fonction)} · ${TP.esc(p.section)} · ${TP.esc(p.mail)}</div></div>
              <div class="flex gap-2">
                <span class="pill pill-amber">En attente</span>
                <button class="btn btn-success btn-sm" onclick="TP_CORE.approvePending('${p.id}')">Accepter</button>
                <button class="btn btn-danger btn-sm" onclick="TP_CORE.rejectPending('${p.id}')">Refuser</button>
              </div>
            </div>`).join('') : '<div class="card muted">Aucune demande d\'inscription en attente.</div>'}
        </div>`;
    }

    if (sub === 'badges') {
      return `
        <div class="flex-between mb-4">
          <div><h1>Générer et télécharger les badges</h1><p class="muted">${s.employees.length} badges prêts avec code-barres unique</p></div>
          <div class="flex gap-2">
            <button class="btn btn-outline" onclick="TP.navigate('employees','enroll')">← Retour</button>
            <button class="btn btn-amber" onclick="TP_CORE.downloadBadges()">⬇ Télécharger planche Badges</button>
          </div>
        </div>
        <div class="grid-3">
          ${s.employees.slice(0, 6).map(e => `
            <div class="card" style="text-align:center;padding:0;overflow:hidden;">
              <div style="background:#0B2E33;color:#fff;padding:16px 12px 24px;"><div style="font-weight:700;">Tempo-Point IA</div><div class="small" style="color:#9CC0C6;">${TP.esc(s.company.name)}</div></div>
              <div style="margin-top:-20px;"><span class="avatar" style="width:46px;height:46px;border:3px solid #fff;">${TP.initials(e.nom + ' ' + e.prenom)}</span></div>
              <div style="padding:12px 16px 18px;">
                <h3>${TP.esc(e.nom)} ${TP.esc(e.prenom)}</h3>
                <div class="muted small">${TP.esc(e.fonction)}</div>
                <div class="mt-2"><span class="pill pill-blue">${TP.esc(e.section)}</span></div>
                <div class="mt-3" style="display:flex;justify-content:center;">${barcodeSvg(e.matricule + e.nom)}</div>
                <div class="small mt-1" style="font-weight:700;">${TP.esc(e.matricule)}</div>
                <div class="muted small">Valable : 2026 – 2027</div>
              </div>
            </div>`).join('')}
        </div>`;
    }

    if (sub === 'list' || sub === 'delete') {
      const isDel = sub === 'delete';
      const q = (TP.ui.params.q || '').toLowerCase();
      const secF = TP.ui.params.sec || 'Toutes';
      const rows = s.employees.filter(e => (secF === 'Toutes' || e.section === secF) && (`${e.nom} ${e.prenom} ${e.fonction} ${e.section}`).toLowerCase().includes(q));
      return `
        <div class="flex-between mb-4">
          <div><h1>${isDel ? 'Suppression des salariés' : 'Liste des employés'}</h1><p class="muted">${rows.length} salariés affichés</p></div>
          <div class="flex gap-2">
            <button class="btn btn-outline" onclick="TP.navigate('employees','index')">← Retour</button>
            ${!isDel ? `<button class="btn btn-amber" onclick="TP.navigate('employees','enroll')">+ Inscription</button>` : ''}
          </div>
        </div>
        <div class="flex gap-3 mb-3">
          <input class="input" style="max-width:340px;" placeholder="Rechercher par nom, fonction..." value="${TP.esc(TP.ui.params.q || '')}" oninput="TP.ui.params.q=this.value;TP.render();"/>
          ${s.company.type === 'type1' ? `<select class="select" style="max-width:220px;" onchange="TP.ui.params.sec=this.value;TP.render();"><option>Toutes</option>${s.company.sections.map(x => `<option ${secF === x ? 'selected' : ''}>${TP.esc(x)}</option>`).join('')}</select>` : ''}
        </div>
        <div class="table-wrap">
          <table>
            <thead><tr>${isDel ? '<th></th>' : ''}<th>Nom & Prénom</th><th>Fonction</th>${s.company.type === 'type1' ? '<th>Section</th>' : ''}<th>Mail</th><th>Tél</th><th></th></tr></thead>
            <tbody>
              ${rows.map(e => `
                <tr class="${selectedIds.has(e.id) ? 'row-selected' : 'clickable'}" onclick="${isDel ? '' : `TP.navigate('employees','detail',{id:'${e.id}'})`}">
                  ${isDel ? `<td onclick="event.stopPropagation()"><input type="checkbox" ${selectedIds.has(e.id) ? 'checked' : ''} onchange="TP_CORE.toggleDel('${e.id}')"/></td>` : ''}
                  <td><div class="flex gap-2"><span class="avatar">${TP.initials(e.nom + ' ' + e.prenom)}</span><strong>${TP.esc(e.nom)} ${TP.esc(e.prenom)}</strong></div></td>
                  <td>${TP.esc(e.fonction)}</td>
                  ${s.company.type === 'type1' ? `<td>${TP.esc(e.section)}</td>` : ''}
                  <td>${TP.esc(e.mail)}</td><td class="num">${TP.esc(e.tel)}</td>
                  <td onclick="event.stopPropagation()">${isDel ? `<button class="btn btn-danger btn-sm" onclick="TP_CORE.confirmDelete(['${e.id}'])">Supprimer</button>` : `<button class="btn btn-outline btn-sm" onclick="TP.navigate('employees','detail',{id:'${e.id}'})">Fiche</button>`}</td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
        ${isDel && selectedIds.size ? `
          <div class="floating-bar">
            <strong>${selectedIds.size} salarié(s) sélectionné(s)</strong>
            <div class="flex gap-2">
              <button class="btn btn-outline btn-sm" onclick="TP_CORE.clearDel()">Désélectionner</button>
              <button class="btn btn-danger-solid btn-sm" onclick="TP_CORE.confirmDeleteSelected()">🗑 Supprimer la sélection</button>
            </div>
          </div>` : ''}`;
    }

    if (sub === 'detail') {
      const e = s.employees.find(x => x.id === TP.ui.params.id) || s.employees[0];
      return `
        <div class="flex-between mb-4">
          <div><h1>Fiche employé · ${TP.esc(e.nom)} ${TP.esc(e.prenom)}</h1><p class="muted">${TP.esc(e.matricule)} · ${TP.esc(e.section)}</p></div>
          <button class="btn btn-outline" onclick="TP.navigate('employees','list')">← Liste</button>
        </div>
        <div class="card">
          <div class="grid-2">
            <div><label class="field-label">Nom</label><input id="ed-nom" class="input" value="${TP.esc(e.nom)}"/></div>
            <div><label class="field-label">Prénom</label><input id="ed-prenom" class="input" value="${TP.esc(e.prenom)}"/></div>
            <div><label class="field-label">Mail</label><input id="ed-mail" class="input" value="${TP.esc(e.mail)}"/></div>
            <div><label class="field-label">Téléphone</label><input id="ed-tel" class="input" value="${TP.esc(e.tel)}"/></div>
            <div><label class="field-label">Fonction</label><input id="ed-fn" class="input" value="${TP.esc(e.fonction)}"/></div>
            <div><label class="field-label">Section</label><select id="ed-sec" class="select">${s.company.sections.map(x => `<option ${e.section === x ? 'selected' : ''}>${TP.esc(x)}</option>`).join('')}</select></div>
          </div>
          <div class="banner banner-blue mt-4">Chaque modification est automatiquement enregistrée dans les journaux avec l'avant/après et l'auteur.</div>
          <div class="flex-between mt-4">
            <span class="pill pill-blue">Planning : ${TP.esc(e.shift)}</span>
            <button class="btn btn-primary" onclick="TP_CORE.saveEmployee('${e.id}')">✓ Enregistrer les modifications</button>
          </div>
        </div>`;
    }

    if (sub === 'salaries') {
      if (!TP.hasPerm('salaries')) return `<div class="banner banner-red">Accès restreint : le rôle ${s.currentRole} n'a pas accès aux données salariales.</div>`;
      return `
        <div class="flex-between mb-4">
          <div><h1>Salaires des salariés</h1><p class="muted">Novembre 2026 · Calcul automatique des retenues issues des règles de pointage</p></div>
          <button class="btn btn-outline" onclick="TP.navigate('employees','index')">← Retour</button>
        </div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Salarié</th><th>Fonction</th><th>Section</th><th>Salaire de base</th><th>Retenues retards</th><th>Net à payer</th><th></th></tr></thead>
            <tbody>
              ${s.employees.map(e => `
                <tr>
                  <td><strong>${TP.esc(e.nom)} ${TP.esc(e.prenom)}</strong></td><td>${TP.esc(e.fonction)}</td><td>${TP.esc(e.section)}</td>
                  <td class="num">${TP.fmtMoney(e.baseSalary)}</td>
                  <td class="num" style="color:${e.deduction ? '#DC2626' : 'inherit'};">${e.deduction ? '- ' + TP.fmtMoney(e.deduction) : '0'}</td>
                  <td class="num"><strong>${TP.fmtMoney(e.baseSalary - e.deduction)}</strong></td>
                  <td><button class="btn btn-outline btn-sm" onclick="TP_CORE.editSalary('${e.id}')">Ajuster</button></td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>`;
    }

    if (sub === 'promotions') {
      const sorted = [...s.employees].sort((a, b) => b.score - a.score);
      return `
        <div class="flex-between mb-4">
          <div><h1>Liste de promotion (IA)</h1><p class="muted">Suggestions classées selon ponctualité, assiduité et avis des managers</p></div>
          <div class="flex gap-2">
            <button class="btn btn-outline" onclick="TP.navigate('employees','index')">← Retour</button>
            <button class="btn btn-amber" onclick="TP_CORE.recalcPromotions()">↻ Recalculer avec l'IA</button>
          </div>
        </div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Rang</th><th>Salarié</th><th>Performance</th><th>Avis manager</th><th>Note / 20</th><th></th></tr></thead>
            <tbody>
              ${sorted.map((e, i) => `
                <tr>
                  <td><strong>#${i + 1}</strong></td>
                  <td><strong>${TP.esc(e.nom)} ${TP.esc(e.prenom)}</strong><div class="muted small">${TP.esc(e.fonction)}</div></td>
                  <td class="num">${Math.min(99, Math.round(e.score * 5.1))} %</td>
                  <td><span class="pill ${e.managerAvis === 'Favorable' ? 'pill-green' : e.managerAvis === 'Réservé' ? 'pill-amber' : 'pill-gray'}">${TP.esc(e.managerAvis)}</span></td>
                  <td class="num"><strong>${e.score.toFixed(1)} / 20</strong></td>
                  <td><button class="btn btn-amber btn-sm" onclick="TP_CORE.showPromoDetail('${e.id}')">Détail & Valider</button></td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>`;
    }

    return `
      <div class="flex-between mb-4">
        <div><h1>Avis des managers</h1><p class="muted">Emails reçus sur ${TP.esc(s.company.email)} · Traités sans invention par l'IA</p></div>
        <div class="flex gap-2">
          <button class="btn btn-outline" onclick="TP.navigate('employees','index')">← Retour</button>
          <button class="btn btn-outline" onclick="TP_CORE.addManagerModal()">+ Ajouter un manager</button>
          <button class="btn btn-amber" onclick="TP_CORE.processManagerEmails()">★ Traiter emails avec l'IA</button>
        </div>
      </div>
      <div class="grid-3 mb-4">
        ${s.managers.map(m => `
          <div class="card card-hover" onclick="TP_CORE.openManagerTable('${m.id}')">
            <div class="flex gap-3"><span class="avatar">${TP.initials(m.name)}</span><div><strong>${TP.esc(m.name)}</strong><div class="muted small">${TP.esc(m.section)} · ${TP.esc(m.email)}</div></div></div>
            <div class="flex-between mt-3"><strong class="num" style="font-size:20px;">${m.reviews.length} avis</strong><span class="pill pill-gray">Email du ${m.lastEmail}</span></div>
          </div>`).join('')}
      </div>
      <h3>Boîte de réception managers</h3>
      <div class="table-wrap mt-2">
        <table>
          <thead><tr><th>Manager</th><th>Objet</th><th>Reçu</th><th>État</th></tr></thead>
          <tbody>${s.managerEmails.map(em => `<tr><td><strong>${TP.esc(em.manager)}</strong></td><td>${TP.esc(em.subject)}<div class="muted small">${TP.esc(em.body.slice(0, 78))}...</div></td><td>${TP.esc(em.received)}</td><td><span class="pill ${em.status === 'Traité' ? 'pill-green' : 'pill-amber'}">${em.status}</span></td></tr>`).join('')}</tbody>
        </table>
      </div>`;
  };

  Object.assign(window.TP_CORE, {
    startManual() { manualCount = Math.max(1, Math.min(20, +(document.getElementById('manual-qty')?.value || 1))); manualCurrent = 1; TP.navigate('employees', 'manual'); },
    submitManual() {
      const nom = document.getElementById('m-nom').value.trim();
      const prenom = document.getElementById('m-prenom').value.trim();
      if (!nom || !prenom) return TP.toast('Nom et prénom obligatoires.');
      const section = document.getElementById('m-sec')?.value || TP.state.company.sections[0];
      const fonction = document.getElementById('m-fn').value.trim() || 'Collaborateur';
      TP.state.employees.push({
        id: 'emp-' + Date.now(), matricule: 'N° 00' + (TP.state.employees.length + 32),
        nom, prenom, fonction, section, mail: document.getElementById('m-mail').value.trim() || `${prenom.toLowerCase()}@ravelo.mg`,
        tel: document.getElementById('m-tel').value.trim() || '+261 34 00 000 00', baseSalary: 1150000, deduction: 0,
        shift: 'Jour · 06h–13h', arrivee: '08:00', retardMin: 0, heures: '8h00', sup: '0h00', fin: '17:00',
        nbRetards: 0, status: 'Présent', telework: false, managerAvis: 'En attente', score: 15.0
      });
      TP.logAction('Insérer', `Salarié ${nom} ${prenom} inscrit`, 'Inscription manuelle', '—', `${section} · ${fonction}`, 'Employés');
      if (manualCurrent < manualCount) { manualCurrent++; TP.save(); TP.render(); TP.toast(`Fiche enregistrée (${manualCurrent - 1}/${manualCount})`); }
      else { TP.save(); TP.navigate('employees', 'list'); TP.toast('Inscription manuelle terminée !'); }
    },
    runPhotoAI() {
      TP.toast('Analyse OCR IA simulée...');
      ocrDrafts = [
        { nom: 'Rasoanaivo', prenom: 'Tiana', mail: '', tel: '+261 34 22 908 11', section: TP.state.company.sections[0], fonction: 'Chargé clientèle', aiNom: true, aiPrenom: true, aiMail: false, aiTel: true },
        { nom: 'Andriamanantena', prenom: 'Haja', mail: 'haja.a@ravelo.mg', tel: '', section: TP.state.company.sections[1] || TP.state.company.sections[0], fonction: 'Assistant', aiNom: true, aiPrenom: true, aiMail: true, aiTel: false }
      ];
      ocrIdx = 0; setTimeout(() => TP.navigate('employees', 'ocr_validate'), 450);
    },
    runExcelAI() {
      TP.openModal('Import Excel / CSV assisté par IA', `<p class="muted mb-3">Chargez un CSV local ou simulez un import Excel intelligent.</p><input type="file" accept=".csv,.txt" class="input mb-3" onchange="TP_CORE.handleCsvFile(this)"/><button class="btn btn-amber" onclick="TP.closeModal();TP_CORE.runPhotoAI();">Simuler mapping automatique (2 fiches)</button>`);
    },
    handleCsvFile(inp) {
      const f = inp.files?.[0]; if (!f) return;
      const r = new FileReader();
      r.onload = () => {
        const lines = String(r.result).split(/\r?\n/).filter(Boolean).slice(1, 5);
        if (!lines.length) return TP.toast('Aucune ligne trouvée.');
        ocrDrafts = lines.map(l => {
          const [nom = '', prenom = '', fonction = 'Collaborateur', mail = '', tel = ''] = l.split(/[,;]/);
          return { nom: nom.trim(), prenom: prenom.trim(), fonction: fonction.trim(), mail: mail.trim(), tel: tel.trim(), section: TP.state.company.sections[0], aiNom: !!nom, aiPrenom: !!prenom, aiMail: !!mail, aiTel: !!tel };
        });
        ocrIdx = 0; TP.closeModal(); TP.navigate('employees', 'ocr_validate');
      };
      r.readAsText(f);
    },
    updateOcr(k, v) { if (ocrDrafts[ocrIdx]) ocrDrafts[ocrIdx][k] = v; },
    skipOcr() { ocrIdx++; if (ocrIdx >= ocrDrafts.length) TP.navigate('employees', 'list'); else TP.render(); },
    acceptOcr() {
      const d = ocrDrafts[ocrIdx];
      TP.state.employees.push({ id: 'emp-' + Date.now(), matricule: 'N° 00' + (TP.state.employees.length + 32), nom: d.nom, prenom: d.prenom, fonction: d.fonction, section: d.section, mail: d.mail, tel: d.tel, baseSalary: 1200000, deduction: 0, shift: 'Jour · 06h–13h', arrivee: '08:00', retardMin: 0, heures: '8h00', sup: '0h00', fin: '17:00', nbRetards: 0, status: 'Présent', telework: false, managerAvis: 'En attente', score: 15.5 });
      TP.logAction('Insérer', `Import IA validé : ${d.nom} ${d.prenom}`, 'Validation IA', '—', d.section, 'Employés');
      ocrIdx++; TP.save();
      if (ocrIdx >= ocrDrafts.length) { TP.navigate('employees', 'list'); TP.toast('Fiches importées !'); } else TP.render();
    },
    openIntranetForm() {
      TP.openModal('Portail Intranet · Demande', `<div class="grid-2"><div><label class="field-label">Nom</label><input id="in-nom" class="input" value="Raharison"/></div><div><label class="field-label">Prénom</label><input id="in-pre" class="input" value="Niry"/></div><div><label class="field-label">Mail</label><input id="in-mail" class="input" value="niry.r@ravelo.mg"/></div><div><label class="field-label">Section</label><select id="in-sec" class="select">${TP.state.company.sections.map(x => `<option>${TP.esc(x)}</option>`).join('')}</select></div></div><div class="mt-3"><label class="field-label">Poste</label><input id="in-fn" class="input" value="Chargé logistique"/></div><button class="btn btn-amber mt-4" onclick="TP_CORE.submitIntranet()">Envoyer en attente</button>`);
    },
    submitIntranet() {
      TP.state.pendingRegistrations.unshift({ id: 'pend-' + Date.now(), nom: document.getElementById('in-nom').value, prenom: document.getElementById('in-pre').value, mail: document.getElementById('in-mail').value, tel: '+261 34 11 009 22', section: document.getElementById('in-sec').value, fonction: document.getElementById('in-fn').value });
      TP.closeModal(); TP.save(); TP.render(); TP.toast('Demande intranet enregistrée.');
    },
    approvePending(id) {
      const idx = TP.state.pendingRegistrations.findIndex(p => p.id === id); if (idx < 0) return;
      const p = TP.state.pendingRegistrations.splice(idx, 1)[0];
      TP.state.employees.push({ id: 'emp-' + Date.now(), matricule: 'N° 00' + (TP.state.employees.length + 32), nom: p.nom, prenom: p.prenom, fonction: p.fonction, section: p.section, mail: p.mail, tel: p.tel, baseSalary: 1200000, deduction: 0, shift: 'Jour · 06h–13h', arrivee: '08:00', retardMin: 0, heures: '8h00', sup: '0h00', fin: '17:00', nbRetards: 0, status: 'Présent', telework: false, managerAvis: 'En attente', score: 15.0 });
      TP.logAction('Insérer', `Intranet validé : ${p.nom} ${p.prenom}`, 'Validation Intranet', 'En attente', 'Actif', 'Employés');
      TP.save(); TP.render(); TP.toast(`${p.nom} ${p.prenom} ajouté.`);
    },
    rejectPending(id) { TP.state.pendingRegistrations = TP.state.pendingRegistrations.filter(p => p.id !== id); TP.save(); TP.render(); },
    downloadBadges() {
      const html = `<html><body style="font-family:sans-serif;"><h2>Badges ${TP.esc(TP.state.company.name)}</h2>` + TP.state.employees.map(e => `<div style="border:1px solid #0B2E33;padding:12px;margin:8px;display:inline-block;width:210px;"><strong>${TP.esc(e.nom)} ${TP.esc(e.prenom)}</strong><br/>${TP.esc(e.fonction)}<br/>${TP.esc(e.section)} · ${TP.esc(e.matricule)}</div>`).join('') + `</body></html>`;
      TP.exportFile('badges-tempo-point.html', html);
    },
    toggleDel(id) { if (selectedIds.has(id)) selectedIds.delete(id); else selectedIds.add(id); TP.render(); },
    clearDel() { selectedIds.clear(); TP.render(); },
    confirmDelete(ids) { TP.openModal('Confirmer la suppression', `<p>Retirer <strong>${ids.length} salarié(s)</strong> ?</p><div class="flex-between mt-4"><button class="btn btn-outline" onclick="TP.closeModal()">Annuler</button><button class="btn btn-danger-solid" onclick="TP_CORE.executeDelete(${JSON.stringify(ids).replace(/"/g, '&quot;')})">Confirmer</button></div>`); },
    confirmDeleteSelected() { this.confirmDelete(Array.from(selectedIds)); },
    executeDelete(ids) { TP.state.employees = TP.state.employees.filter(e => !ids.includes(e.id)); selectedIds.clear(); TP.logAction('Supprimer', `${ids.length} salarié(s) retiré(s)`, 'Suppression RH', 'Actif', 'Supprimé', 'Employés'); TP.closeModal(); TP.save(); TP.render(); TP.toast('Suppression effectuée.'); },
    saveEmployee(id) {
      const e = TP.state.employees.find(x => x.id === id); const oldFn = e.fonction;
      e.nom = document.getElementById('ed-nom').value; e.prenom = document.getElementById('ed-prenom').value; e.mail = document.getElementById('ed-mail').value;
      e.tel = document.getElementById('ed-tel').value; e.fonction = document.getElementById('ed-fn').value; e.section = document.getElementById('ed-sec').value;
      TP.logAction('Modifier', `Fiche de ${e.nom} ${e.prenom}`, 'Mise à jour dossier RH', oldFn, e.fonction, 'Employés'); TP.save(); TP.toast('Modifications enregistrées.');
    },
    editSalary(id) {
      const e = TP.state.employees.find(x => x.id === id);
      TP.openModal(`Salaire · ${e.nom} ${e.prenom}`, `<label class="field-label">Salaire de base</label><input id="sal-base" type="number" class="input mb-3" value="${e.baseSalary}"/><label class="field-label">Retenues</label><input id="sal-ded" type="number" class="input mb-4" value="${e.deduction}"/><button class="btn btn-amber" onclick="TP_CORE.saveSalary('${e.id}')">Enregistrer</button>`);
    },
    saveSalary(id) {
      const e = TP.state.employees.find(x => x.id === id); const prev = e.baseSalary;
      e.baseSalary = +document.getElementById('sal-base').value; e.deduction = +document.getElementById('sal-ded').value;
      TP.logAction('Modifier', `Salaire de ${e.nom} ${e.prenom}`, 'Ajustement paie', TP.fmtMoney(prev), TP.fmtMoney(e.baseSalary), 'Salaires');
      TP.closeModal(); TP.save(); TP.render();
    },
    recalcPromotions() { TP.state.employees.forEach(e => { e.score = Math.min(19.6, Math.max(12.0, +(e.score + (Math.random() * 0.4 - 0.15)).toFixed(1))); }); TP.save(); TP.render(); TP.toast('Scores recalculés par l\'IA.'); },
    showPromoDetail(id) {
      const e = TP.state.employees.find(x => x.id === id);
      TP.openModal(`Détail promotion · ${e.nom} ${e.prenom}`, `<div class="flex-between mb-3"><strong>Note globale IA</strong><span class="pill pill-green">${e.score.toFixed(1)} / 20</span></div><div class="mb-2 small">Ponctualité (${e.nbRetards} retards) <div class="progress-track mt-1"><div class="progress-fill" style="width:${Math.max(45, 100 - e.nbRetards * 12)}%"></div></div></div><div class="mb-4 small">Avis manager (${TP.esc(e.managerAvis)}) <div class="progress-track mt-1"><div class="progress-fill" style="width:${e.managerAvis === 'Favorable' ? 94 : 72}%;background:#F59E0B;"></div></div></div><div class="banner banner-amber mb-4">Validation humaine requise avant toute promotion.</div><button class="btn btn-success" onclick="TP_CORE.validatePromo('${e.id}')">✓ Valider la promotion</button>`);
    },
    validatePromo(id) { const e = TP.state.employees.find(x => x.id === id); TP.logAction('Modifier', `Promotion validée pour ${e.nom} ${e.prenom}`, 'Promotion IA', e.fonction, 'Promu · ' + e.fonction, 'Promotions'); TP.closeModal(); TP.toast('Promotion validée.'); },
    addManagerModal() { TP.openModal('Ajouter un manager', `<label class="field-label">Nom</label><input id="nm-name" class="input mb-3" placeholder="Mme / M."/><label class="field-label">Section</label><select id="nm-sec" class="select mb-3">${TP.state.company.sections.map(s => `<option>${TP.esc(s)}</option>`).join('')}</select><label class="field-label">Email</label><input id="nm-mail" class="input mb-4" placeholder="manager@ravelo.mg"/><button class="btn btn-amber" onclick="TP_CORE.saveManager()">Ajouter</button>`); },
    saveManager() { TP.state.managers.push({ id: 'mgr-' + Date.now(), name: document.getElementById('nm-name').value, section: document.getElementById('nm-sec').value, email: document.getElementById('nm-mail').value, lastEmail: 'Aujourd\'hui', reviews: [] }); TP.closeModal(); TP.save(); TP.render(); },
    processManagerEmails() { TP.state.managerEmails.forEach(em => em.status = 'Traité'); TP.save(); TP.render(); TP.toast('Emails traités avec l\'IA.'); },
    openManagerTable(id) {
      const m = TP.state.managers.find(x => x.id === id);
      TP.openModal(`Avis de ${m.name} (${m.section})`, `<div class="table-wrap"><table><thead><tr><th>Salarié</th><th>Note</th><th>Points forts</th><th>Commentaire</th></tr></thead><tbody>${m.reviews.map(r => `<tr><td><strong>${TP.esc(r.empName)}</strong></td><td>${TP.esc(r.note)}</td><td>${TP.esc(r.strengths)}</td><td>${TP.esc(r.comment)}</td></tr>`).join('') || '<tr><td colspan="4" class="muted">Aucun avis.</td></tr>'}</tbody></table></div>`, true);
    }
  });
})();

(function () {
  window.TP_EXT_MODULES = window.TP_EXT_MODULES || {};
  window.TP_EXT = window.TP_EXT || {};

  window.TP_EXT_MODULES.predictive = function () {
    const s = TP.state;
    const pr = s.predictive;
    const mg = pr.lang === 'MG';
    const lateCount = s.employees.filter(e => e.status === 'Retard' || e.status === 'Absent').length;
    const overdueTasks = s.tasks.filter(t => t.status !== 'Terminée' && t.due <= '2026-11-20').length;

    const forecasts = [
      {
        id: 'pred-1',
        title: mg ? 'Fironan\'ny fahatarana sy tsy fahatongavana (7 andro)' : 'Tendance absences & retards (7 prochains jours)',
        observed: `${lateCount} cas aujourd'hui`,
        forecast: `${Math.max(2, lateCount + 1)} cas/jour (± 1)`,
        confidence: 82, sample: '45 jours d\'historique',
        factor: 'Pluies saisonnières Antananarivo + pic ligne Ivato',
        rec: mg ? 'Manomana fanoloana vonjimaika amin\'ny ekipa maraina.' : 'Prévoir un renfort matinal sur le quai Logistique entre 07h45 et 08h30.'
      },
      {
        id: 'pred-2',
        title: mg ? 'Tandindonin-doza amin\'ny tetikasa sy asa' : 'Risque de dépassement d\'échéance Projets & Tâches',
        observed: `${overdueTasks} tâche(s) critique(s)`,
        forecast: `${overdueTasks + 1} livrable(s) à risque (± 1)`,
        confidence: 76, sample: `${s.tasks.length} tâches actives`,
        factor: 'Dépendance non résolue sur MP-0004 Quai logistique',
        rec: mg ? 'Hamarino aloha ny fampifandraisana ny milina MP-0004.' : 'Prioriser le déblocage de la tâche MP-0004 avant la clôture paie.'
      },
      {
        id: 'pred-3',
        title: mg ? 'Enta-mavesatra sy ora fanampiny' : 'Charge de travail & heures supplémentaires par service',
        observed: 'Logistique : +14 %',
        forecast: 'Surcharge modérée fin de mois (± 4 %)',
        confidence: 69, sample: '30 jours d\'historique',
        factor: 'Campagne fin d\'année + jours fériés locaux configurés',
        rec: mg ? 'Mizara ny asa eo amin\'ny Marketing sy Logistique.' : 'Rééquilibrer 4h de charge sur les créneaux disponibles du jeudi.'
      }
    ];

    return `
      <div class="flex-between mb-4">
        <div>
          <h1>${mg ? 'Tabilaon\'ny vinavina IA (Orinasa eto an-toerana)' : 'Tableau de bord prédictif IA'}</h1>
          <p class="muted">${mg ? 'Fomba fijery mialoha ho an\'ny orinasa eto Madagasikara' : 'Anticipation opérationnelle adaptée au contexte local et faible connectivité'}</p>
        </div>
        <div class="flex gap-2">
          ${TP.isModuleEnabled('predictiveMalagasy') ? `<button class="btn btn-outline btn-sm" onclick="TP.state.predictive.lang=TP.state.predictive.lang==='FR'?'MG':'FR';TP.save();TP.render();">${mg ? '🇲🇬 Malagasy → FR' : '🇫🇷 Français → MG'}</button>` : ''}
          <button class="btn ${pr.offlineMode ? 'btn-amber' : 'btn-outline'} btn-sm" onclick="TP.state.predictive.offlineMode=!TP.state.predictive.offlineMode;TP.save();TP.render();">${pr.offlineMode ? '⚠ Mode hors-ligne (Synchro différée)' : '● Connexion active'}</button>
        </div>
      </div>

      <div class="banner banner-amber mb-4">
        <strong>Garde-fou éthique :</strong> Les prévisions ne doivent jamais être utilisées seules pour sanctionner, recruter, licencier ou évaluer individuellement un salarié.
      </div>

      <div class="grid-3">
        ${forecasts.map(f => {
          const dec = pr.decisions[f.id] || { status: 'En attente', comment: '' };
          return `
            <div class="card">
              <div class="flex-between mb-2"><span class="pill pill-blue">Confiance ${f.confidence} %</span><span class="small muted">${f.sample}</span></div>
              <h3>${f.title}</h3>
              <div class="mt-3 small">Observé : <strong>${f.observed}</strong></div>
              <div class="mt-1" style="font-size:16px;font-weight:800;color:#0B2E33;">Prévision : ${f.forecast}</div>
              <div class="muted small mt-2">Facteurs : ${f.factor}</div>
              <div class="banner banner-blue mt-3 small">💡 ${f.rec}</div>
              ${dec.comment ? `<div class="muted small mt-2">Note : ${TP.esc(dec.comment)}</div>` : ''}
              <div class="flex-between mt-3">
                <span class="pill ${dec.status === 'Confirmée' ? 'pill-green' : dec.status === 'Ignorée' ? 'pill-gray' : 'pill-amber'}">${dec.status}</span>
                <div class="flex gap-2">
                  <button class="btn btn-success btn-sm" onclick="TP_EXT.decidePred('${f.id}','Confirmée')">Confirmer</button>
                  <button class="btn btn-outline btn-sm" onclick="TP_EXT.decidePred('${f.id}','Ignorée')">Ignorer</button>
                </div>
              </div>
            </div>`;
        }).join('')}
      </div>

      <div class="card mt-4">
        <h3 class="mb-2">Jours fériés locaux pris en compte (${TP.esc(s.company.country)})</h3>
        <div class="flex gap-2" style="flex-wrap:wrap;">${s.company.holidays.map(h => `<span class="pill pill-gray">${TP.esc(h)}</span>`).join('')}</div>
      </div>`;
  };

  Object.assign(window.TP_EXT, {
    decidePred(id, status) { TP.state.predictive.decisions[id] = { status, comment: '' }; TP.save(); TP.render(); TP.toast(`Alerte prédictive : ${status}`); }
  });
})();

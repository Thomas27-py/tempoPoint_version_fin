window.TP_DEFAULT_DATA = function () {
  return {
    installed: false,
    loggedIn: false,
    currentRole: 'PDG',
    company: {
      name: 'Ravelo Distribution',
      type: 'type1',
      sector: 'Tertiaire',
      subSector: 'Distribution & Logistique',
      email: 'contact@ravelo.mg',
      phone: '+261 20 22 456 78',
      country: 'Madagascar',
      city: 'Antananarivo',
      sites: ['Siège Antananarivo', 'Entrepôt Ivato', 'Agence Tamatave'],
      headcount: 48,
      currency: 'Ar',
      language: 'FR',
      teleworkEnabled: true,
      pointingMethod: 'Badge + empreinte',
      paymentPlan: 'Abonnement global par an',
      hostingMode: 'hybride',
      machinesOrdered: 4,
      supportPackage: 'Installation sur site + Formation équipes',
      holidays: [
        '2026-01-01 · Jour de l\'an',
        '2026-03-29 · Commémoration 1947',
        '2026-05-01 · Fête du Travail',
        '2026-06-26 · Fête de l\'Indépendance',
        '2026-11-01 · Toussaint',
        '2026-12-25 · Noël'
      ],
      sections: ['Marketing', 'Finance', 'Logistique', 'Informatique', 'RH']
    },
    enabledModules: {
      hrDecisions: true,
      payrollDeductions: true,
      projectsTasks: true,
      projectBudgets: true,
      automation: true,
      predictive: true,
      predictiveMalagasy: true,
      digitalVision: true,
      tempoApi: true
    },
    rolePermissions: {
      PDG: { salaries: true, deleteEmp: true, rules: true, automation: true, securityCloud: true, api: true, accounts: true, projects: true },
      DRH: { salaries: true, deleteEmp: true, rules: true, automation: true, securityCloud: false, api: false, accounts: false, projects: true },
      DG:  { salaries: true, deleteEmp: false, rules: true, automation: true, securityCloud: true, api: true, accounts: false, projects: true },
      SG:  { salaries: false, deleteEmp: false, rules: false, automation: false, securityCloud: false, api: false, accounts: false, projects: true }
    },
    adminAccount: {
      name: 'Rabe Hery',
      email: 'hery.rabe@ravelo.mg',
      phone: '+261 34 12 345 67',
      password: 'admin',
      faceRegistered: true,
      faceMandatory: true,
      lastFaceUpdate: '15/11/2026'
    },
    companyAccounts: [
      { id: 'acc-1', name: 'Rabe Hery', role: 'PDG', email: 'hery.rabe@ravelo.mg', status: 'Connecté' },
      { id: 'acc-2', name: 'Rasoa Fanja', role: 'DRH', email: 'fanja.rasoa@ravelo.mg', status: 'Hors ligne' },
      { id: 'acc-3', name: 'Razafy Tojo', role: 'DG', email: 'tojo.razafy@ravelo.mg', status: 'Hors ligne' },
      { id: 'acc-4', name: 'Andrianina Lova', role: 'SG', email: 'lova.a@ravelo.mg', status: 'Connecté' }
    ],
    employees: [
      { id: 'emp-1', matricule: 'N° 0012', nom: 'Rabe', prenom: 'Hery', fonction: 'Admin système', section: 'Informatique', mail: 'hery.rabe@ravelo.mg', tel: '034 12 345 67', baseSalary: 1450000, deduction: 0, shift: 'Jour · 06h–13h', arrivee: '07:58', retardMin: 0, heures: '8h04', sup: '0h04', fin: '17:02', nbRetards: 0, status: 'Présent', telework: true, managerAvis: 'Favorable', score: 16.1 },
      { id: 'emp-2', matricule: 'N° 0014', nom: 'Rakoto', prenom: 'Dev', fonction: 'Développeur junior', section: 'Informatique', mail: 'dev.rakoto@ravelo.mg', tel: '032 11 222 33', baseSalary: 1200000, deduction: 28000, shift: 'Jour · 06h–13h', arrivee: '08:12', retardMin: 12, heures: '8h03', sup: '0h03', fin: '17:15', nbRetards: 3, status: 'Retard', telework: true, managerAvis: 'Réservé', score: 15.2 },
      { id: 'emp-3', matricule: 'N° 0017', nom: 'Randria', prenom: 'Mialy', fonction: 'Chargée de communication', section: 'Marketing', mail: 'mialy.randria@ravelo.mg', tel: '032 04 567 89', baseSalary: 1300000, deduction: 12000, shift: 'Jour · 06h–13h', arrivee: '07:55', retardMin: 0, heures: '8h05', sup: '0h05', fin: '17:02', nbRetards: 0, status: 'Présent', telework: true, managerAvis: 'Favorable', score: 18.2 },
      { id: 'emp-4', matricule: 'N° 0019', nom: 'Razafy', prenom: 'Tojo', fonction: 'Comptable', section: 'Finance', mail: 'tojo.razafy@ravelo.mg', tel: '033 22 110 09', baseSalary: 1650000, deduction: 0, shift: 'Jour · 06h–13h', arrivee: '08:01', retardMin: 0, heures: '8h30', sup: '0h30', fin: '17:30', nbRetards: 0, status: 'Présent', telework: true, managerAvis: 'Favorable', score: 17.5 },
      { id: 'emp-5', matricule: 'N° 0021', nom: 'Rasoa', prenom: 'Fanja', fonction: 'Assistante RH', section: 'RH', mail: 'fanja.rasoa@ravelo.mg', tel: '034 55 667 78', baseSalary: 1100000, deduction: 6000, shift: 'Nuit · 13h–21h', arrivee: '08:04', retardMin: 4, heures: '7h56', sup: '0h00', fin: '17:00', nbRetards: 1, status: 'Présent', telework: true, managerAvis: 'En attente', score: 15.4 },
      { id: 'emp-6', matricule: 'N° 0024', nom: 'Andrianina', prenom: 'Lova', fonction: 'Logisticien', section: 'Logistique', mail: 'lova.a@ravelo.mg', tel: '034 98 765 43', baseSalary: 1000000, deduction: 40000, shift: 'Nuit · 21h–06h', arrivee: '—', retardMin: 0, heures: '—', sup: '0h00', fin: '—', nbRetards: 4, status: 'Absent', telework: false, managerAvis: 'Favorable', score: 14.8 },
      { id: 'emp-7', matricule: 'N° 0028', nom: 'Ravao', prenom: 'Soa', fonction: 'Chargée marketing digital', section: 'Marketing', mail: 'soa.ravao@ravelo.mg', tel: '034 45 123 90', baseSalary: 1150000, deduction: 15000, shift: 'Jour · 06h–13h', arrivee: '08:12', retardMin: 12, heures: '8h03', sup: '0h03', fin: '17:15', nbRetards: 3, status: 'Retard', telework: false, managerAvis: 'Réservé', score: 14.3 },
      { id: 'emp-8', matricule: 'N° 0031', nom: 'Andry', prenom: 'Hasina', fonction: 'Analyste données', section: 'Marketing', mail: 'hasina.a@ravelo.mg', tel: '033 19 887 11', baseSalary: 1380000, deduction: 4000, shift: 'Jour · 06h–13h', arrivee: '08:04', retardMin: 4, heures: '7h56', sup: '0h00', fin: '17:00', nbRetards: 1, status: 'Présent', telework: true, managerAvis: 'Favorable', score: 16.9 }
    ],
    pendingRegistrations: [
      { id: 'pend-1', nom: 'Rakotoarivelo', prenom: 'Fy', mail: 'fy.r@ravelo.mg', tel: '+261 34 71 220 11', section: 'Marketing', fonction: 'Chef de projet junior' },
      { id: 'pend-2', nom: 'Raveloson', prenom: 'Sitraka', mail: 'sitraka@ravelo.mg', tel: '+261 32 88 901 02', section: 'Finance', fonction: 'Aide comptable' },
      { id: 'pend-3', nom: 'Randriamanana', prenom: 'Lalaina', mail: 'lalaina@ravelo.mg', tel: '+261 33 44 102 55', section: 'Logistique', fonction: 'Magasinier' }
    ],
    managers: [
      {
        id: 'mgr-1', name: 'Mme Rasoa', section: 'Marketing', email: 'rasoa@ravelo.mg', lastEmail: '15/11',
        reviews: [
          { empName: 'Randria Mialy', note: '4,5 / 5', strengths: 'Fiabilité · Communication', comment: 'Prend en charge la communication des équipes.' },
          { empName: 'Ravao Soa', note: '3 / 5', strengths: 'Créativité', comment: 'Quelques retards, mais progresse.' },
          { empName: 'Andry Hasina', note: '4 / 5', strengths: 'Autonomie · Rigueur', comment: 'Travaille seul sans difficulté.' }
        ]
      },
      {
        id: 'mgr-2', name: 'M. Rakoto', section: 'Finance', email: 'rakoto@ravelo.mg', lastEmail: '14/11',
        reviews: [
          { empName: 'Razafy Tojo', note: '4,5 / 5', strengths: 'Précision · Fiabilité', comment: 'Comptable très rigoureux.' },
          { empName: 'Raveloson Sitraka', note: '3,5 / 5', strengths: 'Rapidité', comment: 'Doit mieux classer les pièces.' }
        ]
      },
      {
        id: 'mgr-3', name: 'M. Andry', section: 'Informatique', email: 'andry@ravelo.mg', lastEmail: '13/11',
        reviews: [
          { empName: 'Rabe Hery', note: '4,5 / 5', strengths: 'Architecture · Sécurité', comment: 'Assure la stabilité réseau.' },
          { empName: 'Rakoto Dev', note: '3,5 / 5', strengths: 'Apprentissage', comment: 'Doit gagner en ponctualité le matin.' }
        ]
      }
    ],
    managerEmails: [
      { id: 'em-1', manager: 'Mme Rasoa', section: 'Marketing', subject: 'Avis équipe Marketing · novembre', received: '15/11 · 17:10', status: 'Nouveau', body: 'Bonjour, voici mon avis pour novembre. Mialy est très fiable et prend en charge la communication. Soa a eu quelques retards mais progresse. Hasina est autonome et rigoureux.' },
      { id: 'em-2', manager: 'M. Rakoto', section: 'Finance', subject: 'Retour sur l\'équipe Finance', received: '14/11 · 09:42', status: 'Nouveau', body: 'Tojo Razafy maintient une excellente précision sur les bilans mensuels. Sitraka gagne en rapidité.' },
      { id: 'em-3', manager: 'M. Andry', section: 'Informatique', subject: 'Évaluation Informatique', received: '13/11 · 16:25', status: 'Nouveau', body: 'Hery Rabe pilote parfaitement les machines de pointage. Dev progresse techniquement.' },
      { id: 'em-4', manager: 'M. Ravelo', section: 'Logistique', subject: 'Avis du mois · Logistique', received: '12/11 · 11:03', status: 'Traité', body: 'Équipe logistique très sollicitée au quai Ivato.' }
    ],
    rules: {
      arrival: '08:00',
      departure: '17:00',
      lateTolerance: 10,
      latePenaltyPerMin: 1000,
      overtimeRate: 1.25,
      breaks: [
        { id: 'br-1', label: 'Pause du matin', start: '10:00', end: '10:15' },
        { id: 'br-2', label: 'Déjeuner', start: '12:00', end: '13:00' },
        { id: 'br-3', label: 'Goûter', start: '15:30', end: '15:45' }
      ],
      employeeShifts: [
        { id: 'sh-1', range: '06h – 13h', employee: 'Rabe Hery', unit: 'Jour' },
        { id: 'sh-2', range: '06h – 13h', employee: 'Rakoto Dev', unit: 'Jour' },
        { id: 'sh-3', range: '13h – 21h', employee: 'Rasoa Fanja', unit: 'Nuit' },
        { id: 'sh-4', range: '21h – 06h', employee: 'Andrianina Lova', unit: 'Nuit' }
      ],
      calendarCycle: [
        'Jour','Jour','Nuit','Nuit','Repos','Jour','Jour',
        'Jour','Jour','Nuit','Nuit','Repos','Jour','Jour',
        'Jour','Jour','Nuit','Nuit','Repos','Jour','Jour',
        'Jour','Jour','Nuit','Nuit','Repos','Jour','Jour','Jour','Jour'
      ]
    },
    machines: [
      {
        id: 'MP-0001', name: 'Entrée principale', ip: '192.168.1.21', status: 'En ligne', latencyMs: 12,
        method: 'Badge + empreinte', lastPunch: '08:02', connectedSince: '06h58', offlineBuffered: 0,
        pcs: [
          { pc: 'PC-RH-01', user: 'Rasoa Fanja · DRH', ip: '192.168.1.101', since: '07:30' },
          { pc: 'PC-DIR-01', user: 'Rabe Hery · PDG', ip: '192.168.1.102', since: '07:42' },
          { pc: 'PC-DG-01', user: 'Razafy Tojo · DG', ip: '192.168.1.103', since: '07:55' },
          { pc: 'PC-SG-01', user: 'Andrianina Lova · SG', ip: '192.168.1.104', since: '08:05' },
          { pc: 'PC-RH-02', user: 'Rasoa Fanja · DRH', ip: '192.168.1.105', since: '08:11' },
          { pc: 'PC-ADM-01', user: 'Rakoto Dev · Admin', ip: '192.168.1.106', since: '08:20' }
        ]
      },
      {
        id: 'MP-0002', name: 'Accueil entrepôt', ip: '192.168.1.22', status: 'En ligne', latencyMs: 18,
        method: 'Badge + mot de passe', lastPunch: '07:58', connectedSince: '06h15', offlineBuffered: 0,
        pcs: [
          { pc: 'PC-LOG-01', user: 'Andrianina Lova', ip: '192.168.1.111', since: '06:20' },
          { pc: 'PC-LOG-02', user: 'Magasinier Ivato', ip: '192.168.1.112', since: '06:35' },
          { pc: 'PC-FIN-01', user: 'Razafy Tojo', ip: '192.168.1.113', since: '07:50' }
        ]
      },
      {
        id: 'MP-0003', name: 'Entrée parking', ip: '192.168.1.23', status: 'En ligne', latencyMs: 25,
        method: 'Badge + empreinte', lastPunch: '07:45', connectedSince: '05h50', offlineBuffered: 0,
        pcs: [
          { pc: 'PC-SEC-01', user: 'Poste Sécurité', ip: '192.168.1.121', since: '06:00' },
          { pc: 'PC-MKT-01', user: 'Randria Mialy', ip: '192.168.1.122', since: '07:48' }
        ]
      },
      {
        id: 'MP-0004', name: 'Quai logistique', ip: '192.168.1.24', status: 'Hors ligne', latencyMs: null,
        method: 'Badge + mot de passe', lastPunch: 'Hier 17:03', connectedSince: '—', offlineBuffered: 7,
        pcs: []
      }
    ],
    connectionHistory: [
      { date: '15/11/2026 · 14:20', machine: 'Quai logistique', event: 'Déconnectée', type: 'machine', detail: 'Liaison perdue (7 pointages en cache local)' },
      { date: '15/11/2026 · 08:20', machine: 'Entrée principale', event: 'Poste connecté', type: 'pc', detail: 'PC-ADM-01 · Rakoto Dev' },
      { date: '15/11/2026 · 08:11', machine: 'Entrée principale', event: 'Poste connecté', type: 'pc', detail: 'PC-RH-02 · Rasoa Fanja' },
      { date: '15/11/2026 · 06:58', machine: 'Entrée principale', event: 'Connectée', type: 'machine', detail: 'Démarrage de la machine' },
      { date: '14/11/2026 · 17:03', machine: 'Quai logistique', event: 'Déconnectée', type: 'machine', detail: 'Par Rabe Hery (PDG)' },
      { date: '12/11/2026 · 09:40', machine: 'Entrée parking', event: 'Associée', type: 'machine', detail: 'Nouvelle machine MP-0003' }
    ],
    projects: [
      {
        id: 'prj-1', name: 'Déploiement Entrepôt Ivato Phase 2', section: 'Logistique', owner: 'Andrianina Lova',
        status: 'En cours', priority: 'Haute', start: '2026-11-02', end: '2026-12-10', budget: 18500000, spent: 11200000,
        objectives: 'Mettre en service les 2 nouveaux quais et synchroniser le pointage biométrique.',
        risks: 'Coupures réseau intermittentes au quai logistique',
        phases: [
          { name: 'Phase 1 · Câblage & Terminaux', milestone: '12 Nov', done: true },
          { name: 'Phase 2 · Tests Pointage & Stocks', milestone: '24 Nov', done: false },
          { name: 'Phase 3 · Mise en production', milestone: '10 Déc', done: false }
        ]
      },
      {
        id: 'prj-2', name: 'Campagne Communication Fin d\'année', section: 'Marketing', owner: 'Randria Mialy',
        status: 'En cours', priority: 'Moyenne', start: '2026-11-05', end: '2026-11-28', budget: 6400000, spent: 4100000,
        objectives: 'Lancer la campagne client B2B et organiser la fête d\'entreprise.',
        risks: 'Validation tardive des supports imprimés',
        phases: [
          { name: 'Charte & Visuels', milestone: '14 Nov', done: true },
          { name: 'Diffusion Multicanal', milestone: '25 Nov', done: false }
        ]
      },
      {
        id: 'prj-3', name: 'Audit Clôture Paie & Conformité RH', section: 'Finance', owner: 'Razafy Tojo',
        status: 'Planifié', priority: 'Critique', start: '2026-11-18', end: '2026-11-30', budget: 2500000, spent: 500000,
        objectives: 'Rapprocher les relevés de pointage, retenues et heures supplémentaires avant paie.',
        risks: 'Relevés hors-ligne non remontés',
        phases: [
          { name: 'Extraction Pointages', milestone: '22 Nov', done: false },
          { name: 'Validation Direction', milestone: '26 Nov', done: false }
        ]
      }
    ],
    tasks: [
      { id: 'tsk-1', projectId: 'prj-1', title: 'Reconnecter terminal MP-0004 Quai logistique', assignee: 'Rabe Hery', section: 'Informatique', priority: 'Critique', status: 'En cours', start: '2026-11-18', due: '2026-11-19', hours: 4, blocker: 'Switch PoE à vérifier', checklist: [{ text: 'Tester câble RJ45', done: true }, { text: 'Vider cache hors-ligne', done: false }], comments: ['7 pointages en attente détectés.'], dependsOn: '' },
      { id: 'tsk-2', projectId: 'prj-2', title: 'Finaliser programme Fête d\'entreprise', assignee: 'Randria Mialy', section: 'Marketing', priority: 'Haute', status: 'En validation', start: '2026-11-17', due: '2026-11-20', hours: 5, blocker: '', checklist: [{ text: 'Confirmer traiteur', done: true }, { text: 'Envoyer invitations', done: true }], comments: ['Prêt pour validation PDG.'], dependsOn: '' },
      { id: 'tsk-3', projectId: 'prj-3', title: 'Vérifier écarts retards novembre', assignee: 'Razafy Tojo', section: 'Finance', priority: 'Haute', status: 'À faire', start: '2026-11-21', due: '2026-11-25', hours: 6, blocker: '', checklist: [{ text: 'Exporter stats mensuelles', done: false }], comments: [], dependsOn: 'tsk-1' },
      { id: 'tsk-4', projectId: 'prj-1', title: 'Former équipe nuit Ivato sur nouveaux badges', assignee: 'Rasoa Fanja', section: 'RH', priority: 'Moyenne', status: 'À faire', start: '2026-11-22', due: '2026-11-24', hours: 3, blocker: '', checklist: [{ text: 'Imprimer guides', done: true }], comments: [], dependsOn: '' },
      { id: 'tsk-5', projectId: 'prj-2', title: 'Analyser retombées campagne Q4', assignee: 'Andry Hasina', section: 'Marketing', priority: 'Normale', status: 'Terminée', start: '2026-11-10', due: '2026-11-16', hours: 4, blocker: '', checklist: [{ text: 'Tableau KPI', done: true }], comments: ['Livré dans les délais.'], dependsOn: '' }
    ],
    events: [
      { id: 'ev-1', title: 'Revue mensuelle', date: '2026-11-17', time: '14:00 – 16:00', type: 'Réunion', section: 'PDG, DG, DRH, managers', place: 'Salle de réunion · 2e étage', reminder: 'La veille à 17:00', color: 'blue' },
      { id: 'ev-2', title: 'Formation sécurité & incendie', date: '2026-11-19', time: '15:00 – 16:30', type: 'Formation', section: 'Logistique', place: 'Entrepôt Ivato', reminder: '2h avant', color: 'green' },
      { id: 'ev-3', title: 'Fête d\'entreprise', date: '2026-11-20', time: '15:00 – 17:30', type: 'Événement', section: 'Toute l\'entreprise', place: 'Siège Ravelo', reminder: 'La veille', color: 'dark' },
      { id: 'ev-4', title: 'Clôture paie novembre', date: '2026-11-26', time: '09:00 – 12:00', type: 'Échéance', section: 'Finance & RH', place: 'Bureau Finance', reminder: '48h avant', color: 'red' }
    ],
    automations: [
      {
        id: 'aut-1', name: 'Onboarding nouvel employé validé', active: true, sensitive: false,
        trigger: 'Nouvelle inscription validée', condition: 'Toutes sections', action: 'Créer tâches d\'intégration + Notifier DRH + Générer badge',
        runs: 14, lastRun: '15/11/2026 · 16:10'
      },
      {
        id: 'aut-2', name: 'Anomalie de pointage / Machine hors ligne', active: true, sensitive: false,
        trigger: 'Machine déconnectée > 15 min', condition: 'Section Informatique ou Logistique', action: 'Créer tâche de vérification (sans modifier le relevé)',
        runs: 6, lastRun: '15/11/2026 · 14:22'
      },
      {
        id: 'aut-3', name: 'Application retenues retards sur paie', active: true, sensitive: true,
        trigger: 'Date mensuelle : 25 du mois', condition: 'Retard cumulé > 30 min', action: 'Préparer calcul retenue + Demander validation humaine DRH/PDG',
        runs: 3, lastRun: '25/10/2026 · 09:00'
      },
      {
        id: 'aut-4', name: 'Rappel échéance projet J-2', active: false, sensitive: false,
        trigger: '2 jours avant échéance tâche/jalon', condition: 'Priorité Haute ou Critique', action: 'Notifier responsable + Ajouter point dans Agenda',
        runs: 9, lastRun: '14/11/2026 · 08:00'
      }
    ],
    approvals: [
      { id: 'apr-1', workflow: 'Application retenues retards sur paie', detail: 'Validation retenue novembre : Rakoto Dev (-28 000 Ar), Andrianina Lova (-40 000 Ar).', requestedAt: '18/11/2026 · 08:30', status: 'En attente', comment: '' },
      { id: 'apr-2', workflow: 'Suggestion Promotion IA', detail: 'Validation promotion Randria Mialy (Score 18,2/20 · Avis Favorable).', requestedAt: '17/11/2026 · 17:00', status: 'En attente', comment: '' }
    ],
    automationLogs: [
      { date: '15/11/2026 · 16:10', scenario: 'Onboarding nouvel employé validé', status: 'Succès', note: '3 tâches d\'intégration générées.' },
      { date: '15/11/2026 · 14:22', scenario: 'Anomalie de pointage / Machine hors ligne', status: 'Succès', note: 'Tâche créée suite perte MP-0004.' },
      { date: '14/11/2026 · 18:00', scenario: 'Rappel échéance projet J-2', status: 'Erreur simulée', note: 'Destinataire absent de l\'annuaire temporaire.' }
    ],
    securityCloud: {
      storageMode: 'hybride',
      retentionYears: 3,
      mfaRequired: true,
      encryptionAtRest: true,
      encryptionInTransit: true,
      biometricCloudLocked: true,
      lastConsentDate: '15/11/2026 · 21:15',
      lastConsentAuthor: 'Rabe Hery (PDG)',
      categories: {
        config: { label: 'Configuration de l\'entreprise', cloud: true, date: '15/11/2026' },
        employees: { label: 'Dossiers et informations des employés', cloud: false, date: '15/11/2026' },
        attendance: { label: 'Données de pointage et historiques de présence', cloud: true, date: '15/11/2026' },
        projects: { label: 'Projets, tâches, planning et agenda', cloud: true, date: '15/11/2026' },
        documents: { label: 'Documents et pièces jointes', cloud: false, date: '15/11/2026' },
        logs: { label: 'Journaux techniques et journaux d\'audit', cloud: true, date: '15/11/2026' },
        analytics: { label: 'Données analytiques des tableaux de bord', cloud: true, date: '15/11/2026' },
        biometrics: { label: 'Gabarits biométriques faciaux & empreintes (Protégé)', cloud: false, locked: true, date: 'Bloqué par défaut' }
      },
      securityAlerts: [
        { id: 'sec-1', date: '18/11/2026 · 07:12', severity: 'Moyen', msg: 'Tentative de connexion hors plage horaire sur PC-ADM-01 (IP locale 192.168.1.106)', status: 'À vérifier' },
        { id: 'sec-2', date: '15/11/2026 · 14:20', severity: 'Faible', msg: 'Perte de liaison chiffrée avec le terminal Quai logistique MP-0004', status: 'Résolu' }
      ]
    },
    apiPlatform: {
      apps: [
        { id: 'app-1', name: 'Connecteur Paie Interne', env: 'Production', key: 'tp_live_9f8a21c4e77b3d10', scopes: ['rh:read', 'pointage:read', 'stats:read'], expires: '2027-11-15', active: true },
        { id: 'app-2', name: 'Portail Test Intranet', env: 'Sandbox', key: 'tp_test_4c10e991a2d88f02', scopes: ['rh:read', 'projets:write', 'agenda:read'], expires: '2026-12-31', active: true }
      ],
      webhooks: [
        { id: 'wh-1', url: 'https://erp.ravelo.mg/hooks/pointage', event: 'attendance.anomaly', active: true, lastStatus: '200 OK · 42 ms' },
        { id: 'wh-2', url: 'https://intranet.ravelo.mg/hooks/tasks', event: 'task.overdue', active: true, lastStatus: '200 OK · 31 ms' }
      ],
      callLogs: [
        { date: '18/11/2026 · 08:15', method: 'GET', path: '/api/v1/attendance/today', app: 'Connecteur Paie Interne', status: '200 OK', corrId: 'corr-8841a' },
        { date: '18/11/2026 · 07:50', method: 'POST', path: '/api/v1/webhooks/test', app: 'Portail Test Intranet', status: '200 OK', corrId: 'corr-8839f' }
      ]
    },
    predictive: {
      lang: 'FR',
      offlineMode: false,
      sensitivity: 'PME (Équilibré)',
      lastSync: '18/11/2026 · 19:30',
      decisions: {
        'pred-1': { status: 'En attente', comment: '' },
        'pred-2': { status: 'En attente', comment: '' },
        'pred-3': { status: 'Confirmée', comment: 'Relance planifiée avec l\'équipe IT.' }
      }
    },
    logs: [
      { id: 'log-1', date: '15/11/2026 · 17:42', action: 'Modifier', target: 'Fiche de Randria Mialy · fonction', author: 'Rabe Hery (PDG)', motif: 'Changement de poste', before: 'Assistante de communication', after: 'Chargée de communication', field: 'Fonction · fiche Randria Mialy' },
      { id: 'log-2', date: '15/11/2026 · 16:10', action: 'Insérer', target: 'Inscription de 3 salariés', author: 'Rasoa Fanja (DRH)', motif: 'Recrutement novembre', before: '—', after: '3 fiches créées', field: 'Employés' },
      { id: 'log-3', date: '14/11/2026 · 09:25', action: 'Supprimer', target: 'Salarié Rakoto Test retiré', author: 'Rabe Hery (PDG)', motif: 'Fin de contrat', before: 'Actif', after: 'Supprimé', field: 'Employés' },
      { id: 'log-4', date: '13/11/2026 · 18:03', action: 'Modifier', target: 'Règles : heure d\'arrivée 07:45 → 08:00', author: 'Rabe Hery (PDG)', motif: 'Ajustement horaire', before: '07:45', after: '08:00', field: 'Règles · Heure d\'arrivée' }
    ],
    ruleLogs: [
      { label: 'Heure d\'arrivée', before: '07:45', after: '08:00', date: '13/11/2026 · 18:03', author: 'Rabe Hery (PDG)' },
      { label: 'Déjeuner', before: '12:00 – 12:45', after: '12:00 – 13:00', date: '02/11/2026 · 09:10', author: 'Rabe Hery (PDG)' },
      { label: 'Tolérance de retard', before: '5 minutes', after: '10 minutes', date: '20/10/2026 · 14:32', author: 'Rasoa Fanja (DRH)' }
    ]
  };
};

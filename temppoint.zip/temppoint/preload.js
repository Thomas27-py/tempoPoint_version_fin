const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('tempoBridge', {
  platform: 'electron-linux',
  loadState: () => ipcRenderer.invoke('tp:load-state'),
  saveState: (data) => ipcRenderer.invoke('tp:save-state', data),
  exportFile: (payload) => ipcRenderer.invoke('tp:export-file', payload),
  resetState: () => ipcRenderer.invoke('tp:reset-state')
});
